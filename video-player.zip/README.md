# Video Player (Android)

Fast, native Android video player built with **Kotlin**, **Jetpack Compose (Material 3)**, **AndroidX Media3 (ExoPlayer)** with `SurfaceView` rendering, and automatic **LibVLC** fallback for legacy/exotic containers and audio codecs.

## Key Features
- **Ocean Glass Design & Adaptive Navigation**: Three curated themes (**Ocean Navy**, **Midnight AMOLED**, **Sky Ice**) with translucent glassmorphic cards and adaptive bottom bar / tablet navigation rail (`Home`, `Videos`, `Folders`, `Playlists`, `Network`).
- **Home Dashboard & Watch History**: Smart **Resume Watching** hero card with timestamp & dismissal, **Continue Watching**, **Recently Played**, **Recently Added**, **Frequently Played**, library storage summary, and full dedicated **History** screen.
- **Fast Library & Auto-Scan**: Instant cold-start via Room media index cache + background `MediaStore` scan (`VOLUME_EXTERNAL`, including removable storage) + `ContentObserver` live updates + pull-to-refresh.
- **Folder, File & Playlist Management**: List/Grid toggle, search, sorting (name, date added, date modified, size, duration, resolution), hide/unhide folders, `NEW` badge, progress bar, custom **Playlists** with reordering and queue playback, plus multi-select delete/rename/share/play-next/add-to-queue/enriched properties (`MediaExtractor` / `MediaMetadataRetriever`).
- **Comprehensive Subtitles**: Supports **SRT, ASS/SSA, VTT, SUB, SMI** external files (auto-discovery + SAF document picker) plus embedded tracks (ExoPlayer & LibVLC), live sync delay (`-10s..+10s`), font size, colors, background styles, vertical offset, and character encodings (`UTF-8`, `Windows-1252`, `ISO-8859-1`, `Windows-1256`, `UTF-16`).
- **Network Streams & Safe Link Routing**: Stream HTTP/HTTPS/RTSP/HLS/DASH URLs with persistent stream history; YouTube links safely hand off to the official YouTube app/browser.
- **MX-Style Player & Gestures**:
  - Left vertical swipe: real `WindowManager` brightness.
  - Right vertical swipe: `AudioManager` volume + `LoudnessEnhancer` boost up to `200%`.
  - Horizontal swipe: seek with `CLOSEST_SYNC` preview and `EXACT` release.
  - Double tap left/right/center: seek N seconds (`5/10/15/20/30/60s`) or play/pause without showing controls.
  - Two-finger pinch-to-zoom & pan (player surface only).
  - Decoders: `HW`, `HW+` (default), `SW` (software-preferred `MediaCodecSelector`), device codec inspector, audio sync (`-5000ms..+5000ms`), and automatic **LibVLC** fallback with error recovery actions.
  - Controls: 0.25x–4x pitch-corrected speed, 7 aspect ratio modes, multi-audio track selection, mute, screen lock, orientation/match-video rotation, A-B repeat, frame-by-frame step, sleep timer, live queue sheet.
  - **5-Band Equalizer**: `Equalizer`, `BassBoost`, `Virtualizer` with 8 presets persisted across sessions.
  - **Background Audio & PiP**: `MediaSessionService` notification/lockscreen/headset controls, pause on headphone unplug, and Picture-in-Picture (auto-enter + RemoteActions).

## Build Instructions

### Option 1: Build Automatically via GitHub Actions (No Android Studio Needed)
1. Push this repository to GitHub (or run `make_zip.py` in Google Colab / Kaggle to create `video-player-android.zip`, extract, and push).
2. Open the **Actions** tab in your GitHub repository.
3. Wait for **Build Signed Release APKs** to complete (or trigger it manually via **Run workflow**).
4. Download `video-player-arm64-v8a.apk` (for modern Android phones) or `video-player-universal.apk` from the workflow artifacts and install on your device.
5. *(Optional)* Add repository secrets `KEYSTORE_PASSWORD` and `KEY_PASSWORD` in GitHub Settings if you want custom keystore passwords.

### Option 2: Build Locally with Gradle CLI
1. Install **JDK 17** and **Android SDK** (API 36, Build-Tools).
2. Generate a release keystore (if building release):
   ```bash
   keytool -genkeypair -v -keystore my-upload-key.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
   ```
3. Build release APKs:
   ```bash
   export KEYSTORE_PATH="$PWD/my-upload-key.jks"
   export STORE_PASSWORD="your_password"
   export KEY_ALIAS="upload"
   export KEY_PASSWORD="your_password"
   gradle assembleRelease
   ```
4. APKs are generated in `app/build/outputs/apk/release/`.

## Manual Notes
- If publishing under your own package ID outside AI Studio, update `applicationId` in `app/build.gradle.kts` (currently `com.aistudio.videoplayer.kxmpzq`) to `com.videoplayer.app`.
- Grant `Allow access` to videos on first launch (or use `Pick a Video File` / `Open network stream` without storage permissions).
