# Video Player (Android)

Fast, native Android video player built with **Kotlin**, **Jetpack Compose (Material 3)**, **AndroidX Media3 (ExoPlayer)** with `SurfaceView` rendering, and automatic **LibVLC** fallback for legacy/exotic containers and audio codecs.

## Key Features
- **Fast Library & Auto-Scan**: Instant cold-start via Room media index cache + background `MediaStore` scan + `ContentObserver` live updates + pull-to-refresh.
- **Folder & File Views**: List/Grid toggle, search, sorting (name, date, size, duration, resolution), hide/unhide folders, `NEW` badge, resume progress bar, last-played highlight.
- **Multi-Select Actions**: `MediaStore.createDeleteRequest` delete, rename, share, and detailed media properties (`MediaExtractor` / `MediaMetadataRetriever` codec, bitrate, fps, resolution, path).
- **Network Streams & Open With**: Built-in stream URL dialog (HTTP/HTTPS/RTSP/HLS/DASH) and `video/*` `ACTION_VIEW` intent filters.
- **MX-Style Player & Gestures**:
  - Left vertical swipe: real `WindowManager` brightness.
  - Right vertical swipe: `AudioManager` volume + `LoudnessEnhancer` boost up to `200%`.
  - Horizontal swipe: seek with `CLOSEST_SYNC` preview and `EXACT` release.
  - Double tap left/right/center: seek N seconds (`5/10/15/20/30/60s`) or play/pause without showing controls.
  - Two-finger pinch-to-zoom & pan (player surface only).
  - Decoders: `HW`, `HW+` (default), `SW` (custom software-preferred `MediaCodecSelector`), plus automatic **LibVLC** fallback.
  - Controls: 0.25x–4x pitch-corrected speed, 7 aspect ratio modes, multi-audio track selection, mute, screen lock, orientation/match-video rotation, A-B repeat, frame-by-frame step, sleep timer.
  - **5-Band Equalizer**: `Equalizer`, `BassBoost`, `Virtualizer` with 8 presets persisted across sessions.
  - **Background Audio & PiP**: `MediaSessionService` notification/lockscreen/headset controls, pause on headphone unplug, and Picture-in-Picture (auto-enter + RemoteActions).

## Build Instructions

### Option 1: Build Automatically via GitHub Actions (No Android Studio Needed)
1. Push this repository to GitHub (or run `make_zip.py` in Google Colab / Kaggle to create `video-player-android.zip`, extract, and push).
2. Open the **Actions** tab in your GitHub repository.
3. Wait for **Build Signed Release APKs** to complete (or trigger it manually via **Run workflow**).
4. Download `video-player-arm64-v8a.apk` (for modern Android phones) or `video-player-universal.apk` from the workflow artifacts and install on your device.
5. *(Optional)* Add repository secrets `KEYSTORE_PASSWORD` and `KEY_PASSWORD` in GitHub Settings if you want custom keystore passwords.

### Option 2: Build Locally with Gradle CLI
1. Install **JDK 17** and **Android SDK** (API 36, Build-Tools).
2. Generate a release keystore (if building release):
   ```bash
   keytool -genkeypair -v -keystore my-upload-key.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
   ```
3. Build release APKs:
   ```bash
   export KEYSTORE_PATH="$PWD/my-upload-key.jks"
   export STORE_PASSWORD="your_password"
   export KEY_ALIAS="upload"
   export KEY_PASSWORD="your_password"
   gradle assembleRelease
   ```
4. APKs are generated in `app/build/outputs/apk/release/`.

## Manual Notes
- If publishing under your own package ID outside AI Studio, update `applicationId` in `app/build.gradle.kts` (currently `com.aistudio.videoplayer.kxmpzq`) to `com.videoplayer.app`.
- Grant `Allow access` to videos on first launch (or use `Pick a Video File` / `Open network stream` without storage permissions).
