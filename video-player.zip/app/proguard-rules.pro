# R8 Full Mode Keep Rules for Video Player

# Keep line numbers for crash diagnostics while shrinking
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Media3 / ExoPlayer
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keepclassmembers class * extends androidx.media3.common.Player$Listener {
    <methods>;
}

# LibVLC native JNI bindings (critical for R8/ProGuard)
-keep class org.videolan.libvlc.** { *; }
-keep interface org.videolan.libvlc.** { *; }
-dontwarn org.videolan.libvlc.**

# Kotlinx Serialization (Navigation Compose routes)
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.example.ui.navigation.**$$serializer { *; }
-keepclassmembers class com.example.ui.navigation.** {
    *** Companion;
}
-keepclasseswithmembers class com.example.ui.navigation.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Room & DataStore
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Coil video decoder
-keep class coil.decode.VideoFrameDecoder** { *; }
-dontwarn coil.**

# Android AudioEffect JNI safety
-keep class android.media.audiofx.** { *; }
