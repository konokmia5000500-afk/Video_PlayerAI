package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.VideoDao
import com.example.data.local.VideoEntity
import com.example.data.mediastore.MediaStoreScanner
import com.example.data.repository.VideoLibraryRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DatabaseAndRepositoryRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var dao: VideoDao
    private lateinit var repo: VideoLibraryRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.videoDao()
        repo = VideoLibraryRepository(dao, MediaStoreScanner(context))
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `resume watching preserves timestamp on restart and clears after dismiss`() = runBlocking {
        val uri = "content://media/external/video/media/101"
        dao.upsertVideos(
            listOf(
                VideoEntity(
                    id = 101L,
                    contentUri = uri,
                    title = "Sample Movie",
                    displayName = "Sample Movie.mp4",
                    path = "/storage/emulated/0/Movies/Sample Movie.mp4",
                    folderBucketId = "bucket_1",
                    folderName = "Movies",
                    folderPath = "/storage/emulated/0/Movies",
                    durationMs = 120_000L,
                    sizeBytes = 50_000_000L,
                    width = 1920,
                    height = 1080,
                    dateAddedSec = 1_700_000_000L,
                    dateModifiedSec = 1_700_000_000L,
                    mimeType = "video/mp4"
                )
            )
        )

        repo.saveProgress(
            mediaKey = uri,
            title = "Sample Movie",
            positionMs = 45_000L,
            durationMs = 120_000L,
            incrementPlayCount = false
        )

        // Starting playback increments playCount with sentinel -1L without erasing 45s position
        repo.saveProgress(
            mediaKey = uri,
            title = "Sample Movie",
            positionMs = -1L,
            durationMs = 120_000L,
            incrementPlayCount = true
        )

        val candidate = repo.resumeCandidateFlow.first()
        assertNotNull(candidate)
        assertEquals(45_000L, candidate?.positionMs)
        assertEquals(2, candidate?.playCount)

        repo.dismissFromResume(uri)
        val afterDismiss = repo.resumeCandidateFlow.first()
        assertNull(afterDismiss)
    }

    @Test
    fun `playlist CRUD and item reordering persist cleanly`() = runBlocking {
        val v1 = VideoEntity(
            id = 1L,
            contentUri = "content://video/1",
            title = "Alpha",
            displayName = "Alpha.mp4",
            path = "/Movies/Alpha.mp4",
            folderBucketId = "b1",
            folderName = "Movies",
            folderPath = "/Movies",
            durationMs = 60_000L,
            sizeBytes = 10_000_000L,
            width = 1280,
            height = 720,
            dateAddedSec = 100L,
            dateModifiedSec = 100L,
            mimeType = "video/mp4"
        )
        val v2 = v1.copy(id = 2L, contentUri = "content://video/2", title = "Beta", displayName = "Beta.mp4")
        dao.upsertVideos(listOf(v1, v2))

        val domainVideos = repo.videosFlow.first().sortedBy { it.id }
        val playlistId = repo.createPlaylist("Weekend Watchlist", domainVideos)

        val itemsBefore = repo.observePlaylistVideos(playlistId).first()
        assertEquals(listOf("Alpha", "Beta"), itemsBefore.map { it.title })

        repo.movePlaylistItemUp(playlistId, itemsBefore, index = 1)
        val itemsAfterMove = repo.observePlaylistVideos(playlistId).first()
        assertEquals(listOf("Beta", "Alpha"), itemsAfterMove.map { it.title })

        repo.renamePlaylist(playlistId, "Top Picks")
        val summary = repo.playlistsFlow.first().first()
        assertEquals("Top Picks", summary.name)
        assertEquals(2, summary.itemCount)

        repo.deletePlaylist(playlistId)
        assertEquals(0, repo.playlistsFlow.first().size)
    }

    @Test
    fun `network stream history records and increments playCount`() = runBlocking {
        val url = "https://cdn.example.com/live.m3u8"
        repo.recordNetworkStreamPlay(url, "Live Feed")
        repo.recordNetworkStreamPlay(url, "Live Feed")

        val entries = repo.networkStreamHistoryFlow.first()
        assertEquals(1, entries.size)
        assertEquals(2, entries.first().playCount)
        assertEquals("Live Feed", entries.first().title)
    }
}
