package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performTextInput
import com.example.data.model.LibrarySummary
import com.example.data.model.WatchHistoryItem
import com.example.data.preferences.AppThemeMode
import com.example.ui.home.HomeDashboardContent
import com.example.ui.home.HomeDashboardState
import com.example.ui.network.NetworkTabContent
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.VideoPlayerTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ComposeUiRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `home dashboard hides resume card when no history exists`() {
        composeRule.setContent {
            VideoPlayerTheme(themeMode = AppThemeMode.DARK) {
                HomeDashboardContent(
                    dashboard = HomeDashboardState(
                        resumeCandidate = null,
                        summary = LibrarySummary(totalVideos = 5, totalFolders = 2, totalSizeBytes = 1024L * 1024L)
                    ),
                    hasStoragePermission = true,
                    showThumbnails = false,
                    onResumePlay = {},
                    onDismissResume = {},
                    onPlayVideo = {},
                    onOpenHistory = {},
                    onRequestPermission = {},
                    onPickVideoFile = {},
                    onOpenNetworkTab = {}
                )
            }
        }
        composeRule.waitForIdle()
        assertEquals(0, composeRule.onAllNodesWithTag("resume_watching_card").fetchSemanticsNodes().size)
    }

    @Test
    fun `home dashboard shows resume card when candidate exists`() {
        val candidate = WatchHistoryItem(
            mediaKey = "content://video/10",
            title = "Ocean Documentary",
            thumbnailUri = "",
            positionMs = 30_000L,
            durationMs = 120_000L,
            lastPlayedAtMs = System.currentTimeMillis(),
            playCount = 1,
            isCompleted = false,
            dismissedFromResume = false,
            isNetworkStream = false,
            folderBucketId = "bucket_1",
            width = 1920,
            height = 1080
        )
        composeRule.setContent {
            VideoPlayerTheme(themeMode = AppThemeMode.DARK) {
                HomeDashboardContent(
                    dashboard = HomeDashboardState(
                        resumeCandidate = candidate,
                        summary = LibrarySummary(totalVideos = 1, totalFolders = 1, totalSizeBytes = 10_000L)
                    ),
                    hasStoragePermission = true,
                    showThumbnails = false,
                    onResumePlay = {},
                    onDismissResume = {},
                    onPlayVideo = {},
                    onOpenHistory = {},
                    onRequestPermission = {},
                    onPickVideoFile = {},
                    onOpenNetworkTab = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("resume_watching_card").assertIsDisplayed()
        composeRule.onNodeWithText("Ocean Documentary").assertIsDisplayed()
        composeRule.onNodeWithTag("resume_watching_cta").assertIsDisplayed()
    }

    @Test
    fun `network tab distinguishes YouTube link from direct stream URL`() {
        composeRule.setContent {
            VideoPlayerTheme(themeMode = AppThemeMode.DARK) {
                NetworkTabContent(onPlayStreamUrl = { _, _ -> })
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("network_tab_url_input")
            .performTextInput("https://youtu.be/dQw4w9WgXcQ")
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("open_youtube_external_button").assertIsDisplayed()
        assertEquals(0, composeRule.onAllNodesWithTag("network_play_stream_button").fetchSemanticsNodes().size)
    }

    @Test
    fun `settings screen renders all upgraded sections`() {
        composeRule.setContent {
            VideoPlayerTheme(themeMode = AppThemeMode.DARK) {
                SettingsScreen(onBack = {})
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("setting_start_tab").assertIsDisplayed()
        composeRule.onNodeWithTag("setting_theme").assertIsDisplayed()
    }
}
