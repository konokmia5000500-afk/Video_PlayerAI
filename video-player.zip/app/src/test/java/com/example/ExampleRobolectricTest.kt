package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.TimeFormatters
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Video Player", appName)
    }

    @Test
    fun `format duration formats mm ss and hh mm ss`() {
        assertEquals("01:05", TimeFormatters.formatDuration(65_000L))
        assertEquals("1:01:05", TimeFormatters.formatDuration(3_665_000L))
    }

    @Test
    fun `format resolution badge maps standard heights`() {
        assertEquals("4K", TimeFormatters.formatResolutionBadge(3840, 2160))
        assertEquals("1080p", TimeFormatters.formatResolutionBadge(1920, 1080))
        assertEquals("720p", TimeFormatters.formatResolutionBadge(1280, 720))
    }
}
