package com.example

import com.example.util.ClassifiedStreamUrl
import com.example.util.NetworkUrlClassifier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NetworkUrlClassifierRobolectricTest {

    @Test
    fun `classifies HLS DASH RTSP and direct HTTP URLs`() {
        val hls = NetworkUrlClassifier.classify("https://cdn.example.com/live/master.m3u8")
        assertTrue(hls is ClassifiedStreamUrl.PlayableStream)
        assertEquals("HLS Stream", (hls as ClassifiedStreamUrl.PlayableStream).protocolLabel)

        val dash = NetworkUrlClassifier.classify("http://cdn.example.com/manifest.mpd")
        assertTrue(dash is ClassifiedStreamUrl.PlayableStream)
        assertEquals("DASH Stream", (dash as ClassifiedStreamUrl.PlayableStream).protocolLabel)

        val rtsp = NetworkUrlClassifier.classify("rtsp://192.168.1.10:554/stream1")
        assertTrue(rtsp is ClassifiedStreamUrl.PlayableStream)
        assertEquals("RTSP Stream", (rtsp as ClassifiedStreamUrl.PlayableStream).protocolLabel)

        val bare = NetworkUrlClassifier.classify("media.example.org/movie.mp4")
        assertTrue(bare is ClassifiedStreamUrl.PlayableStream)
        assertEquals("https://media.example.org/movie.mp4", (bare as ClassifiedStreamUrl.PlayableStream).normalizedUrl)
    }

    @Test
    fun `routes YouTube links cleanly to external YouTubeLink result`() {
        listOf(
            "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            "https://m.youtube.com/shorts/abc123",
            "https://youtu.be/dQw4w9WgXcQ",
            "youtube.com/watch?v=test"
        ).forEach { url ->
            val result = NetworkUrlClassifier.classify(url)
            assertTrue("Expected YouTubeLink for $url", result is ClassifiedStreamUrl.YouTubeLink)
        }
    }

    @Test
    fun `rejects empty or unsupported schemes`() {
        assertTrue(NetworkUrlClassifier.classify("   ") is ClassifiedStreamUrl.Invalid)
        assertTrue(NetworkUrlClassifier.classify("ftp://server/video.mp4") is ClassifiedStreamUrl.Invalid)
    }
}
