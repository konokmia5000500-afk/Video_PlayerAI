package com.example

import com.example.player.subtitle.SubtitleFormat
import com.example.player.subtitle.SubtitleParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.nio.charset.Charset

class SubtitleParserTest {

    @Test
    fun `parses SRT cues and strips HTML formatting tags`() {
        val srt = """
            1
            00:00:01,500 --> 00:00:04,000
            <i>Hello</i> World!

            2
            00:00:05,250 --> 00:00:08,500
            Second line
            Third line
        """.trimIndent()

        val cues = SubtitleParser.parse(srt, SubtitleFormat.SRT)
        assertEquals(2, cues.size)
        assertEquals(1500L, cues[0].startMs)
        assertEquals(4000L, cues[0].endMs)
        assertEquals("Hello World!", cues[0].text)
        assertEquals("Second line\nThird line", cues[1].text)
    }

    @Test
    fun `parses VTT cues without hours`() {
        val vtt = """
            WEBVTT

            00:02.000 --> 00:05.500 align:middle
            Welcome to the stream
        """.trimIndent()

        val cues = SubtitleParser.parse(vtt, SubtitleFormat.VTT)
        assertEquals(1, cues.size)
        assertEquals(2000L, cues[0].startMs)
        assertEquals(5500L, cues[0].endMs)
        assertEquals("Welcome to the stream", cues[0].text)
    }

    @Test
    fun `parses ASS dialogue and strips override blocks`() {
        val ass = """
            [Script Info]
            Title: Test

            [Events]
            Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
            Dialogue: 0,0:00:10.50,0:00:13.25,Default,,0,0,0,,{\pos(320,200)}Top line\NBottom line
        """.trimIndent()

        val cues = SubtitleParser.parse(ass, SubtitleFormat.ASS)
        assertEquals(1, cues.size)
        assertEquals(10_500L, cues[0].startMs)
        assertEquals(13_250L, cues[0].endMs)
        assertEquals("Top line\nBottom line", cues[0].text)
    }

    @Test
    fun `parses MicroDVD SUB frames and SAMI SMI sync points`() {
        val sub = "{25}{75}Frame subtitle|Line 2"
        val subCues = SubtitleParser.parse(sub, SubtitleFormat.SUB, fps = 25f)
        assertEquals(1, subCues.size)
        assertEquals(1000L, subCues[0].startMs)
        assertEquals(3000L, subCues[0].endMs)
        assertEquals("Frame subtitle\nLine 2", subCues[0].text)

        val smi = """
            <SAMI>
            <BODY>
            <SYNC Start=1200><P>First caption<br>Line two</P>
            <SYNC Start=4000><P>&nbsp;</P>
            </BODY>
            </SAMI>
        """.trimIndent()
        val smiCues = SubtitleParser.parse(smi, SubtitleFormat.SMI)
        assertEquals(1, smiCues.size)
        assertEquals(1200L, smiCues[0].startMs)
        assertEquals(4000L, smiCues[0].endMs)
        assertEquals("First caption\nLine two", smiCues[0].text)
    }

    @Test
    fun `binary search respects delay offset cleanly`() {
        val cues = SubtitleParser.parse(
            """
            1
            00:00:05,000 --> 00:00:07,000
            Target cue
            """.trimIndent(),
            SubtitleFormat.SRT
        )

        assertEquals("Target cue", SubtitleParser.findActiveCueText(cues, 6000L, offsetMs = 0L))
        assertNull(SubtitleParser.findActiveCueText(cues, 4500L, offsetMs = 0L))
        // Negative offset shifts subtitles earlier: at 4500ms with -1000ms offset -> lookup 5500ms
        assertEquals("Target cue", SubtitleParser.findActiveCueText(cues, 4500L, offsetMs = -1000L))
        // Positive offset delays subtitles: at 5500ms with +1000ms offset -> lookup 4500ms
        assertNull(SubtitleParser.findActiveCueText(cues, 5500L, offsetMs = 1000L))
    }

    @Test
    fun `decodeBytes strips UTF-8 BOM and decodes UTF-16LE BOM`() {
        val utf8Bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + "Hola".toByteArray(Charsets.UTF_8)
        assertEquals("Hola", SubtitleParser.decodeBytes(utf8Bom, Charset.forName("Windows-1252")))

        val utf16Le = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + "Hi".toByteArray(Charsets.UTF_16LE)
        assertEquals("Hi", SubtitleParser.decodeBytes(utf16Le, Charsets.UTF_8))
    }
}
