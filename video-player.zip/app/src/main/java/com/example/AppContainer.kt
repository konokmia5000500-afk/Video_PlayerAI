package com.example

import android.content.Context
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.data.local.AppDatabase
import com.example.data.mediastore.MediaStoreScanner
import com.example.data.preferences.SettingsRepository
import com.example.data.repository.VideoLibraryRepository

/**
 * Manual, lazy-initialized dependency container. Avoids reflection and Hilt startup overhead.
 */
class AppContainer(context: Context) {
    private val appContext: Context = context.applicationContext

    val database: AppDatabase by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        AppDatabase.getInstance(appContext)
    }

    val settingsRepository: SettingsRepository by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        SettingsRepository(appContext)
    }

    val mediaStoreScanner: MediaStoreScanner by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        MediaStoreScanner(appContext)
    }

    val videoLibraryRepository: VideoLibraryRepository by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        VideoLibraryRepository(
            videoDao = database.videoDao(),
            scanner = mediaStoreScanner
        )
    }

    val imageLoader: ImageLoader by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        ImageLoader.Builder(appContext)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .memoryCache {
                MemoryCache.Builder(appContext)
                    .maxSizePercent(0.20)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(appContext.cacheDir.resolve("video_thumbs"))
                    .maxSizeBytes(96L * 1024L * 1024L)
                    .build()
            }
            .crossfade(false)
            .build()
    }

    companion object {
        @Volatile
        private var instance: AppContainer? = null

        fun getInstance(context: Context): AppContainer {
            return instance ?: synchronized(this) {
                instance ?: AppContainer(context.applicationContext).also { instance = it }
            }
        }
    }
}
