package com.example

import android.app.Application

/**
 * Intentionally keeps onCreate() empty so cold start to the first visible frame stays under 1s.
 * All dependencies are lazily initialized via [AppContainer] on first access.
 */
class VideoPlayerApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
