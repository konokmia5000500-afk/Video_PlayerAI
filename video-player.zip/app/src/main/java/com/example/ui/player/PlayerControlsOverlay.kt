package com.example.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.SkipNext
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.player.engine.LoopMode
import com.example.player.engine.PlaybackPositionState
import com.example.player.engine.PlaybackUiState
import com.example.player.engine.PlayerEngineType
import com.example.util.TimeFormatters
import kotlinx.coroutines.flow.StateFlow

@Composable
fun PlayerControlsOverlay(
    playbackState: PlaybackUiState,
    chromeState: PlayerChromeState,
    positionStateFlow: StateFlow<PlaybackPositionState>,
    isPipSupported: Boolean,
    onBack: () -> Unit,
    onDecoderClick: () -> Unit,
    onDecoderInfoClick: () -> Unit,
    onSubtitleClick: () -> Unit,
    onAudioTrackClick: () -> Unit,
    onAudioSyncClick: () -> Unit,
    onMuteClick: () -> Unit,
    onPipClick: () -> Unit,
    onRotateClick: () -> Unit,
    onLockClick: () -> Unit,
    onPreviousClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onNextClick: () -> Unit,
    onStepFrameClick: () -> Unit,
    onSpeedClick: () -> Unit,
    onAspectRatioClick: () -> Unit,
    onEqualizerClick: () -> Unit,
    onQueueClick: () -> Unit,
    onFullscreenClick: () -> Unit,
    onToggleRemainingTime: () -> Unit,
    onSeek: (positionMs: Long, isScrubbing: Boolean) -> Unit,
    onResetZoom: () -> Unit,
    onAbRepeatClick: () -> Unit,
    onClearAbRepeat: () -> Unit,
    onSleepTimerClick: () -> Unit,
    onLoopClick: () -> Unit,
    onShuffleClick: () -> Unit,
    onPropertiesClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    var showMoreMenu by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        // Lock overlay unlock pill
        AnimatedVisibility(
            visible = chromeState.isLocked && chromeState.showUnlockButton,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(20.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.72f),
                modifier = Modifier
                    .clickable(onClick = onLockClick)
                    .testTag("unlock_screen_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.LockOpen,
                        contentDescription = stringResource(R.string.screen_unlock),
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Unlock", color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        // Main MX Controls
        AnimatedVisibility(
            visible = !chromeState.isLocked && chromeState.controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top gradient + clean MX-style top bar (no duplicate playlist/play buttons)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Black.copy(alpha = 0.84f), Color.Transparent)
                            )
                        )
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("player_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = playbackState.currentItem?.title ?: "Video",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val badgeText = if (playbackState.engineType == PlayerEngineType.LIBVLC) {
                                "VLC (${playbackState.decoderMode.badge})"
                            } else {
                                playbackState.decoderMode.badge
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color.White.copy(alpha = 0.2f),
                                    modifier = Modifier
                                        .clickable(onClick = onDecoderClick)
                                        .testTag("decoder_badge")
                                ) {
                                    Text(
                                        text = badgeText,
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                if (playbackState.sleepTimerRemainingMs > 0L) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                        modifier = Modifier.clickable(onClick = onSleepTimerClick)
                                    ) {
                                        Text(
                                            text = "Sleep ${TimeFormatters.formatDuration(playbackState.sleepTimerRemainingMs)}",
                                            color = Color.White,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }

                        IconButton(
                            onClick = onSubtitleClick,
                            modifier = Modifier.testTag("subtitle_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ClosedCaption,
                                contentDescription = stringResource(R.string.subtitles),
                                tint = if (playbackState.subtitlesEnabled) MaterialTheme.colorScheme.primary else Color.White
                            )
                        }

                        IconButton(
                            onClick = onAudioTrackClick,
                            modifier = Modifier.testTag("audio_track_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Audiotrack,
                                contentDescription = stringResource(R.string.audio_track),
                                tint = Color.White
                            )
                        }

                        IconButton(
                            onClick = onMuteClick,
                            modifier = Modifier.testTag("mute_button")
                        ) {
                            Icon(
                                imageVector = if (playbackState.isMuted) {
                                    Icons.AutoMirrored.Filled.VolumeOff
                                } else {
                                    Icons.AutoMirrored.Filled.VolumeUp
                                },
                                contentDescription = "Mute",
                                tint = if (playbackState.isMuted) MaterialTheme.colorScheme.primary else Color.White
                            )
                        }

                        if (isPipSupported) {
                            IconButton(
                                onClick = onPipClick,
                                modifier = Modifier.testTag("pip_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PictureInPictureAlt,
                                    contentDescription = stringResource(R.string.pip_mode),
                                    tint = Color.White
                                )
                            }
                        }

                        IconButton(
                            onClick = onRotateClick,
                            modifier = Modifier.testTag("rotate_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ScreenRotation,
                                contentDescription = "Rotate screen",
                                tint = Color.White
                            )
                        }

                        Box {
                            IconButton(
                                onClick = { showMoreMenu = true },
                                modifier = Modifier.testTag("player_more_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.MoreVert,
                                    contentDescription = "More",
                                    tint = Color.White
                                )
                            }
                            DropdownMenu(
                                expanded = showMoreMenu,
                                onDismissRequest = { showMoreMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("${stringResource(R.string.queue_title)} (${playbackState.queueSize})") },
                                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onQueueClick()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Audio Sync (${playbackState.audioDelayMs}ms)") },
                                    leadingIcon = { Icon(Icons.Filled.Sync, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onAudioSyncClick()
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        val abLabel = when {
                                            playbackState.abRepeatA == null -> "A-B Repeat: Set A"
                                            playbackState.abRepeatB == null -> "A-B Repeat: Set B"
                                            else -> "A-B Repeat: Clear"
                                        }
                                        Text(abLabel)
                                    },
                                    leadingIcon = { Icon(Icons.Filled.Repeat, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onAbRepeatClick()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Loop: ${playbackState.loopMode.label}") },
                                    leadingIcon = {
                                        Icon(
                                            if (playbackState.loopMode == LoopMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                                            contentDescription = null
                                        )
                                    },
                                    onClick = {
                                        showMoreMenu = false
                                        onLoopClick()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (playbackState.shuffleEnabled) "Shuffle: On" else "Shuffle: Off") },
                                    leadingIcon = { Icon(Icons.Filled.Shuffle, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onShuffleClick()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.sleep_timer)) },
                                    leadingIcon = { Icon(Icons.Filled.Timer, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onSleepTimerClick()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.decoder_info)) },
                                    leadingIcon = { Icon(Icons.Filled.Memory, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onDecoderInfoClick()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.properties)) },
                                    leadingIcon = { Icon(Icons.Filled.Info, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onPropertiesClick()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.settings_title)) },
                                    leadingIcon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onSettingsClick()
                                    }
                                )
                            }
                        }
                    }

                    // Active Zoom or A-B repeat status chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (chromeState.zoomScale > 1.02f) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color.Black.copy(alpha = 0.65f),
                                modifier = Modifier.clickable(onClick = onResetZoom)
                            ) {
                                Text(
                                    text = "${(chromeState.zoomScale * 10).toInt() / 10f}x • Tap to reset",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (playbackState.abRepeatA != null) {
                            val aText = TimeFormatters.formatDuration(playbackState.abRepeatA)
                            val bText = playbackState.abRepeatB?.let { TimeFormatters.formatDuration(it) } ?: "…"
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                modifier = Modifier.clickable(onClick = onClearAbRepeat)
                            ) {
                                Text(
                                    text = "A-B: $aText → $bText (Clear)",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Bottom gradient + seek bar + transport/tools
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.86f))
                            )
                        )
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    IsolatedSeekBarSection(
                        positionStateFlow = positionStateFlow,
                        showRemainingTime = chromeState.showRemainingTime,
                        onToggleRemainingTime = onToggleRemainingTime,
                        onSeek = onSeek
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = onLockClick,
                            modifier = Modifier.testTag("lock_screen_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = stringResource(R.string.screen_lock),
                                tint = Color.White
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onPreviousClick,
                                enabled = playbackState.queueSize > 1,
                                modifier = Modifier.testTag("player_previous_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SkipPrevious,
                                    contentDescription = stringResource(R.string.previous),
                                    tint = if (playbackState.queueSize > 1) Color.White else Color.White.copy(alpha = 0.35f),
                                    modifier = Modifier.size(30.dp)
                                )
                            }

                            IconButton(
                                onClick = onPlayPauseClick,
                                modifier = Modifier
                                    .size(52.dp)
                                    .testTag("player_play_pause_button")
                            ) {
                                Icon(
                                    imageVector = if (playbackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = stringResource(if (playbackState.isPlaying) R.string.pause else R.string.play),
                                    tint = Color.White,
                                    modifier = Modifier.size(38.dp)
                                )
                            }

                            if (!playbackState.isPlaying) {
                                IconButton(
                                    onClick = onStepFrameClick,
                                    modifier = Modifier.testTag("step_frame_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.SkipNext,
                                        contentDescription = stringResource(R.string.step_frame),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            IconButton(
                                onClick = onNextClick,
                                enabled = playbackState.queueSize > 1,
                                modifier = Modifier.testTag("player_next_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SkipNext,
                                    contentDescription = stringResource(R.string.next),
                                    tint = if (playbackState.queueSize > 1) Color.White else Color.White.copy(alpha = 0.35f),
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color.White.copy(alpha = 0.16f),
                                modifier = Modifier
                                    .clickable(onClick = onSpeedClick)
                                    .testTag("speed_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Speed,
                                        contentDescription = stringResource(R.string.speed),
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = TimeFormatters.formatSpeed(playbackState.speed),
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            IconButton(
                                onClick = onAspectRatioClick,
                                modifier = Modifier.testTag("aspect_ratio_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AspectRatio,
                                    contentDescription = stringResource(R.string.aspect_ratio),
                                    tint = Color.White
                                )
                            }

                            IconButton(
                                onClick = onEqualizerClick,
                                modifier = Modifier.testTag("equalizer_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Equalizer,
                                    contentDescription = stringResource(R.string.equalizer),
                                    tint = Color.White
                                )
                            }

                            IconButton(
                                onClick = onFullscreenClick,
                                modifier = Modifier.testTag("fullscreen_button")
                            ) {
                                Icon(
                                    imageVector = if (chromeState.isFullscreenImmersive) {
                                        Icons.Filled.FullscreenExit
                                    } else {
                                        Icons.Filled.Fullscreen
                                    },
                                    contentDescription = "Fullscreen",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IsolatedSeekBarSection(
    positionStateFlow: StateFlow<PlaybackPositionState>,
    showRemainingTime: Boolean,
    onToggleRemainingTime: () -> Unit,
    onSeek: (positionMs: Long, isScrubbing: Boolean) -> Unit
) {
    val posState by positionStateFlow.collectAsStateWithLifecycle()
    var isDragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }

    val durationMs = posState.durationMs.coerceAtLeast(0L)
    val currentFraction = if (isDragging) {
        dragFraction
    } else if (durationMs > 0L) {
        (posState.positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val displayedPosMs = if (isDragging) (dragFraction * durationMs).toLong() else posState.positionMs
    val rightTimeText = if (showRemainingTime && durationMs > 0L) {
        "-${TimeFormatters.formatDuration((durationMs - displayedPosMs).coerceAtLeast(0L))}"
    } else {
        TimeFormatters.formatDuration(durationMs)
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = TimeFormatters.formatDuration(displayedPosMs),
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.width(56.dp)
        )
        Slider(
            value = currentFraction,
            onValueChange = { frac ->
                isDragging = true
                dragFraction = frac
                if (durationMs > 0L) {
                    onSeek((frac * durationMs).toLong(), true)
                }
            },
            onValueChangeFinished = {
                isDragging = false
                if (durationMs > 0L) {
                    onSeek((dragFraction * durationMs).toLong(), false)
                }
            },
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = Color.White.copy(alpha = 0.28f)
            ),
            modifier = Modifier
                .weight(1f)
                .height(28.dp)
                .testTag("player_seekbar")
        )
        Text(
            text = rightTimeText,
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier
                .clickable(onClick = onToggleRemainingTime)
                .padding(start = 8.dp)
        )
    }
}

@Composable
fun GestureHudOverlay(hudState: GestureHudState, modifier: Modifier = Modifier) {
    if (hudState is GestureHudState.None) return
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.Black.copy(alpha = 0.78f)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (hudState) {
                    is GestureHudState.Brightness -> {
                        Icon(
                            imageVector = Icons.Filled.WbSunny,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Brightness ${hudState.percent}%",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    is GestureHudState.Volume -> {
                        Icon(
                            imageVector = if (hudState.percent == 0) {
                                Icons.AutoMirrored.Filled.VolumeOff
                            } else {
                                Icons.AutoMirrored.Filled.VolumeUp
                            },
                            contentDescription = null,
                            tint = if (hudState.percent > 100) MaterialTheme.colorScheme.primary else Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (hudState.percent > 100) "Volume Boost ${hudState.percent}%" else "Volume ${hudState.percent}%",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    is GestureHudState.SeekPreview -> {
                        Text(
                            text = TimeFormatters.formatDuration(hudState.targetMs),
                            color = Color.White,
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = TimeFormatters.formatSignedDelta(hudState.deltaMs),
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    is GestureHudState.DoubleTapSeek -> {
                        Text(
                            text = if (hudState.isForward) "+${hudState.seconds}s  ▶▶" else "◀◀  -${hudState.seconds}s",
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    is GestureHudState.DoubleTapPlayPause -> {
                        Icon(
                            imageVector = if (hudState.isNowPlaying) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                    is GestureHudState.ToastLabel -> {
                        Text(
                            text = hudState.label,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    GestureHudState.None -> Unit
                }
            }
        }
    }
}
