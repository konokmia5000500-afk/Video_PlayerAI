package com.example.ui.player

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.data.model.VideoItem
import com.example.data.model.VideoProperties
import com.example.data.preferences.DecoderMode
import com.example.data.preferences.OrientationMode
import com.example.data.preferences.PlayerSettings
import com.example.data.preferences.SubtitleBackgroundStyle
import com.example.player.audio.EqualizerPreset
import com.example.player.engine.AspectRatioMode
import com.example.player.engine.AudioTrackInfo
import com.example.player.engine.LoopMode
import com.example.player.engine.PlaybackPositionState
import com.example.player.engine.PlaybackQueueItem
import com.example.player.engine.PlaybackUiState
import com.example.player.engine.PlayerEngineType
import com.example.player.service.PlaybackService
import com.example.player.service.PlaybackServiceConnection
import com.example.player.subtitle.SubtitleTrackInfo
import com.example.util.MediaInfoExtractor
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
data class PlayerChromeState(
    val controlsVisible: Boolean = true,
    val isLocked: Boolean = false,
    val showUnlockButton: Boolean = false,
    val isFullscreenImmersive: Boolean = true,
    val showRemainingTime: Boolean = false,
    val orientationMode: OrientationMode = OrientationMode.MATCH_VIDEO,
    val zoomScale: Float = 1f,
    val panX: Float = 0f,
    val panY: Float = 0f
)

@OptIn(ExperimentalCoroutinesApi::class)
class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val container = AppContainer.getInstance(application)
    private val settingsRepo = container.settingsRepository
    private val libraryRepo = container.videoLibraryRepository
    private val audioManager = application.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val serviceConnection = PlaybackServiceConnection(application)
    val serviceFlow: StateFlow<PlaybackService?> = serviceConnection.service

    val settings: StateFlow<PlayerSettings> = settingsRepo.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = PlayerSettings()
    )

    val playbackState: StateFlow<PlaybackUiState> = serviceFlow
        .flatMapLatest { service -> service?.uiState ?: flowOf(PlaybackUiState()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = PlaybackUiState()
        )

    val positionState: StateFlow<PlaybackPositionState> = serviceFlow
        .flatMapLatest { service -> service?.positionState ?: flowOf(PlaybackPositionState()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = PlaybackPositionState()
        )

    val queueFlow: StateFlow<List<PlaybackQueueItem>> = serviceFlow
        .flatMapLatest { service -> service?.queueFlow ?: flowOf(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val activeSubtitleTextFlow: StateFlow<String?> = serviceFlow
        .flatMapLatest { service -> service?.activeSubtitleText ?: flowOf(null) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = null
        )

    private val _chromeState = MutableStateFlow(PlayerChromeState())
    val chromeState: StateFlow<PlayerChromeState> = _chromeState.asStateFlow()

    private val _propertiesState = MutableStateFlow<Pair<VideoProperties?, Boolean>>(null to false)
    val propertiesState: StateFlow<Pair<VideoProperties?, Boolean>> = _propertiesState.asStateFlow()

    private var autoHideJob: Job? = null
    private var unlockHideJob: Job? = null
    private var loadedRouteKey: String? = null

    init {
        serviceConnection.bind()
        viewModelScope.launch {
            val initialSettings = settingsRepo.settingsFlow.first()
            _chromeState.update {
                it.copy(
                    orientationMode = initialSettings.defaultOrientationMode,
                    isFullscreenImmersive = initialSettings.autoFullscreen
                )
            }
        }
    }

    override fun onCleared() {
        autoHideJob?.cancel()
        unlockHideJob?.cancel()
        serviceConnection.service.value?.setUiForegroundActive(false)
        serviceConnection.service.value?.setPositionTickerActive(false)
        serviceConnection.unbind()
        super.onCleared()
    }

    fun startPlaybackIfNeeded(
        startUri: String,
        folderBucketId: String,
        playlistId: Long,
        fallbackTitle: String,
        isNetworkStream: Boolean,
        initialPositionMs: Long
    ) {
        val routeKey = "$startUri|$folderBucketId|$playlistId|$isNetworkStream|$initialPositionMs"
        if (loadedRouteKey == routeKey) return
        loadedRouteKey = routeKey

        viewModelScope.launch {
            val service = awaitService()
            service.setUiForegroundActive(true)

            val queueItems = when {
                playlistId > 0L -> {
                    val playlistQueue = libraryRepo.getPlaylistQueue(playlistId)
                    if (playlistQueue.isNotEmpty()) {
                        playlistQueue
                    } else if (startUri.isNotBlank()) {
                        val resolvedTitle = fallbackTitle.ifBlank {
                            Uri.parse(startUri).lastPathSegment?.substringAfterLast('/') ?: "Video"
                        }
                        listOf(
                            PlaybackQueueItem(
                                uri = startUri,
                                title = resolvedTitle,
                                isNetworkStream = isNetworkStream
                            )
                        )
                    } else {
                        emptyList()
                    }
                }
                else -> {
                    val allVideos = libraryRepo.videosFlow.first()
                    val folderVideos = if (!isNetworkStream && folderBucketId.isNotBlank()) {
                        allVideos.filter { it.folderBucketId == folderBucketId }
                    } else {
                        emptyList()
                    }

                    if (folderVideos.isNotEmpty() && folderVideos.any { it.contentUri == startUri }) {
                        folderVideos.map { it.toQueueItem() }
                    } else {
                        val matched = if (!isNetworkStream) allVideos.firstOrNull { it.contentUri == startUri } else null
                        if (matched != null) {
                            listOf(matched.toQueueItem())
                        } else {
                            val resolvedTitle = fallbackTitle.ifBlank {
                                Uri.parse(startUri).lastPathSegment?.substringAfterLast('/') ?: "Video Stream"
                            }
                            listOf(
                                PlaybackQueueItem(
                                    uri = startUri,
                                    title = resolvedTitle,
                                    isNetworkStream = isNetworkStream
                                )
                            )
                        }
                    }
                }
            }

            if (queueItems.isEmpty()) return@launch

            val startIndex = if (startUri.isNotBlank()) {
                queueItems.indexOfFirst { it.uri == startUri }.coerceAtLeast(0)
            } else {
                0
            }

            service.loadQueue(
                items = queueItems,
                startIndex = startIndex,
                overrideStartPositionMs = initialPositionMs
            )
            service.setPositionTickerActive(_chromeState.value.controlsVisible)
            scheduleAutoHide()
        }
    }

    private suspend fun awaitService(): PlaybackService {
        serviceConnection.service.value?.let { return it }
        return serviceConnection.service.first { it != null }!!
    }

    fun onSingleTap() {
        val current = _chromeState.value
        if (current.isLocked) {
            val nextUnlock = !current.showUnlockButton
            _chromeState.update { it.copy(showUnlockButton = nextUnlock) }
            unlockHideJob?.cancel()
            if (nextUnlock) {
                unlockHideJob = viewModelScope.launch {
                    delay(2800L)
                    _chromeState.update { it.copy(showUnlockButton = false) }
                }
            }
            return
        }
        val nextVisible = !current.controlsVisible
        setControlsVisible(nextVisible)
    }

    fun setControlsVisible(visible: Boolean) {
        _chromeState.update { it.copy(controlsVisible = visible) }
        serviceFlow.value?.setPositionTickerActive(visible)
        if (visible) {
            serviceFlow.value?.syncPositionNow()
            scheduleAutoHide()
        } else {
            autoHideJob?.cancel()
        }
    }

    fun scheduleAutoHide() {
        autoHideJob?.cancel()
        if (!_chromeState.value.controlsVisible || _chromeState.value.isLocked) return
        autoHideJob = viewModelScope.launch {
            delay(3500L)
            if (playbackState.value.isPlaying) {
                _chromeState.update { it.copy(controlsVisible = false) }
                serviceFlow.value?.setPositionTickerActive(false)
            }
        }
    }

    fun keepControlsAlive() {
        scheduleAutoHide()
    }

    fun toggleLock() {
        val nextLocked = !_chromeState.value.isLocked
        _chromeState.update {
            it.copy(
                isLocked = nextLocked,
                controlsVisible = !nextLocked,
                showUnlockButton = nextLocked
            )
        }
        serviceFlow.value?.setPositionTickerActive(!nextLocked)
        if (nextLocked) {
            autoHideJob?.cancel()
            unlockHideJob?.cancel()
            unlockHideJob = viewModelScope.launch {
                delay(2500L)
                _chromeState.update { it.copy(showUnlockButton = false) }
            }
        } else {
            scheduleAutoHide()
        }
    }

    fun toggleRemainingTime() {
        _chromeState.update { it.copy(showRemainingTime = !it.showRemainingTime) }
        keepControlsAlive()
    }

    fun toggleFullscreenImmersive() {
        _chromeState.update { it.copy(isFullscreenImmersive = !it.isFullscreenImmersive) }
        keepControlsAlive()
    }

    fun setOrientationMode(mode: OrientationMode) {
        _chromeState.update { it.copy(orientationMode = mode) }
        keepControlsAlive()
    }

    fun updateZoomAndPan(scale: Float, panX: Float, panY: Float) {
        _chromeState.update {
            it.copy(
                zoomScale = scale.coerceIn(1f, 4f),
                panX = if (scale <= 1.01f) 0f else panX,
                panY = if (scale <= 1.01f) 0f else panY
            )
        }
    }

    fun resetZoom() {
        _chromeState.update { it.copy(zoomScale = 1f, panX = 0f, panY = 0f) }
    }

    fun togglePlayPause(fromDoubleTap: Boolean = false) {
        serviceFlow.value?.togglePlayPause()
        if (!fromDoubleTap) keepControlsAlive()
    }

    fun seekBy(deltaMs: Long, fromDoubleTap: Boolean = false) {
        serviceFlow.value?.seekBy(deltaMs)
        if (!fromDoubleTap) keepControlsAlive()
    }

    fun seekTo(positionMs: Long, isScrubbing: Boolean) {
        serviceFlow.value?.seekTo(positionMs, isScrubbing)
        if (isScrubbing) {
            autoHideJob?.cancel()
        } else {
            scheduleAutoHide()
        }
    }

    fun playNext() {
        serviceFlow.value?.playNext()
        keepControlsAlive()
    }

    fun playPrevious() {
        serviceFlow.value?.playPrevious()
        keepControlsAlive()
    }

    fun playQueueIndex(index: Int) {
        serviceFlow.value?.playQueueIndex(index)
        keepControlsAlive()
    }

    fun removeFromQueue(index: Int) {
        serviceFlow.value?.removeFromQueue(index)
        keepControlsAlive()
    }

    fun retryCurrentItem() {
        serviceFlow.value?.retryCurrentItem()
        keepControlsAlive()
    }

    fun switchEngineManually(engine: PlayerEngineType) {
        serviceFlow.value?.switchEngineManually(engine)
        keepControlsAlive()
    }

    fun stepFrameForward() {
        serviceFlow.value?.stepFrameForward()
        keepControlsAlive()
    }

    fun setSpeed(speed: Float) {
        serviceFlow.value?.setSpeed(speed)
        keepControlsAlive()
    }

    fun setDecoderMode(mode: DecoderMode) {
        serviceFlow.value?.setDecoderMode(mode)
        keepControlsAlive()
    }

    fun cycleAspectRatio(): AspectRatioMode {
        val next = serviceFlow.value?.cycleAspectRatioMode() ?: AspectRatioMode.FIT
        keepControlsAlive()
        return next
    }

    fun setAspectRatio(mode: AspectRatioMode) {
        serviceFlow.value?.setAspectRatioMode(mode)
        keepControlsAlive()
    }

    fun toggleMute() {
        serviceFlow.value?.toggleMute()
        keepControlsAlive()
    }

    fun selectAudioTrack(track: AudioTrackInfo) {
        serviceFlow.value?.selectAudioTrack(track)
        keepControlsAlive()
    }

    fun setAudioDelayMs(delayMs: Long) {
        serviceFlow.value?.setAudioDelayMs(delayMs)
        keepControlsAlive()
    }

    fun setSubtitlesEnabled(enabled: Boolean) {
        serviceFlow.value?.setSubtitlesEnabled(enabled)
        keepControlsAlive()
    }

    fun selectSubtitleTrack(track: SubtitleTrackInfo?) {
        serviceFlow.value?.selectSubtitleTrack(track)
        keepControlsAlive()
    }

    fun addExternalSubtitle(uri: Uri, displayName: String) {
        serviceFlow.value?.addExternalSubtitle(uri, displayName)
        keepControlsAlive()
    }

    fun setSubtitleDelayMs(delayMs: Long) {
        serviceFlow.value?.setSubtitleDelayMs(delayMs)
        keepControlsAlive()
    }

    fun setSubtitleFontSizeSp(sizeSp: Int) {
        viewModelScope.launch { settingsRepo.updateSubtitleFontSizeSp(sizeSp) }
    }

    fun setSubtitleTextColorHex(colorHex: Long) {
        viewModelScope.launch { settingsRepo.updateSubtitleTextColorHex(colorHex) }
    }

    fun setSubtitleBackgroundStyle(style: SubtitleBackgroundStyle) {
        viewModelScope.launch { settingsRepo.updateSubtitleBackgroundStyle(style) }
    }

    fun setSubtitleBottomPadding(fraction: Float) {
        viewModelScope.launch { settingsRepo.updateSubtitleBottomPadding(fraction) }
    }

    fun setSubtitleEncoding(encoding: String) {
        viewModelScope.launch { settingsRepo.updateSubtitleEncoding(encoding) }
    }

    fun cycleLoopMode(): LoopMode {
        val next = serviceFlow.value?.cycleLoopMode() ?: LoopMode.OFF
        keepControlsAlive()
        return next
    }

    fun toggleShuffle(): Boolean {
        val next = serviceFlow.value?.toggleShuffle() ?: false
        keepControlsAlive()
        return next
    }

    fun toggleAbRepeat() {
        serviceFlow.value?.setAbRepeatPoint()
        keepControlsAlive()
    }

    fun clearAbRepeat() {
        serviceFlow.value?.clearAbRepeat()
        keepControlsAlive()
    }

    fun setSleepTimerMinutes(minutes: Int) {
        serviceFlow.value?.setSleepTimerMinutes(minutes)
        keepControlsAlive()
    }

    fun getMaxSystemVolume(): Int = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    fun getCurrentSystemVolume(): Int = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

    fun setCombinedVolumePercent(percent: Int) {
        val clamped = percent.coerceIn(0, 200)
        val maxVol = getMaxSystemVolume()
        if (clamped <= 100) {
            val targetStreamVol = ((clamped / 100f) * maxVol).toInt().coerceIn(0, maxVol)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetStreamVol, 0)
            serviceFlow.value?.setVolumeBoostPercent(if (clamped == 0) 0 else 100)
        } else {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxVol, 0)
            serviceFlow.value?.setVolumeBoostPercent(clamped)
        }
    }

    fun getEqualizerPresets(): List<EqualizerPreset> {
        return serviceFlow.value?.getAudioEffectsManager()?.presets ?: emptyList()
    }

    fun getEqualizerBandFreqsHz(): List<Int> {
        return serviceFlow.value?.getAudioEffectsManager()?.getBandCenterFreqHz()
            ?: listOf(60, 230, 910, 3600, 14000)
    }

    fun updateEqualizer(
        enabled: Boolean,
        presetIndex: Int,
        bandLevels: List<Int>,
        bassBoost: Int,
        virtualizer: Int
    ) {
        serviceFlow.value?.getAudioEffectsManager()?.updateEqualizer(
            enabled = enabled,
            bandNormalized = bandLevels,
            bassBoostLevel = bassBoost,
            virtualizerLevel = virtualizer
        )
        viewModelScope.launch {
            settingsRepo.updateEqualizer(enabled, presetIndex, bandLevels, bassBoost, virtualizer)
        }
    }

    fun loadCurrentVideoProperties() {
        val item = playbackState.value.currentItem ?: return
        _propertiesState.value = null to true
        viewModelScope.launch {
            val props = MediaInfoExtractor.extractProperties(
                context = getApplication(),
                uri = Uri.parse(item.uri),
                displayName = item.displayName,
                path = item.path,
                sizeBytes = item.sizeBytes,
                durationMs = item.durationMs.takeIf { it > 0L } ?: positionState.value.durationMs,
                width = item.width.takeIf { it > 0 } ?: playbackState.value.videoWidth,
                height = item.height.takeIf { it > 0 } ?: playbackState.value.videoHeight
            )
            _propertiesState.value = props to false
        }
    }

    fun dismissProperties() {
        _propertiesState.value = null to false
    }

    private fun VideoItem.toQueueItem(): PlaybackQueueItem {
        return PlaybackQueueItem(
            uri = contentUri,
            title = title,
            displayName = displayName,
            path = path,
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            width = width,
            height = height,
            mimeType = mimeType,
            folderBucketId = folderBucketId,
            isNetworkStream = false
        )
    }
}
