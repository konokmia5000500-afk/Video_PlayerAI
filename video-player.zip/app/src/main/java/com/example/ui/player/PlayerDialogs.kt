package com.example.ui.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.preferences.DecoderMode
import com.example.data.preferences.OrientationMode
import com.example.player.engine.AspectRatioMode
import com.example.player.engine.AudioTrackInfo
import com.example.player.engine.PlaybackUiState
import com.example.player.engine.PlayerEngineType
import com.example.util.CodecCapabilitiesHelper
import com.example.util.DeviceCodecSummary
import com.example.util.TimeFormatters
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SpeedDialog(
    currentSpeed: Float,
    onSelectSpeed: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    var sliderVal by remember(currentSpeed) { mutableFloatStateOf(currentSpeed) }
    val presets = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f, 4.0f)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback Speed • ${TimeFormatters.formatSpeed(sliderVal)}") },
        text = {
            Column {
                Slider(
                    value = sliderVal,
                    onValueChange = {
                        val snapped = ((it * 20f).toInt() / 20f).coerceIn(0.25f, 4.0f)
                        sliderVal = snapped
                        onSelectSpeed(snapped)
                    },
                    valueRange = 0.25f..4.0f
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    presets.forEach { preset ->
                        FilterChip(
                            selected = kotlin.math.abs(sliderVal - preset) < 0.03f,
                            onClick = {
                                sliderVal = preset
                                onSelectSpeed(preset)
                            },
                            label = { Text(TimeFormatters.formatSpeed(preset)) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}

@Composable
fun DecoderDialog(
    currentMode: DecoderMode,
    currentEngine: PlayerEngineType,
    onSelectMode: (DecoderMode) -> Unit,
    onSwitchEngine: (PlayerEngineType) -> Unit,
    onShowDecoderInfo: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Decoder & Engine") },
        text = {
            Column {
                DecoderMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectMode(mode)
                                onDismiss()
                            }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = currentMode == mode,
                            onClick = {
                                onSelectMode(mode)
                                onDismiss()
                            }
                        )
                        Text(mode.label, modifier = Modifier.padding(start = 8.dp))
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Playback Engine",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                PlayerEngineType.entries.forEach { engine ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSwitchEngine(engine)
                                onDismiss()
                            }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = currentEngine == engine,
                            onClick = {
                                onSwitchEngine(engine)
                                onDismiss()
                            }
                        )
                        Text(engine.label, modifier = Modifier.padding(start = 8.dp))
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onShowDecoderInfo()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("View Device Codec & Decoder Info")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}

@Composable
fun DecoderInfoDialog(
    playbackState: PlaybackUiState,
    onDismiss: () -> Unit
) {
    var codecs by remember { mutableStateOf<List<DeviceCodecSummary>>(emptyList()) }
    LaunchedEffect(Unit) {
        codecs = CodecCapabilitiesHelper.listVideoAndAudioDecoders()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.decoder_info)) },
        text = {
            Column {
                Text(
                    text = "Active Session",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("Engine: ${playbackState.engineType.label}")
                Text("Decoder Mode: ${playbackState.decoderMode.label}")
                if (playbackState.activeVideoCodec.isNotBlank()) {
                    Text("Video Stream: ${playbackState.activeVideoCodec}")
                }
                if (playbackState.activeAudioCodec.isNotBlank()) {
                    Text("Audio Stream: ${playbackState.activeAudioCodec}")
                }
                if (playbackState.videoWidth > 0 && playbackState.videoHeight > 0) {
                    Text("Resolution: ${playbackState.videoWidth}x${playbackState.videoHeight}")
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))
                Text(
                    text = "Available MediaCodec Decoders (${codecs.size})",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyColumn(modifier = Modifier.height(220.dp)) {
                    items(codecs, key = { it.name }) { codec ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(
                                text = "${if (codec.isHardwareAccelerated) "[HW]" else "[SW]"} ${codec.name}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = codec.mimeTypes.joinToString(", "),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}

@Composable
fun AudioSyncDialog(
    currentDelayMs: Long,
    onDelayChangeMs: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Audio Synchronization") },
        text = {
            Column {
                Text(
                    text = "Offset: ${String.format(Locale.US, "%+d ms", currentDelayMs)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Non-zero offsets automatically use LibVLC precision audio synchronization.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Slider(
                    value = currentDelayMs.toFloat(),
                    onValueChange = { onDelayChangeMs((it / 50f).toLong() * 50L) },
                    valueRange = -5000f..5000f
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = { onDelayChangeMs(currentDelayMs - 100L) }) { Text("-100ms") }
                    TextButton(onClick = { onDelayChangeMs(0L) }) { Text(stringResource(R.string.reset)) }
                    TextButton(onClick = { onDelayChangeMs(currentDelayMs + 100L) }) { Text("+100ms") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}

@Composable
fun AudioTrackDialog(
    tracks: List<AudioTrackInfo>,
    onSelectTrack: (AudioTrackInfo) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.audio_track)) },
        text = {
            if (tracks.isEmpty()) {
                Text("Only default audio track is available.")
            } else {
                Column {
                    tracks.forEach { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectTrack(track)
                                    onDismiss()
                                }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = track.isSelected,
                                onClick = {
                                    onSelectTrack(track)
                                    onDismiss()
                                }
                            )
                            Text(track.label, modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}

@Composable
fun AspectRatioDialog(
    currentMode: AspectRatioMode,
    onSelectMode: (AspectRatioMode) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.aspect_ratio)) },
        text = {
            Column {
                AspectRatioMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectMode(mode)
                                onDismiss()
                            }
                            .padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = currentMode == mode,
                            onClick = {
                                onSelectMode(mode)
                                onDismiss()
                            }
                        )
                        Text(mode.label, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}

@Composable
fun OrientationDialog(
    currentMode: OrientationMode,
    onSelectMode: (OrientationMode) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Screen Rotation") },
        text = {
            Column {
                OrientationMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectMode(mode)
                                onDismiss()
                            }
                            .padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = currentMode == mode,
                            onClick = {
                                onSelectMode(mode)
                                onDismiss()
                            }
                        )
                        Text(mode.label, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}

@Composable
fun SleepTimerDialog(
    currentRemainingMs: Long,
    onSetMinutes: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val options = listOf(0, 5, 10, 15, 30, 45, 60, 90)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.sleep_timer)) },
        text = {
            Column {
                if (currentRemainingMs > 0L) {
                    Text(
                        text = "Remaining: ${TimeFormatters.formatDuration(currentRemainingMs)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                options.forEach { minutes ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSetMinutes(minutes)
                                onDismiss()
                            }
                            .padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (minutes == 0) "Off" else "$minutes minutes",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}
