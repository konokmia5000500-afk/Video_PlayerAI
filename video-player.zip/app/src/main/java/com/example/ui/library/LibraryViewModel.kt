package com.example.ui.library

import android.app.Application
import android.content.IntentSender
import android.net.Uri
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.data.mediastore.MediaOperationResult
import com.example.data.model.FolderItem
import com.example.data.model.LibraryLayoutMode
import com.example.data.model.LibraryViewMode
import com.example.data.model.SortDirection
import com.example.data.model.SortField
import com.example.data.model.VideoItem
import com.example.data.model.VideoProperties
import com.example.data.preferences.PlayerSettings
import com.example.util.MediaInfoExtractor
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@Immutable
data class LibraryUiState(
    val settings: PlayerSettings = PlayerSettings(),
    val folders: List<FolderItem> = emptyList(),
    val videos: List<VideoItem> = emptyList(),
    val selectedFolderBucketId: String? = null,
    val selectedFolderName: String? = null,
    val searchQuery: String = "",
    val isSearchActive: Boolean = false,
    val isRefreshing: Boolean = false,
    val hasStoragePermission: Boolean = false,
    val selectedVideoIds: Set<Long> = emptySet(),
    val selectedFolderIds: Set<String> = emptySet(),
    val propertiesVideo: VideoProperties? = null,
    val isLoadingProperties: Boolean = false
) {
    val isMultiSelectActive: Boolean
        get() = selectedVideoIds.isNotEmpty() || selectedFolderIds.isNotEmpty()
}

sealed interface LibraryEvent {
    data class LaunchIntentSender(
        val intentSender: IntentSender,
        val pendingRenameVideo: VideoItem? = null,
        val pendingRenameBaseName: String? = null
    ) : LibraryEvent
    data class ShowMessage(val message: String) : LibraryEvent
}

class LibraryViewModel(application: Application) : AndroidViewModel(application) {

    private val container = AppContainer.getInstance(application)
    private val repository = container.videoLibraryRepository
    private val settingsRepo = container.settingsRepository

    private val selectedFolderBucketId = MutableStateFlow<String?>(null)
    private val searchQuery = MutableStateFlow("")
    private val isSearchActive = MutableStateFlow(false)
    private val isRefreshing = MutableStateFlow(false)
    private val hasPermission = MutableStateFlow(false)
    private val selectedVideoIds = MutableStateFlow<Set<Long>>(emptySet())
    private val selectedFolderIds = MutableStateFlow<Set<String>>(emptySet())
    private val propertiesState = MutableStateFlow<Pair<VideoProperties?, Boolean>>(null to false)

    private val _events = MutableSharedFlow<LibraryEvent>()
    val events: SharedFlow<LibraryEvent> = _events.asSharedFlow()

    val uiState: StateFlow<LibraryUiState> = combine(
        settingsRepo.settingsFlow,
        repository.videosFlow,
        repository.hiddenFolderIdsFlow,
        selectedFolderBucketId,
        searchQuery,
        isSearchActive,
        isRefreshing,
        hasPermission,
        selectedVideoIds,
        selectedFolderIds,
        propertiesState
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val settings = values[0] as PlayerSettings
        @Suppress("UNCHECKED_CAST")
        val allVideos = values[1] as List<VideoItem>
        @Suppress("UNCHECKED_CAST")
        val hiddenIds = values[2] as Set<String>
        val activeBucketId = values[3] as String?
        val query = values[4] as String
        val searchOpen = values[5] as Boolean
        val refreshing = values[6] as Boolean
        val granted = values[7] as Boolean
        @Suppress("UNCHECKED_CAST")
        val selVideos = values[8] as Set<Long>
        @Suppress("UNCHECKED_CAST")
        val selFolders = values[9] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val propsPair = values[10] as Pair<VideoProperties?, Boolean>

        val visibleVideos = if (settings.showHiddenFolders) {
            allVideos
        } else {
            allVideos.filter { it.folderBucketId !in hiddenIds }
        }

        val folderFilteredVideos = if (activeBucketId != null) {
            allVideos.filter { it.folderBucketId == activeBucketId }
        } else {
            visibleVideos
        }

        val queryTrimmed = query.trim().lowercase()
        val filteredVideos = if (queryTrimmed.isEmpty()) {
            folderFilteredVideos
        } else {
            folderFilteredVideos.filter {
                it.title.lowercase().contains(queryTrimmed) ||
                    it.displayName.lowercase().contains(queryTrimmed) ||
                    it.folderName.lowercase().contains(queryTrimmed)
            }
        }

        val sortedVideos = sortVideos(filteredVideos, settings.sortField, settings.sortDirection)

        val rawFolders = repository.buildFolders(allVideos, hiddenIds)
        val visibleFolders = if (settings.showHiddenFolders) {
            rawFolders
        } else {
            rawFolders.filterNot { it.isHidden }
        }
        val filteredFolders = if (queryTrimmed.isEmpty()) {
            visibleFolders
        } else {
            visibleFolders.filter { it.name.lowercase().contains(queryTrimmed) }
        }
        val sortedFolders = sortFolders(filteredFolders, settings.sortField, settings.sortDirection)

        val folderName = activeBucketId?.let { id ->
            allVideos.firstOrNull { it.folderBucketId == id }?.folderName
        }

        LibraryUiState(
            settings = settings,
            folders = sortedFolders,
            videos = sortedVideos,
            selectedFolderBucketId = activeBucketId,
            selectedFolderName = folderName,
            searchQuery = query,
            isSearchActive = searchOpen,
            isRefreshing = refreshing,
            hasStoragePermission = granted,
            selectedVideoIds = selVideos,
            selectedFolderIds = selFolders,
            propertiesVideo = propsPair.first,
            isLoadingProperties = propsPair.second
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = LibraryUiState()
    )

    private var observingMediaChanges = false

    fun onPermissionStatusChanged(granted: Boolean) {
        hasPermission.value = granted
        if (granted) {
            refreshLibrary()
            startObservingMediaChanges()
        }
    }

    private fun startObservingMediaChanges() {
        if (observingMediaChanges) return
        observingMediaChanges = true
        viewModelScope.launch {
            repository.mediaChangesFlow.collect {
                if (hasPermission.value) {
                    repository.refreshFromMediaStore()
                }
            }
        }
    }

    fun refreshLibrary() {
        if (!hasPermission.value) return
        viewModelScope.launch {
            isRefreshing.value = true
            runCatching { repository.refreshFromMediaStore() }
            isRefreshing.value = false
        }
    }

    fun openFolder(folder: FolderItem) {
        selectedVideoIds.value = emptySet()
        selectedFolderIds.value = emptySet()
        selectedFolderBucketId.value = folder.bucketId
    }

    fun closeFolder(): Boolean {
        if (selectedFolderBucketId.value != null) {
            selectedFolderBucketId.value = null
            selectedVideoIds.value = emptySet()
            return true
        }
        return false
    }

    fun setViewMode(mode: LibraryViewMode) {
        selectedFolderBucketId.value = null
        clearSelection()
        viewModelScope.launch { settingsRepo.updateLibraryViewMode(mode) }
    }

    fun toggleLayoutMode() {
        val next = if (uiState.value.settings.libraryLayoutMode == LibraryLayoutMode.LIST) {
            LibraryLayoutMode.GRID
        } else {
            LibraryLayoutMode.LIST
        }
        viewModelScope.launch { settingsRepo.updateLibraryLayoutMode(next) }
    }

    fun updateSort(field: SortField, direction: SortDirection) {
        viewModelScope.launch { settingsRepo.updateSort(field, direction) }
    }

    fun setSearchActive(active: Boolean) {
        isSearchActive.value = active
        if (!active) searchQuery.value = ""
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun toggleVideoSelection(videoId: Long) {
        val current = selectedVideoIds.value
        selectedVideoIds.value = if (videoId in current) current - videoId else current + videoId
    }

    fun toggleFolderSelection(bucketId: String) {
        val current = selectedFolderIds.value
        selectedFolderIds.value = if (bucketId in current) current - bucketId else current + bucketId
    }

    fun selectAllVisible() {
        val state = uiState.value
        if (state.selectedFolderBucketId != null || state.settings.libraryViewMode == LibraryViewMode.FILES) {
            selectedVideoIds.value = state.videos.mapTo(HashSet()) { it.id }
        } else {
            selectedFolderIds.value = state.folders.mapTo(HashSet()) { it.bucketId }
        }
    }

    fun clearSelection() {
        selectedVideoIds.value = emptySet()
        selectedFolderIds.value = emptySet()
    }

    fun hideOrUnhideSelectedFolders() {
        val ids = selectedFolderIds.value.toList()
        if (ids.isEmpty()) return
        val hiddenMap = uiState.value.folders.associateBy { it.bucketId }
        viewModelScope.launch {
            ids.forEach { bucketId ->
                val isHidden = hiddenMap[bucketId]?.isHidden == true
                if (isHidden) {
                    repository.unhideFolder(bucketId)
                } else {
                    repository.hideFolder(bucketId)
                }
            }
            clearSelection()
            _events.emit(LibraryEvent.ShowMessage("Folder visibility updated"))
        }
    }

    fun toggleFolderHidden(folder: FolderItem) {
        viewModelScope.launch {
            if (folder.isHidden) {
                repository.unhideFolder(folder.bucketId)
                _events.emit(LibraryEvent.ShowMessage("Unhid ${folder.name}"))
            } else {
                repository.hideFolder(folder.bucketId)
                _events.emit(LibraryEvent.ShowMessage("Hid ${folder.name}"))
            }
        }
    }

    fun toggleShowHiddenFolders() {
        val next = !uiState.value.settings.showHiddenFolders
        viewModelScope.launch { settingsRepo.updateShowHiddenFolders(next) }
    }

    fun deleteSelectedVideos() {
        val selected = uiState.value.videos.filter { it.id in selectedVideoIds.value }
        if (selected.isEmpty()) return
        viewModelScope.launch {
            when (val res = repository.deleteVideos(selected)) {
                is MediaOperationResult.Success -> {
                    clearSelection()
                    _events.emit(LibraryEvent.ShowMessage("Deleted ${selected.size} video(s)"))
                }
                is MediaOperationResult.NeedsApproval -> {
                    _events.emit(LibraryEvent.LaunchIntentSender(res.intentSender))
                }
                is MediaOperationResult.Failure -> {
                    _events.emit(LibraryEvent.ShowMessage(res.message))
                }
            }
        }
    }

    fun onMediaPermissionApproved(pendingRenameVideo: VideoItem?, pendingRenameBaseName: String?) {
        if (pendingRenameVideo != null && pendingRenameBaseName != null) {
            renameVideo(pendingRenameVideo, pendingRenameBaseName)
        } else {
            clearSelection()
            refreshLibrary()
        }
    }

    fun renameVideo(video: VideoItem, newBaseName: String) {
        viewModelScope.launch {
            when (val res = repository.renameVideo(video, newBaseName)) {
                is MediaOperationResult.Success -> {
                    clearSelection()
                    refreshLibrary()
                    _events.emit(LibraryEvent.ShowMessage("Video renamed"))
                }
                is MediaOperationResult.NeedsApproval -> {
                    _events.emit(
                        LibraryEvent.LaunchIntentSender(
                            intentSender = res.intentSender,
                            pendingRenameVideo = video,
                            pendingRenameBaseName = newBaseName
                        )
                    )
                }
                is MediaOperationResult.Failure -> {
                    _events.emit(LibraryEvent.ShowMessage(res.message))
                }
            }
        }
    }

    fun loadProperties(video: VideoItem) {
        propertiesState.value = null to true
        viewModelScope.launch {
            val props = MediaInfoExtractor.extractProperties(
                context = getApplication(),
                uri = Uri.parse(video.contentUri),
                displayName = video.displayName,
                path = video.path,
                sizeBytes = video.sizeBytes,
                durationMs = video.durationMs,
                width = video.width,
                height = video.height
            )
            propertiesState.value = props to false
        }
    }

    fun dismissProperties() {
        propertiesState.value = null to false
    }

    fun addRecentNetworkUrl(url: String) {
        viewModelScope.launch {
            settingsRepo.addRecentNetworkUrl(url)
        }
    }

    private fun sortVideos(
        list: List<VideoItem>,
        field: SortField,
        direction: SortDirection
    ): List<VideoItem> {
        val comparator: Comparator<VideoItem> = when (field) {
            SortField.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.title }
            SortField.DATE -> compareBy { it.dateAddedSec }
            SortField.SIZE -> compareBy { it.sizeBytes }
            SortField.DURATION -> compareBy { it.durationMs }
            SortField.RESOLUTION -> compareBy { it.resolutionScore }
        }
        return if (direction == SortDirection.ASC) {
            list.sortedWith(comparator)
        } else {
            list.sortedWith(comparator.reversed())
        }
    }

    private fun sortFolders(
        list: List<FolderItem>,
        field: SortField,
        direction: SortDirection
    ): List<FolderItem> {
        val comparator: Comparator<FolderItem> = when (field) {
            SortField.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            SortField.DATE -> compareBy { it.latestAddedSec }
            SortField.SIZE -> compareBy { it.totalSizeBytes }
            SortField.DURATION, SortField.RESOLUTION -> compareBy { it.videoCount }
        }
        return if (direction == SortDirection.ASC) {
            list.sortedWith(comparator)
        } else {
            list.sortedWith(comparator.reversed())
        }
    }
}
