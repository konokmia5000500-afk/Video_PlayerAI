package com.example.ui.home

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.data.model.LibrarySummary
import com.example.data.model.VideoItem
import com.example.data.model.WatchHistoryItem
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@Immutable
data class HomeDashboardState(
    val resumeCandidate: WatchHistoryItem? = null,
    val continueWatching: List<WatchHistoryItem> = emptyList(),
    val recentlyPlayed: List<WatchHistoryItem> = emptyList(),
    val recentlyAdded: List<VideoItem> = emptyList(),
    val frequentlyPlayed: List<VideoItem> = emptyList(),
    val summary: LibrarySummary = LibrarySummary()
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppContainer.getInstance(application).videoLibraryRepository

    val dashboardState: StateFlow<HomeDashboardState> = combine(
        repository.resumeCandidateFlow,
        repository.continueWatchingFlow,
        repository.watchHistoryFlow,
        repository.videosFlow,
        repository.librarySummaryFlow,
        repository.hiddenFolderIdsFlow
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val resume = values[0] as WatchHistoryItem?
        @Suppress("UNCHECKED_CAST")
        val continueList = values[1] as List<WatchHistoryItem>
        @Suppress("UNCHECKED_CAST")
        val history = values[2] as List<WatchHistoryItem>
        @Suppress("UNCHECKED_CAST")
        val allVideos = values[3] as List<VideoItem>
        val summary = values[4] as LibrarySummary
        @Suppress("UNCHECKED_CAST")
        val hiddenIds = values[5] as Set<String>

        val visibleVideos = allVideos.filter { it.folderBucketId !in hiddenIds }
        val recentlyAdded = visibleVideos
            .sortedByDescending { it.dateAddedSec }
            .take(12)
        val frequentlyPlayed = visibleVideos
            .filter { it.playCount >= 2 }
            .sortedByDescending { it.playCount }
            .take(12)

        HomeDashboardState(
            resumeCandidate = resume,
            continueWatching = continueList,
            recentlyPlayed = history.take(12),
            recentlyAdded = recentlyAdded,
            frequentlyPlayed = frequentlyPlayed,
            summary = summary
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = HomeDashboardState()
    )

    fun dismissResumeCard(mediaKey: String) {
        viewModelScope.launch {
            repository.dismissFromResume(mediaKey)
        }
    }
}
