package com.example.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.preferences.PlayerSettings
import com.example.data.preferences.SubtitleBackgroundStyle
import kotlinx.coroutines.flow.StateFlow

/**
 * Isolated subtitle cue renderer driven by [activeSubtitleFlow] so 120ms subtitle updates
 * never trigger recomposition of the video surface or control chrome.
 */
@Composable
fun SubtitleOverlay(
    activeSubtitleFlow: StateFlow<String?>,
    settings: PlayerSettings,
    controlsVisible: Boolean,
    modifier: Modifier = Modifier
) {
    val cueText by activeSubtitleFlow.collectAsStateWithLifecycle()
    val text = cueText?.takeIf { it.isNotBlank() } ?: return

    val textColor = Color(settings.subtitleTextColorHex)
    val baseFraction = settings.subtitleBottomPaddingFraction.coerceIn(0.02f, 0.25f)
    val bottomPaddingDp = ((baseFraction * 420f) + if (controlsVisible) 88f else 18f).dp

    val shadow = if (
        settings.subtitleBackgroundStyle == SubtitleBackgroundStyle.OUTLINE_SHADOW ||
        settings.subtitleBackgroundStyle == SubtitleBackgroundStyle.NONE
    ) {
        Shadow(
            color = Color.Black.copy(alpha = 0.92f),
            offset = Offset(1.5f, 2f),
            blurRadius = 5f
        )
    } else null

    val containerModifier = when (settings.subtitleBackgroundStyle) {
        SubtitleBackgroundStyle.NONE,
        SubtitleBackgroundStyle.OUTLINE_SHADOW -> Modifier.padding(horizontal = 16.dp)
        SubtitleBackgroundStyle.SEMI_BLACK -> Modifier
            .padding(horizontal = 16.dp)
            .background(Color.Black.copy(alpha = 0.68f), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
        SubtitleBackgroundStyle.SOLID_NAVY -> Modifier
            .padding(horizontal = 16.dp)
            .background(Color(0xD90A1D3A), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 7.dp)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(bottom = bottomPaddingDp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(
            modifier = containerModifier,
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                textAlign = TextAlign.Center,
                style = TextStyle(
                    color = textColor,
                    fontSize = settings.subtitleFontSizeSp.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = (settings.subtitleFontSizeSp + 6).sp,
                    shadow = shadow
                ),
                modifier = Modifier.fillMaxWidth(0.92f)
            )
        }
    }
}
