package com.example.ui.library

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.AppContainer
import com.example.R
import com.example.data.model.FolderItem
import com.example.data.model.LibraryLayoutMode
import com.example.data.model.VideoItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryTabContent(
    state: LibraryUiState,
    showFolders: Boolean,
    onRefresh: () -> Unit,
    onRequestPermission: () -> Unit,
    onPickVideoFile: () -> Unit,
    onOpenNetworkTab: () -> Unit,
    onFolderClick: (FolderItem) -> Unit,
    onFolderLongClick: (FolderItem) -> Unit,
    onPlayFolder: (FolderItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onVideoLongClick: (VideoItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val imageLoader = remember(context) { AppContainer.getInstance(context).imageLoader }

    val showingVideos = !showFolders || state.selectedFolderBucketId != null

    if (!state.hasStoragePermission && state.videos.isEmpty()) {
        PermissionEmptyState(
            onRequestPermission = onRequestPermission,
            onOpenSettings = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", context.packageName, null)
                    }
                )
            },
            onPickVideoFile = onPickVideoFile,
            onOpenStream = onOpenNetworkTab,
            modifier = modifier
        )
    } else {
        PullToRefreshBox(
            isRefreshing = state.isRefreshing,
            onRefresh = onRefresh,
            modifier = modifier.fillMaxSize()
        ) {
            if (showingVideos && state.videos.isEmpty()) {
                EmptyVideosView(
                    onOpenStream = onOpenNetworkTab,
                    onPickFile = onPickVideoFile
                )
            } else if (!showingVideos && state.folders.isEmpty()) {
                EmptyVideosView(
                    onOpenStream = onOpenNetworkTab,
                    onPickFile = onPickVideoFile
                )
            } else {
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val columns = when {
                        maxWidth >= 840.dp -> 4
                        maxWidth >= 600.dp -> 3
                        else -> 2
                    }
                    if (state.settings.libraryLayoutMode == LibraryLayoutMode.GRID) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(columns),
                            contentPadding = PaddingValues(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (!showingVideos) {
                                items(
                                    items = state.folders,
                                    key = { it.bucketId },
                                    contentType = { "folder_grid" }
                                ) { folder ->
                                    FolderGridCard(
                                        folder = folder,
                                        isSelected = folder.bucketId in state.selectedFolderIds,
                                        showThumbnails = state.settings.showThumbnails,
                                        imageLoader = imageLoader,
                                        onClick = { onFolderClick(folder) },
                                        onLongClick = { onFolderLongClick(folder) }
                                    )
                                }
                            } else {
                                items(
                                    items = state.videos,
                                    key = { it.id },
                                    contentType = { "video_grid" }
                                ) { video ->
                                    VideoGridCard(
                                        video = video,
                                        isSelected = video.id in state.selectedVideoIds,
                                        showThumbnails = state.settings.showThumbnails,
                                        imageLoader = imageLoader,
                                        onClick = { onVideoClick(video) },
                                        onLongClick = { onVideoLongClick(video) }
                                    )
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(top = 6.dp, bottom = 24.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (!showingVideos) {
                                items(
                                    items = state.folders,
                                    key = { it.bucketId },
                                    contentType = { "folder_row" }
                                ) { folder ->
                                    FolderListRow(
                                        folder = folder,
                                        isSelected = folder.bucketId in state.selectedFolderIds,
                                        showThumbnails = state.settings.showThumbnails,
                                        imageLoader = imageLoader,
                                        onClick = { onFolderClick(folder) },
                                        onLongClick = { onFolderLongClick(folder) },
                                        onPlayFolder = { onPlayFolder(folder) }
                                    )
                                }
                            } else {
                                items(
                                    items = state.videos,
                                    key = { it.id },
                                    contentType = { "video_row" }
                                ) { video ->
                                    VideoListRow(
                                        video = video,
                                        isSelected = video.id in state.selectedVideoIds,
                                        showThumbnails = state.settings.showThumbnails,
                                        imageLoader = imageLoader,
                                        onClick = { onVideoClick(video) },
                                        onLongClick = { onVideoLongClick(video) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionEmptyState(
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit,
    onPickVideoFile: () -> Unit,
    onOpenStream: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.VideoLibrary,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.permission_required_title),
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.permission_required_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = onRequestPermission,
            modifier = Modifier.testTag("grant_permission_button")
        ) {
            Text(stringResource(R.string.grant_permission))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onOpenSettings) {
                Text(stringResource(R.string.open_app_settings))
            }
            OutlinedButton(onClick = onPickVideoFile) {
                Text(stringResource(R.string.pick_video_file))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        TextButton(onClick = onOpenStream) {
            Text(stringResource(R.string.open_network_stream))
        }
    }
}

@Composable
private fun EmptyVideosView(
    onOpenStream: () -> Unit,
    onPickFile: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.VideoLibrary,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = stringResource(R.string.no_videos_found),
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = stringResource(R.string.no_videos_tip),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onPickFile) {
                Text(stringResource(R.string.pick_video_file))
            }
            Button(onClick = onOpenStream) {
                Text(stringResource(R.string.open_network_stream))
            }
        }
    }
}

fun shareVideos(context: Context, videos: List<VideoItem>) {
    val uris = ArrayList<Uri>(videos.size).apply {
        videos.forEach { add(Uri.parse(it.contentUri)) }
    }
    val intent = if (uris.size == 1) {
        Intent(Intent.ACTION_SEND).apply {
            type = "video/*"
            putExtra(Intent.EXTRA_STREAM, uris.first())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "video/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
    context.startActivity(Intent.createChooser(intent, "Share video"))
}
