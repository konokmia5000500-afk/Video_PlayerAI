package com.example.ui.library

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.AppContainer
import com.example.R
import com.example.data.model.LibraryLayoutMode
import com.example.data.model.LibraryViewMode
import com.example.data.model.VideoItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    onPlayVideo: (video: VideoItem) -> Unit,
    onPlayStreamUrl: (url: String) -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: LibraryViewModel = viewModel()
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val imageLoader = remember(context) { AppContainer.getInstance(context).imageLoader }
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    val requiredPermission = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    var pendingRenameVideo by remember { mutableStateOf<VideoItem?>(null) }
    var pendingRenameBaseName by remember { mutableStateOf<String?>(null) }

    var showSortDialog by remember { mutableStateOf(false) }
    var showStreamDialog by remember { mutableStateOf(false) }
    var showRenameDialogFor by remember { mutableStateOf<VideoItem?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.onPermissionStatusChanged(granted)
    }

    val intentSenderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.onMediaPermissionApproved(pendingRenameVideo, pendingRenameBaseName)
        }
        pendingRenameVideo = null
        pendingRenameBaseName = null
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            onPlayStreamUrl(uri.toString())
        }
    }

    DisposableEffect(lifecycleOwner, requiredPermission) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    requiredPermission
                ) == PackageManager.PERMISSION_GRANTED
                viewModel.onPermissionStatusChanged(granted)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(requiredPermission) {
        val granted = ContextCompat.checkSelfPermission(
            context,
            requiredPermission
        ) == PackageManager.PERMISSION_GRANTED
        viewModel.onPermissionStatusChanged(granted)
        if (!granted) {
            permissionLauncher.launch(requiredPermission)
        }
    }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is LibraryEvent.LaunchIntentSender -> {
                    pendingRenameVideo = event.pendingRenameVideo
                    pendingRenameBaseName = event.pendingRenameBaseName
                    intentSenderLauncher.launch(
                        IntentSenderRequest.Builder(event.intentSender).build()
                    )
                }
                is LibraryEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(event.message)
                }
            }
        }
    }

    BackHandler(enabled = state.isMultiSelectActive || state.isSearchActive || state.selectedFolderBucketId != null) {
        when {
            state.isMultiSelectActive -> viewModel.clearSelection()
            state.isSearchActive -> viewModel.setSearchActive(false)
            state.selectedFolderBucketId != null -> viewModel.closeFolder()
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (state.isMultiSelectActive) {
                val totalSelected = state.selectedVideoIds.size + state.selectedFolderIds.size
                val selectedVideos = state.videos.filter { it.id in state.selectedVideoIds }
                TopAppBar(
                    title = { Text("$totalSelected selected") },
                    navigationIcon = {
                        IconButton(onClick = viewModel::clearSelection) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear selection")
                        }
                    },
                    actions = {
                        IconButton(onClick = viewModel::selectAllVisible) {
                            Icon(Icons.Filled.SelectAll, contentDescription = "Select all")
                        }
                        if (selectedVideos.isNotEmpty()) {
                            IconButton(
                                onClick = { shareVideos(context, selectedVideos) },
                                modifier = Modifier.testTag("action_share")
                            ) {
                                Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.share))
                            }
                            if (selectedVideos.size == 1) {
                                IconButton(
                                    onClick = { showRenameDialogFor = selectedVideos.first() },
                                    modifier = Modifier.testTag("action_rename")
                                ) {
                                    Icon(
                                        Icons.Filled.DriveFileRenameOutline,
                                        contentDescription = stringResource(R.string.rename)
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.loadProperties(selectedVideos.first()) },
                                    modifier = Modifier.testTag("action_properties")
                                ) {
                                    Icon(Icons.Filled.Info, contentDescription = stringResource(R.string.properties))
                                }
                            }
                            IconButton(
                                onClick = { showDeleteConfirm = true },
                                modifier = Modifier.testTag("action_delete")
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete))
                            }
                        }
                        if (state.selectedFolderIds.isNotEmpty()) {
                            IconButton(
                                onClick = viewModel::hideOrUnhideSelectedFolders,
                                modifier = Modifier.testTag("action_toggle_hide_folder")
                            ) {
                                Icon(
                                    Icons.Filled.VisibilityOff,
                                    contentDescription = stringResource(R.string.hide_folder)
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHighest
                    )
                )
            } else if (state.isSearchActive) {
                TopAppBar(
                    title = {
                        TextField(
                            value = state.searchQuery,
                            onValueChange = viewModel::updateSearchQuery,
                            placeholder = { Text(stringResource(R.string.search_hint)) },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_input")
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.setSearchActive(false) }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close search")
                        }
                    },
                    actions = {
                        if (state.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear")
                            }
                        }
                    }
                )
            } else {
                TopAppBar(
                    title = {
                        Text(
                            text = state.selectedFolderName ?: stringResource(R.string.app_name),
                            maxLines = 1
                        )
                    },
                    navigationIcon = {
                        if (state.selectedFolderBucketId != null) {
                            IconButton(onClick = { viewModel.closeFolder() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to folders")
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.setSearchActive(true) },
                            modifier = Modifier.testTag("search_button")
                        ) {
                            Icon(Icons.Filled.Search, contentDescription = "Search")
                        }
                        IconButton(
                            onClick = viewModel::toggleLayoutMode,
                            modifier = Modifier.testTag("layout_toggle_button")
                        ) {
                            val isGrid = state.settings.libraryLayoutMode == LibraryLayoutMode.GRID
                            Icon(
                                imageVector = if (isGrid) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.GridView,
                                contentDescription = "Toggle grid or list"
                            )
                        }
                        IconButton(
                            onClick = { showSortDialog = true },
                            modifier = Modifier.testTag("sort_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort")
                        }
                        Box {
                            IconButton(
                                onClick = { showOverflowMenu = true },
                                modifier = Modifier.testTag("library_more_button")
                            ) {
                                Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                            }
                            DropdownMenu(
                                expanded = showOverflowMenu,
                                onDismissRequest = { showOverflowMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.open_network_stream)) },
                                    leadingIcon = { Icon(Icons.Filled.Link, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        showStreamDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.pick_video_file)) },
                                    leadingIcon = { Icon(Icons.Filled.FolderOpen, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        filePickerLauncher.launch(arrayOf("video/*"))
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (state.settings.showHiddenFolders) "Hide hidden folders" else "Show hidden folders"
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            if (state.settings.showHiddenFolders) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                            contentDescription = null
                                        )
                                    },
                                    onClick = {
                                        showOverflowMenu = false
                                        viewModel.toggleShowHiddenFolders()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.settings_title)) },
                                    leadingIcon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        onOpenSettings()
                                    }
                                )
                            }
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            if (!state.isMultiSelectActive) {
                FloatingActionButton(
                    onClick = { showStreamDialog = true },
                    modifier = Modifier.testTag("fab_network_stream")
                ) {
                    Icon(Icons.Filled.Link, contentDescription = stringResource(R.string.open_network_stream))
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (state.selectedFolderBucketId == null) {
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    SegmentedButton(
                        selected = state.settings.libraryViewMode == LibraryViewMode.FOLDERS,
                        onClick = { viewModel.setViewMode(LibraryViewMode.FOLDERS) },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("tab_folders")
                    ) {
                        Text(stringResource(R.string.folders_tab))
                    }
                    SegmentedButton(
                        selected = state.settings.libraryViewMode == LibraryViewMode.FILES,
                        onClick = { viewModel.setViewMode(LibraryViewMode.FILES) },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("tab_all_videos")
                    ) {
                        Text(stringResource(R.string.all_videos_tab))
                    }
                }
            }

            if (!state.hasStoragePermission && state.videos.isEmpty()) {
                PermissionEmptyState(
                    onRequestPermission = { permissionLauncher.launch(requiredPermission) },
                    onOpenSettings = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                        )
                    },
                    onPickVideoFile = { filePickerLauncher.launch(arrayOf("video/*")) },
                    onOpenStream = { showStreamDialog = true }
                )
            } else {
                PullToRefreshBox(
                    isRefreshing = state.isRefreshing,
                    onRefresh = viewModel::refreshLibrary,
                    modifier = Modifier.fillMaxSize()
                ) {
                    val showingVideos = state.selectedFolderBucketId != null ||
                        state.settings.libraryViewMode == LibraryViewMode.FILES

                    if (showingVideos && state.videos.isEmpty()) {
                        EmptyVideosView(
                            onOpenStream = { showStreamDialog = true },
                            onPickFile = { filePickerLauncher.launch(arrayOf("video/*")) }
                        )
                    } else if (!showingVideos && state.folders.isEmpty()) {
                        EmptyVideosView(
                            onOpenStream = { showStreamDialog = true },
                            onPickFile = { filePickerLauncher.launch(arrayOf("video/*")) }
                        )
                    } else {
                        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                            val columns = when {
                                maxWidth >= 840.dp -> 4
                                maxWidth >= 600.dp -> 3
                                else -> 2
                            }
                            if (state.settings.libraryLayoutMode == LibraryLayoutMode.GRID) {
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(columns),
                                    contentPadding = PaddingValues(12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    if (!showingVideos) {
                                        items(
                                            items = state.folders,
                                            key = { it.bucketId },
                                            contentType = { "folder_grid" }
                                        ) { folder ->
                                            FolderGridCard(
                                                folder = folder,
                                                isSelected = folder.bucketId in state.selectedFolderIds,
                                                imageLoader = imageLoader,
                                                onClick = {
                                                    if (state.isMultiSelectActive) {
                                                        viewModel.toggleFolderSelection(folder.bucketId)
                                                    } else {
                                                        viewModel.openFolder(folder)
                                                    }
                                                },
                                                onLongClick = { viewModel.toggleFolderSelection(folder.bucketId) }
                                            )
                                        }
                                    } else {
                                        items(
                                            items = state.videos,
                                            key = { it.id },
                                            contentType = { "video_grid" }
                                        ) { video ->
                                            VideoGridCard(
                                                video = video,
                                                isSelected = video.id in state.selectedVideoIds,
                                                imageLoader = imageLoader,
                                                onClick = {
                                                    if (state.isMultiSelectActive) {
                                                        viewModel.toggleVideoSelection(video.id)
                                                    } else {
                                                        onPlayVideo(video)
                                                    }
                                                },
                                                onLongClick = { viewModel.toggleVideoSelection(video.id) }
                                            )
                                        }
                                    }
                                }
                            } else {
                                LazyColumn(
                                    contentPadding = PaddingValues(bottom = 88.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    if (!showingVideos) {
                                        items(
                                            items = state.folders,
                                            key = { it.bucketId },
                                            contentType = { "folder_row" }
                                        ) { folder ->
                                            FolderListRow(
                                                folder = folder,
                                                isSelected = folder.bucketId in state.selectedFolderIds,
                                                imageLoader = imageLoader,
                                                onClick = {
                                                    if (state.isMultiSelectActive) {
                                                        viewModel.toggleFolderSelection(folder.bucketId)
                                                    } else {
                                                        viewModel.openFolder(folder)
                                                    }
                                                },
                                                onLongClick = { viewModel.toggleFolderSelection(folder.bucketId) }
                                            )
                                        }
                                    } else {
                                        items(
                                            items = state.videos,
                                            key = { it.id },
                                            contentType = { "video_row" }
                                        ) { video ->
                                            VideoListRow(
                                                video = video,
                                                isSelected = video.id in state.selectedVideoIds,
                                                imageLoader = imageLoader,
                                                onClick = {
                                                    if (state.isMultiSelectActive) {
                                                        viewModel.toggleVideoSelection(video.id)
                                                    } else {
                                                        onPlayVideo(video)
                                                    }
                                                },
                                                onLongClick = { viewModel.toggleVideoSelection(video.id) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSortDialog) {
        SortDialog(
            currentField = state.settings.sortField,
            currentDirection = state.settings.sortDirection,
            onDismiss = { showSortDialog = false },
            onApply = { field, direction ->
                showSortDialog = false
                viewModel.updateSort(field, direction)
            }
        )
    }

    if (showStreamDialog) {
        NetworkStreamDialog(
            recentUrls = state.settings.recentNetworkUrls,
            onDismiss = { showStreamDialog = false },
            onOpenUrl = { url ->
                showStreamDialog = false
                viewModel.addRecentNetworkUrl(url)
                onPlayStreamUrl(url)
            }
        )
    }

    showRenameDialogFor?.let { target ->
        RenameVideoDialog(
            currentTitle = target.title,
            onDismiss = { showRenameDialogFor = null },
            onConfirm = { newBaseName ->
                showRenameDialogFor = null
                viewModel.renameVideo(target, newBaseName)
            }
        )
    }

    if (showDeleteConfirm) {
        val count = state.selectedVideoIds.size
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete $count video(s)?") },
            text = { Text("Selected videos will be permanently removed from your device.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    viewModel.deleteSelectedVideos()
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (state.isLoadingProperties || state.propertiesVideo != null) {
        PropertiesDialog(
            properties = state.propertiesVideo,
            isLoading = state.isLoadingProperties,
            onDismiss = viewModel::dismissProperties
        )
    }
}

@Composable
private fun PermissionEmptyState(
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit,
    onPickVideoFile: () -> Unit,
    onOpenStream: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.VideoLibrary,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.permission_required_title),
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.permission_required_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = onRequestPermission,
            modifier = Modifier.testTag("grant_permission_button")
        ) {
            Text(stringResource(R.string.grant_permission))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onOpenSettings) {
                Text(stringResource(R.string.open_app_settings))
            }
            OutlinedButton(onClick = onPickVideoFile) {
                Text(stringResource(R.string.pick_video_file))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        TextButton(onClick = onOpenStream) {
            Text(stringResource(R.string.open_network_stream))
        }
    }
}

@Composable
private fun EmptyVideosView(
    onOpenStream: () -> Unit,
    onPickFile: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.VideoLibrary,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = stringResource(R.string.no_videos_found),
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = stringResource(R.string.no_videos_tip),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onPickFile) {
                Text(stringResource(R.string.pick_video_file))
            }
            Button(onClick = onOpenStream) {
                Text(stringResource(R.string.open_network_stream))
            }
        }
    }
}

private fun shareVideos(context: android.content.Context, videos: List<VideoItem>) {
    val uris = ArrayList<Uri>(videos.size).apply {
        videos.forEach { add(Uri.parse(it.contentUri)) }
    }
    val intent = if (uris.size == 1) {
        Intent(Intent.ACTION_SEND).apply {
            type = "video/*"
            putExtra(Intent.EXTRA_STREAM, uris.first())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "video/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
    context.startActivity(Intent.createChooser(intent, "Share video"))
}
