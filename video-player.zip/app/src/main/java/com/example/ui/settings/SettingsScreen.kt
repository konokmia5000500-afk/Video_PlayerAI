package com.example.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.BuildConfig
import com.example.R
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.DecoderMode
import com.example.data.preferences.OrientationMode
import com.example.util.TimeFormatters
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = viewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val cacheSize by viewModel.cacheSizeLabel.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var showDecoderDialog by remember { mutableStateOf(false) }
    var showOrientationDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    LaunchedEffect(viewModel) {
        viewModel.messages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .widthIn(max = 720.dp)
        ) {
            item { SectionHeader("Gestures") }

            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text("Double-tap seek duration", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10, 15, 20, 30, 60).forEach { sec ->
                            FilterChip(
                                selected = settings.doubleTapSeekSeconds == sec,
                                onClick = { viewModel.setDoubleTapSeekSeconds(sec) },
                                label = { Text("${sec}s") }
                            )
                        }
                    }
                }
            }

            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Swipe-seek sensitivity", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = String.format(Locale.US, "%.1fx", settings.swipeSeekSensitivity),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = settings.swipeSeekSensitivity,
                        onValueChange = { viewModel.setSwipeSeekSensitivity(it) },
                        valueRange = 0.5f..2.0f,
                        steps = 5
                    )
                }
            }

            item {
                SettingsSwitchRow(
                    title = "Brightness gesture (left swipe)",
                    checked = settings.gestureBrightnessEnabled,
                    onCheckedChange = viewModel::setGestureBrightness
                )
            }
            item {
                SettingsSwitchRow(
                    title = "Volume & boost gesture (right swipe)",
                    checked = settings.gestureVolumeEnabled,
                    onCheckedChange = viewModel::setGestureVolume
                )
            }
            item {
                SettingsSwitchRow(
                    title = "Horizontal swipe seek",
                    checked = settings.gestureSeekEnabled,
                    onCheckedChange = viewModel::setGestureSeek
                )
            }
            item {
                SettingsSwitchRow(
                    title = "Double-tap seek & play/pause",
                    checked = settings.gestureDoubleTapEnabled,
                    onCheckedChange = viewModel::setGestureDoubleTap
                )
            }
            item {
                SettingsSwitchRow(
                    title = "Pinch to zoom & pan",
                    checked = settings.gesturePinchZoomEnabled,
                    onCheckedChange = viewModel::setGesturePinchZoom
                )
            }

            item { HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp)) }
            item { SectionHeader("Playback & Decoder") }

            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Default playback speed", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = TimeFormatters.formatSpeed(settings.defaultSpeed),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = settings.defaultSpeed,
                        onValueChange = { viewModel.setDefaultSpeed((it * 4).toInt() / 4f) },
                        valueRange = 0.25f..4.0f,
                        steps = 14
                    )
                }
            }

            item {
                ListItem(
                    headlineContent = { Text("Default decoder") },
                    supportingContent = { Text(settings.defaultDecoderMode.label) },
                    modifier = Modifier.clickable { showDecoderDialog = true }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Default orientation") },
                    supportingContent = { Text(settings.defaultOrientationMode.label) },
                    modifier = Modifier.clickable { showOrientationDialog = true }
                )
            }
            item {
                SettingsSwitchRow(
                    title = "Resume from last position",
                    checked = settings.resumePlayback,
                    onCheckedChange = viewModel::setResumePlayback
                )
            }
            item {
                SettingsSwitchRow(
                    title = "Auto-play next video in folder",
                    checked = settings.autoPlayNext,
                    onCheckedChange = viewModel::setAutoPlayNext
                )
            }

            item { HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp)) }
            item { SectionHeader("Display & Background") }

            item {
                SettingsSwitchRow(
                    title = "Keep screen on during playback",
                    checked = settings.keepScreenOn,
                    onCheckedChange = viewModel::setKeepScreenOn
                )
            }
            item {
                SettingsSwitchRow(
                    title = "Auto Picture-in-Picture on leaving app",
                    checked = settings.autoPip,
                    onCheckedChange = viewModel::setAutoPip
                )
            }
            item {
                SettingsSwitchRow(
                    title = "Background audio play",
                    subtitle = "Continue audio playback when app goes to background",
                    checked = settings.backgroundPlay,
                    onCheckedChange = viewModel::setBackgroundPlay
                )
            }

            item { HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp)) }
            item { SectionHeader("Appearance & Storage") }

            item {
                ListItem(
                    headlineContent = { Text("Theme") },
                    supportingContent = { Text(settings.themeMode.label) },
                    modifier = Modifier
                        .clickable { showThemeDialog = true }
                        .testTag("setting_theme")
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Clear thumbnail cache") },
                    supportingContent = { Text("Current disk cache: $cacheSize") },
                    leadingContent = { Icon(Icons.Filled.CleaningServices, contentDescription = null) },
                    modifier = Modifier
                        .clickable { viewModel.clearThumbnailCache() }
                        .testTag("setting_clear_cache")
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Rescan video library") },
                    supportingContent = { Text("Refresh MediaStore video index") },
                    leadingContent = { Icon(Icons.Filled.Refresh, contentDescription = null) },
                    modifier = Modifier
                        .clickable { viewModel.rescanLibrary() }
                        .testTag("setting_rescan")
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("About Video Player") },
                    supportingContent = { Text("Version ${BuildConfig.VERSION_NAME} • Media3 + LibVLC") },
                    leadingContent = { Icon(Icons.Filled.Info, contentDescription = null) },
                    modifier = Modifier.clickable { showAboutDialog = true }
                )
            }
            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }

    if (showDecoderDialog) {
        SingleChoiceEnumDialog(
            title = "Default Decoder",
            options = DecoderMode.entries,
            selected = settings.defaultDecoderMode,
            labelOf = { it.label },
            onSelect = {
                viewModel.setDefaultDecoder(it)
                showDecoderDialog = false
            },
            onDismiss = { showDecoderDialog = false }
        )
    }

    if (showOrientationDialog) {
        SingleChoiceEnumDialog(
            title = "Default Orientation",
            options = OrientationMode.entries,
            selected = settings.defaultOrientationMode,
            labelOf = { it.label },
            onSelect = {
                viewModel.setDefaultOrientation(it)
                showOrientationDialog = false
            },
            onDismiss = { showOrientationDialog = false }
        )
    }

    if (showThemeDialog) {
        SingleChoiceEnumDialog(
            title = "App Theme",
            options = AppThemeMode.entries,
            selected = settings.themeMode,
            labelOf = { it.label },
            onSelect = {
                viewModel.setThemeMode(it)
                showThemeDialog = false
            },
            onDismiss = { showThemeDialog = false }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text(stringResource(R.string.app_name)) },
            text = {
                Text(
                    "Version ${BuildConfig.VERSION_NAME}\n\n" +
                        "Engines: AndroidX Media3 ExoPlayer (SurfaceView) with automatic LibVLC fallback.\n" +
                        "Features: Gesture controls, 200% LoudnessEnhancer boost, 5-band Equalizer, PiP, and background MediaSessionService."
                )
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text(stringResource(R.string.ok))
                }
            }
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
    )
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { { Text(it) } },
        trailingContent = {
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        },
        modifier = Modifier.clickable { onCheckedChange(!checked) }
    )
}

@Composable
private fun <T> SingleChoiceEnumDialog(
    title: String,
    options: List<T>,
    selected: T,
    labelOf: (T) -> String,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(opt) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = opt == selected, onClick = { onSelect(opt) })
                        Text(labelOf(opt), modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}
