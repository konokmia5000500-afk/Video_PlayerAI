package com.example.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.BuildConfig
import com.example.R
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.DecoderMode
import com.example.data.preferences.HomeStartTab
import com.example.data.preferences.OrientationMode
import com.example.data.preferences.SubtitleBackgroundStyle
import com.example.player.engine.AspectRatioMode
import com.example.player.engine.LoopMode
import com.example.player.engine.PlaybackUiState
import com.example.player.subtitle.SubtitleEncodings
import com.example.ui.player.DecoderInfoDialog
import com.example.ui.theme.GlassSurfaceCard
import com.example.ui.theme.OceanBackdrop
import com.example.util.TimeFormatters
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = viewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val cacheSize by viewModel.cacheSizeLabel.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var showStartTabDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showDecoderDialog by remember { mutableStateOf(false) }
    var showOrientationDialog by remember { mutableStateOf(false) }
    var showAspectDialog by remember { mutableStateOf(false) }
    var showLoopDialog by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showSubtitleBgDialog by remember { mutableStateOf(false) }
    var showSubtitleEncodingDialog by remember { mutableStateOf(false) }
    var showCodecInfoDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showLicensesDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    LaunchedEffect(viewModel) {
        viewModel.messages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    OceanBackdrop(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                    title = { Text(stringResource(R.string.settings_title)) },
                    navigationIcon = {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { innerPadding ->
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .widthIn(max = 760.dp)
            ) {
                item {
                    SectionCard(title = "General") {
                        SettingsActionRow(
                            headline = "Default start tab",
                            supporting = settings.startTab.label,
                            onClick = { showStartTabDialog = true },
                            modifier = Modifier.testTag("setting_start_tab")
                        )
                        HorizontalDivider()
                        SettingsActionRow(
                            headline = "Theme",
                            supporting = settings.themeMode.label,
                            onClick = { showThemeDialog = true },
                            modifier = Modifier.testTag("setting_theme")
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Show video thumbnails",
                            subtitle = "Render video frame previews across library and playlists",
                            checked = settings.showThumbnails,
                            onCheckedChange = viewModel::setShowThumbnails
                        )
                    }
                }

                item {
                    SectionCard(title = "Player") {
                        SettingsActionRow(
                            headline = "Default orientation",
                            supporting = settings.defaultOrientationMode.label,
                            onClick = { showOrientationDialog = true }
                        )
                        HorizontalDivider()
                        SettingsActionRow(
                            headline = "Default aspect ratio",
                            supporting = settings.defaultAspectRatioMode.label,
                            onClick = { showAspectDialog = true }
                        )
                        HorizontalDivider()
                        SettingsActionRow(
                            headline = "Default loop mode",
                            supporting = settings.defaultLoopMode.label,
                            onClick = { showLoopDialog = true }
                        )
                        HorizontalDivider()
                        SettingsActionRow(
                            headline = "Default sleep timer",
                            supporting = if (settings.defaultSleepTimerMinutes <= 0) "Off" else "${settings.defaultSleepTimerMinutes} minutes",
                            onClick = { showSleepTimerDialog = true }
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Auto fullscreen playback",
                            subtitle = "Hide system navigation and status bars in player",
                            checked = settings.autoFullscreen,
                            onCheckedChange = viewModel::setAutoFullscreen
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Keep screen on during playback",
                            checked = settings.keepScreenOn,
                            onCheckedChange = viewModel::setKeepScreenOn
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Auto Picture-in-Picture on leaving app",
                            checked = settings.autoPip,
                            onCheckedChange = viewModel::setAutoPip
                        )
                    }
                }

                item {
                    SectionCard(title = "Gestures") {
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Text("Double-tap seek duration", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(6.dp))
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(5, 10, 15, 20, 30, 60).forEach { sec ->
                                    FilterChip(
                                        selected = settings.doubleTapSeekSeconds == sec,
                                        onClick = { viewModel.setDoubleTapSeekSeconds(sec) },
                                        label = { Text("${sec}s") }
                                    )
                                }
                            }
                        }
                        HorizontalDivider()
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Swipe-seek sensitivity", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = String.format(Locale.US, "%.1fx", settings.swipeSeekSensitivity),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = settings.swipeSeekSensitivity,
                                onValueChange = viewModel::setSwipeSeekSensitivity,
                                valueRange = 0.5f..2.0f,
                                steps = 5
                            )
                        }
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Brightness gesture (left swipe)",
                            checked = settings.gestureBrightnessEnabled,
                            onCheckedChange = viewModel::setGestureBrightness
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Volume & boost gesture (right swipe)",
                            checked = settings.gestureVolumeEnabled,
                            onCheckedChange = viewModel::setGestureVolume
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Horizontal swipe seek",
                            checked = settings.gestureSeekEnabled,
                            onCheckedChange = viewModel::setGestureSeek
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Double-tap seek & play/pause",
                            checked = settings.gestureDoubleTapEnabled,
                            onCheckedChange = viewModel::setGestureDoubleTap
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Pinch to zoom & pan",
                            checked = settings.gesturePinchZoomEnabled,
                            onCheckedChange = viewModel::setGesturePinchZoom
                        )
                    }
                }

                item {
                    SectionCard(title = "Subtitles") {
                        SettingsSwitchRow(
                            title = "Enable subtitles automatically",
                            subtitle = "Auto-load matching .srt/.ass/.vtt/.sub/.smi files when present",
                            checked = settings.subtitleEnabledByDefault,
                            onCheckedChange = viewModel::setSubtitleEnabledByDefault
                        )
                        HorizontalDivider()
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Default font size", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${settings.subtitleFontSizeSp} sp",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = settings.subtitleFontSizeSp.toFloat(),
                                onValueChange = { viewModel.setSubtitleFontSizeSp(it.toInt()) },
                                valueRange = 12f..34f
                            )
                        }
                        HorizontalDivider()
                        SettingsActionRow(
                            headline = "Subtitle background style",
                            supporting = settings.subtitleBackgroundStyle.label,
                            onClick = { showSubtitleBgDialog = true }
                        )
                        HorizontalDivider()
                        SettingsActionRow(
                            headline = "Text encoding",
                            supporting = settings.subtitleEncoding,
                            onClick = { showSubtitleEncodingDialog = true }
                        )
                    }
                }

                item {
                    SectionCard(title = "Playback & Decoder") {
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Default playback speed", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = TimeFormatters.formatSpeed(settings.defaultSpeed),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = settings.defaultSpeed,
                                onValueChange = { viewModel.setDefaultSpeed((it * 4).toInt() / 4f) },
                                valueRange = 0.25f..4.0f,
                                steps = 14
                            )
                        }
                        HorizontalDivider()
                        SettingsActionRow(
                            headline = "Default decoder",
                            supporting = settings.defaultDecoderMode.label,
                            onClick = { showDecoderDialog = true }
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Resume from last position",
                            checked = settings.resumePlayback,
                            onCheckedChange = viewModel::setResumePlayback
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Auto-play next video",
                            checked = settings.autoPlayNext,
                            onCheckedChange = viewModel::setAutoPlayNext
                        )
                        HorizontalDivider()
                        SettingsSwitchRow(
                            title = "Background audio play",
                            subtitle = "Continue audio playback when app goes to background",
                            checked = settings.backgroundPlay,
                            onCheckedChange = viewModel::setBackgroundPlay
                        )
                    }
                }

                item {
                    SectionCard(title = "Performance & Storage") {
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text("Rescan video library") },
                            supportingContent = { Text("Refresh MediaStore video index") },
                            leadingContent = { Icon(Icons.Filled.Refresh, contentDescription = null) },
                            modifier = Modifier
                                .clickable { viewModel.rescanLibrary() }
                                .testTag("setting_rescan")
                        )
                        HorizontalDivider()
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text("Clear thumbnail cache") },
                            supportingContent = { Text("Current disk cache: $cacheSize") },
                            leadingContent = { Icon(Icons.Filled.CleaningServices, contentDescription = null) },
                            modifier = Modifier
                                .clickable { viewModel.clearThumbnailCache() }
                                .testTag("setting_clear_cache")
                        )
                        HorizontalDivider()
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text("Clear watch history & resume data") },
                            supportingContent = { Text("Reset saved timestamps and playback counts") },
                            leadingContent = { Icon(Icons.Filled.History, contentDescription = null) },
                            modifier = Modifier
                                .clickable { viewModel.clearWatchHistory() }
                                .testTag("setting_clear_history")
                        )
                        HorizontalDivider()
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text("Clear network stream history") },
                            supportingContent = { Text("Remove saved recent stream URLs") },
                            leadingContent = { Icon(Icons.Filled.DeleteSweep, contentDescription = null) },
                            modifier = Modifier
                                .clickable { viewModel.clearNetworkHistory() }
                                .testTag("setting_clear_network_history")
                        )
                    }
                }

                item {
                    SectionCard(title = "About") {
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text("Device hardware & software codecs") },
                            supportingContent = { Text("Inspect MediaCodec decoder capabilities") },
                            leadingContent = { Icon(Icons.Filled.Memory, contentDescription = null) },
                            modifier = Modifier.clickable { showCodecInfoDialog = true }
                        )
                        HorizontalDivider()
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text("Privacy summary") },
                            supportingContent = { Text("All media indexing, playlists, and history stay on device") },
                            leadingContent = { Icon(Icons.Filled.Policy, contentDescription = null) },
                            modifier = Modifier.clickable { showPrivacyDialog = true }
                        )
                        HorizontalDivider()
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text("Open-source licenses") },
                            supportingContent = { Text("AndroidX Media3, LibVLC, Jetpack Compose, Room, Coil") },
                            leadingContent = { Icon(Icons.Filled.Description, contentDescription = null) },
                            modifier = Modifier.clickable { showLicensesDialog = true }
                        )
                        HorizontalDivider()
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text(stringResource(R.string.app_name)) },
                            supportingContent = { Text("Version ${BuildConfig.VERSION_NAME} • Media3 + LibVLC") },
                            leadingContent = { Icon(Icons.Filled.Info, contentDescription = null) },
                            modifier = Modifier.clickable { showAboutDialog = true }
                        )
                    }
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }

    if (showStartTabDialog) {
        SingleChoiceEnumDialog(
            title = "Default Start Tab",
            options = HomeStartTab.entries,
            selected = settings.startTab,
            labelOf = { it.label },
            onSelect = {
                viewModel.setStartTab(it)
                showStartTabDialog = false
            },
            onDismiss = { showStartTabDialog = false }
        )
    }

    if (showThemeDialog) {
        SingleChoiceEnumDialog(
            title = "App Theme",
            options = AppThemeMode.entries,
            selected = settings.themeMode,
            labelOf = { it.label },
            onSelect = {
                viewModel.setThemeMode(it)
                showThemeDialog = false
            },
            onDismiss = { showThemeDialog = false }
        )
    }

    if (showDecoderDialog) {
        SingleChoiceEnumDialog(
            title = "Default Decoder",
            options = DecoderMode.entries,
            selected = settings.defaultDecoderMode,
            labelOf = { it.label },
            onSelect = {
                viewModel.setDefaultDecoder(it)
                showDecoderDialog = false
            },
            onDismiss = { showDecoderDialog = false }
        )
    }

    if (showOrientationDialog) {
        SingleChoiceEnumDialog(
            title = "Default Orientation",
            options = OrientationMode.entries,
            selected = settings.defaultOrientationMode,
            labelOf = { it.label },
            onSelect = {
                viewModel.setDefaultOrientation(it)
                showOrientationDialog = false
            },
            onDismiss = { showOrientationDialog = false }
        )
    }

    if (showAspectDialog) {
        SingleChoiceEnumDialog(
            title = "Default Aspect Ratio",
            options = AspectRatioMode.entries,
            selected = settings.defaultAspectRatioMode,
            labelOf = { it.label },
            onSelect = {
                viewModel.setDefaultAspectRatio(it)
                showAspectDialog = false
            },
            onDismiss = { showAspectDialog = false }
        )
    }

    if (showLoopDialog) {
        SingleChoiceEnumDialog(
            title = "Default Loop Mode",
            options = LoopMode.entries,
            selected = settings.defaultLoopMode,
            labelOf = { it.label },
            onSelect = {
                viewModel.setDefaultLoopMode(it)
                showLoopDialog = false
            },
            onDismiss = { showLoopDialog = false }
        )
    }

    if (showSleepTimerDialog) {
        SingleChoiceEnumDialog(
            title = "Default Sleep Timer",
            options = listOf(0, 15, 30, 45, 60, 90),
            selected = settings.defaultSleepTimerMinutes,
            labelOf = { if (it == 0) "Off" else "$it minutes" },
            onSelect = {
                viewModel.setDefaultSleepTimerMinutes(it)
                showSleepTimerDialog = false
            },
            onDismiss = { showSleepTimerDialog = false }
        )
    }

    if (showSubtitleBgDialog) {
        SingleChoiceEnumDialog(
            title = "Subtitle Background Style",
            options = SubtitleBackgroundStyle.entries,
            selected = settings.subtitleBackgroundStyle,
            labelOf = { it.label },
            onSelect = {
                viewModel.setSubtitleBackgroundStyle(it)
                showSubtitleBgDialog = false
            },
            onDismiss = { showSubtitleBgDialog = false }
        )
    }

    if (showSubtitleEncodingDialog) {
        SingleChoiceEnumDialog(
            title = "Subtitle Encoding",
            options = SubtitleEncodings.supported,
            selected = settings.subtitleEncoding,
            labelOf = { it },
            onSelect = {
                viewModel.setSubtitleEncoding(it)
                showSubtitleEncodingDialog = false
            },
            onDismiss = { showSubtitleEncodingDialog = false }
        )
    }

    if (showCodecInfoDialog) {
        DecoderInfoDialog(
            playbackState = PlaybackUiState(decoderMode = settings.defaultDecoderMode),
            onDismiss = { showCodecInfoDialog = false }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Summary") },
            text = {
                Text(
                    "Video Player processes your library strictly on your device:\n\n" +
                        "• Local media scanning uses Android MediaStore and caches metadata locally in Room.\n" +
                        "• Playlists, playback history, and stream history never leave your phone.\n" +
                        "• No analytics SDKs, ad trackers, or background uploads are included.\n" +
                        "• YouTube links open directly in the official YouTube app or browser."
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text(stringResource(R.string.ok)) }
            }
        )
    }

    if (showLicensesDialog) {
        AlertDialog(
            onDismissRequest = { showLicensesDialog = false },
            title = { Text("Open-Source Licenses") },
            text = {
                Text(
                    "• AndroidX Media3 (ExoPlayer & MediaSession) — Apache License 2.0\n" +
                        "• LibVLC Android SDK — LGPLv2.1 / GPL\n" +
                        "• Jetpack Compose & Material 3 — Apache License 2.0\n" +
                        "• AndroidX Room & DataStore — Apache License 2.0\n" +
                        "• Coil Image & Video Decoder — Apache License 2.0\n" +
                        "• Kotlin Coroutines & Serialization — Apache License 2.0"
                )
            },
            confirmButton = {
                TextButton(onClick = { showLicensesDialog = false }) { Text(stringResource(R.string.close)) }
            }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text(stringResource(R.string.app_name)) },
            text = {
                Text(
                    "Version ${BuildConfig.VERSION_NAME}\n\n" +
                        "Dual-engine architecture combining AndroidX Media3 ExoPlayer (SurfaceView) with automatic LibVLC fallback.\n\n" +
                        "Includes gesture controls, 200% audio boost, 5-band Equalizer, custom SRT/ASS/VTT/SUB/SMI subtitles, playlists, watch history, Picture-in-Picture, and background playback."
                )
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) { Text(stringResource(R.string.ok)) }
            }
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
        )
        GlassSurfaceCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.fillMaxWidth()) {
                content()
            }
        }
    }
}

@Composable
private fun SettingsActionRow(
    headline: String,
    supporting: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ListItem(
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        headlineContent = { Text(headline) },
        supportingContent = { Text(supporting) },
        modifier = modifier.clickable(onClick = onClick)
    )
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    ListItem(
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { { Text(it) } },
        trailingContent = {
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        },
        modifier = Modifier.clickable { onCheckedChange(!checked) }
    )
}

@Composable
private fun <T> SingleChoiceEnumDialog(
    title: String,
    options: List<T>,
    selected: T,
    labelOf: (T) -> String,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(opt) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = opt == selected, onClick = { onSelect(opt) })
                        Text(labelOf(opt), modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        }
    )
}
