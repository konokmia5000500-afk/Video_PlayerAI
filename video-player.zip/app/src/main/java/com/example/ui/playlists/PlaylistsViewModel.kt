package com.example.ui.playlists

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.data.model.PlaylistSummary
import com.example.data.model.PlaylistVideoItem
import com.example.data.model.VideoItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PlaylistsViewModel(application: Application) : AndroidViewModel(application) {
    private val container = AppContainer.getInstance(application)
    private val repository = container.videoLibraryRepository

    val playlists: StateFlow<List<PlaylistSummary>> = repository.playlistsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    val allVideos: StateFlow<List<VideoItem>> = repository.videosFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = emptyList()
    )

    fun observePlaylistSummary(playlistId: Long): Flow<PlaylistSummary?> =
        repository.playlistsFlow.map { list -> list.firstOrNull { it.id == playlistId } }

    fun observePlaylistItems(playlistId: Long): Flow<List<PlaylistVideoItem>> =
        repository.observePlaylistVideos(playlistId)

    fun createPlaylist(name: String, initialVideos: List<VideoItem> = emptyList()) {
        viewModelScope.launch {
            repository.createPlaylist(name, initialVideos)
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        viewModelScope.launch {
            repository.renamePlaylist(playlistId, newName)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun addVideosToPlaylist(playlistId: Long, videos: List<VideoItem>) {
        viewModelScope.launch {
            repository.addVideosToPlaylist(playlistId, videos)
        }
    }

    fun removeEntry(playlistId: Long, entryId: Long) {
        viewModelScope.launch {
            repository.removePlaylistEntry(playlistId, entryId)
        }
    }

    fun moveUp(playlistId: Long, entries: List<PlaylistVideoItem>, index: Int) {
        viewModelScope.launch {
            repository.movePlaylistItemUp(playlistId, entries, index)
        }
    }

    fun moveDown(playlistId: Long, entries: List<PlaylistVideoItem>, index: Int) {
        viewModelScope.launch {
            repository.movePlaylistItemDown(playlistId, entries, index)
        }
    }
}
