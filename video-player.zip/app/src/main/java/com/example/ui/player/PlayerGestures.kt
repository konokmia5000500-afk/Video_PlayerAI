package com.example.ui.player

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import com.example.data.preferences.PlayerSettings
import kotlin.math.abs

@Immutable
sealed interface GestureHudState {
    data object None : GestureHudState
    data class Brightness(val percent: Int) : GestureHudState
    data class Volume(val percent: Int) : GestureHudState
    data class SeekPreview(val targetMs: Long, val deltaMs: Long) : GestureHudState
    data class DoubleTapSeek(val seconds: Int, val isForward: Boolean) : GestureHudState
    data class DoubleTapPlayPause(val isNowPlaying: Boolean) : GestureHudState
    data class ToastLabel(val label: String) : GestureHudState
}

fun Modifier.mxPlayerGestures(
    settings: PlayerSettings,
    isLocked: Boolean,
    currentScale: Float,
    currentPanX: Float,
    currentPanY: Float,
    getCurrentPositionMs: () -> Long,
    getDurationMs: () -> Long,
    getInitialBrightness: () -> Float,
    getInitialVolumePercent: () -> Int,
    onSingleTap: () -> Unit,
    onDoubleTapSeek: (deltaMs: Long, isForward: Boolean) -> Unit,
    onDoubleTapPlayPause: () -> Unit,
    onBrightnessDrag: (brightness01: Float) -> Unit,
    onVolumeDrag: (percent0To200: Int) -> Unit,
    onSeekDrag: (targetMs: Long, deltaMs: Long, isFinal: Boolean) -> Unit,
    onZoomPan: (scale: Float, panX: Float, panY: Float) -> Unit,
    onHudChange: (GestureHudState) -> Unit
): Modifier {
    val tapModifier = this.pointerInput(isLocked, settings.gestureDoubleTapEnabled, settings.doubleTapSeekSeconds) {
        detectTapGestures(
            onTap = { onSingleTap() },
            onDoubleTap = { offset ->
                if (isLocked || !settings.gestureDoubleTapEnabled) return@detectTapGestures
                val width = size.width.toFloat().coerceAtLeast(1f)
                val fractionX = offset.x / width
                when {
                    fractionX < 0.34f -> {
                        val sec = settings.doubleTapSeekSeconds
                        onDoubleTapSeek(-sec * 1000L, false)
                    }
                    fractionX > 0.66f -> {
                        val sec = settings.doubleTapSeekSeconds
                        onDoubleTapSeek(sec * 1000L, true)
                    }
                    else -> {
                        onDoubleTapPlayPause()
                    }
                }
            }
        )
    }

    return tapModifier.pointerInput(
        isLocked,
        settings.gestureBrightnessEnabled,
        settings.gestureVolumeEnabled,
        settings.gestureSeekEnabled,
        settings.gesturePinchZoomEnabled,
        settings.swipeSeekSensitivity,
        currentScale,
        currentPanX,
        currentPanY
    ) {
        val touchSlop = viewConfiguration.touchSlop
        awaitEachGesture {
            val firstDown = awaitFirstDown(requireUnconsumed = false)
            if (isLocked) return@awaitEachGesture

            val width = size.width.toFloat().coerceAtLeast(1f)
            val height = size.height.toFloat().coerceAtLeast(1f)
            val startX = firstDown.position.x
            val startY = firstDown.position.y

            var mode = 0 // 0=undecided, 1=seek, 2=brightness, 3=volume, 4=pinchZoom
            var totalDx = 0f
            var totalDy = 0f

            var startPosMs = 0L
            var durationMs = 0L
            var lastSeekTarget = 0L
            var lastSeekDelta = 0L
            var startBrightness = 0.5f
            var startVolumePct = 100

            var zoomScale = currentScale
            var panX = currentPanX
            var panY = currentPanY

            while (true) {
                val event = awaitPointerEvent()
                val pressed = event.changes.filter { it.pressed }
                if (pressed.isEmpty()) {
                    if (mode == 1) {
                        onSeekDrag(lastSeekTarget, lastSeekDelta, true)
                    }
                    if (mode in 1..3) {
                        onHudChange(GestureHudState.None)
                    }
                    break
                }

                if (pressed.size >= 2 && settings.gesturePinchZoomEnabled) {
                    if (mode == 1) {
                        onSeekDrag(lastSeekTarget, lastSeekDelta, true)
                    }
                    mode = 4
                    val zoomChange = event.calculateZoom()
                    val panChange = event.calculatePan()
                    zoomScale = (zoomScale * zoomChange).coerceIn(1f, 4f)
                    if (zoomScale > 1.01f) {
                        val maxPanX = (width * (zoomScale - 1f)) / 2f
                        val maxPanY = (height * (zoomScale - 1f)) / 2f
                        panX = (panX + panChange.x).coerceIn(-maxPanX, maxPanX)
                        panY = (panY + panChange.y).coerceIn(-maxPanY, maxPanY)
                    } else {
                        panX = 0f
                        panY = 0f
                    }
                    onZoomPan(zoomScale, panX, panY)
                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                    continue
                }

                if (mode == 4) continue

                val primary = pressed.first()
                val dx = primary.position.x - primary.previousPosition.x
                val dy = primary.position.y - primary.previousPosition.y
                totalDx += dx
                totalDy += dy

                if (mode == 0) {
                    if (abs(totalDx) > touchSlop && abs(totalDx) > abs(totalDy) * 1.15f && settings.gestureSeekEnabled) {
                        mode = 1
                        startPosMs = getCurrentPositionMs()
                        durationMs = getDurationMs()
                        lastSeekTarget = startPosMs
                        lastSeekDelta = 0L
                    } else if (abs(totalDy) > touchSlop && abs(totalDy) > abs(totalDx) * 1.15f) {
                        val isLeftHalf = startX < width * 0.5f
                        if (isLeftHalf && settings.gestureBrightnessEnabled) {
                            mode = 2
                            startBrightness = getInitialBrightness().coerceIn(0.01f, 1f)
                        } else if (!isLeftHalf && settings.gestureVolumeEnabled) {
                            mode = 3
                            startVolumePct = getInitialVolumePercent().coerceIn(0, 200)
                        }
                    }
                }

                when (mode) {
                    1 -> {
                        val deltaPx = primary.position.x - startX
                        // Full screen width swipe equals 90 seconds * sensitivity
                        val msPerPx = (90_000f * settings.swipeSeekSensitivity) / width
                        val rawDelta = (deltaPx * msPerPx).toLong()
                        val target = if (durationMs > 0L) {
                            (startPosMs + rawDelta).coerceIn(0L, durationMs)
                        } else {
                            (startPosMs + rawDelta).coerceAtLeast(0L)
                        }
                        val actualDelta = target - startPosMs
                        lastSeekTarget = target
                        lastSeekDelta = actualDelta
                        onSeekDrag(target, actualDelta, false)
                        onHudChange(GestureHudState.SeekPreview(target, actualDelta))
                        primary.consume()
                    }
                    2 -> {
                        val deltaY = startY - primary.position.y
                        val fraction = deltaY / (height * 0.65f)
                        val newBrightness = (startBrightness + fraction).coerceIn(0.01f, 1f)
                        onBrightnessDrag(newBrightness)
                        onHudChange(GestureHudState.Brightness((newBrightness * 100f).toInt()))
                        primary.consume()
                    }
                    3 -> {
                        val deltaY = startY - primary.position.y
                        val fraction = deltaY / (height * 0.65f)
                        val newVol = (startVolumePct + (fraction * 200f)).toInt().coerceIn(0, 200)
                        onVolumeDrag(newVol)
                        onHudChange(GestureHudState.Volume(newVol))
                        primary.consume()
                    }
                }
            }
        }
    }
}
