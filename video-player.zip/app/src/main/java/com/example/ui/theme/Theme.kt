package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.data.preferences.AppThemeMode

@Immutable
data class GlassPalette(
    val gradientTop: Color,
    val gradientBottom: Color,
    val glassFill: Color,
    val glassFillStrong: Color,
    val glassBorder: Color,
    val accentGlow: Color,
    val isDark: Boolean
)

val LocalGlassPalette = staticCompositionLocalOf {
    GlassPalette(
        gradientTop = NavyCanvasTop,
        gradientBottom = NavyCanvasBottom,
        glassFill = NavyGlassSurface.copy(alpha = 0.72f),
        glassFillStrong = NavyGlassElevated.copy(alpha = 0.85f),
        glassBorder = SoftCyanAccent.copy(alpha = 0.22f),
        accentGlow = SkyCyanPrimary,
        isDark = true
    )
}

private val OceanDarkColorScheme = darkColorScheme(
    primary = SkyCyanPrimary,
    onPrimary = DeepNavyInk,
    primaryContainer = OceanBlueContainer,
    onPrimaryContainer = PaleIceOnContainer,
    secondary = SoftCyanAccent,
    onSecondary = DeepNavyInk,
    tertiary = RoyalBlueAccent,
    onTertiary = Color.White,
    background = NavyCanvasTop,
    onBackground = NavyOnSurface,
    surface = NavySurface,
    onSurface = NavyOnSurface,
    surfaceVariant = NavyGlassSurface,
    onSurfaceVariant = NavyOnSurfaceMuted,
    surfaceContainerHigh = NavyGlassSurface,
    surfaceContainerHighest = NavyGlassElevated,
    outline = NavyBorderGlow
)

private val MidnightAmoledColorScheme = darkColorScheme(
    primary = SkyCyanPrimary,
    onPrimary = DeepNavyInk,
    primaryContainer = Color(0xFF0A3A61),
    onPrimaryContainer = PaleIceOnContainer,
    secondary = SoftCyanAccent,
    onSecondary = DeepNavyInk,
    tertiary = RoyalBlueAccent,
    background = MidnightBackground,
    onBackground = Color(0xFFF3F8FF),
    surface = MidnightSurface,
    onSurface = Color(0xFFF3F8FF),
    surfaceVariant = MidnightGlass,
    onSurfaceVariant = NavyOnSurfaceMuted,
    surfaceContainerHigh = MidnightGlass,
    surfaceContainerHighest = MidnightGlassHigh,
    outline = MidnightOutline
)

private val SkyLightColorScheme = lightColorScheme(
    primary = IcePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6EFFF),
    onPrimaryContainer = Color(0xFF063759),
    secondary = IceSecondary,
    onSecondary = Color.White,
    tertiary = IceTertiary,
    background = IceBackground,
    onBackground = IceOnSurface,
    surface = IceSurface,
    onSurface = IceOnSurface,
    surfaceVariant = IceSurfaceVariant,
    onSurfaceVariant = IceOnSurfaceMuted,
    surfaceContainerHigh = IceSurfaceHigh,
    surfaceContainerHighest = IceSurfaceHighest,
    outline = IceOutline
)

@Composable
fun VideoPlayerTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    forceDarkSystemBars: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.DARK -> OceanDarkColorScheme
        AppThemeMode.AMOLED -> MidnightAmoledColorScheme
        AppThemeMode.LIGHT -> SkyLightColorScheme
    }

    val glassPalette = when (themeMode) {
        AppThemeMode.DARK -> GlassPalette(
            gradientTop = NavyCanvasTop,
            gradientBottom = NavyCanvasBottom,
            glassFill = NavyGlassSurface.copy(alpha = 0.72f),
            glassFillStrong = NavyGlassElevated.copy(alpha = 0.88f),
            glassBorder = SoftCyanAccent.copy(alpha = 0.20f),
            accentGlow = SkyCyanPrimary,
            isDark = true
        )
        AppThemeMode.AMOLED -> GlassPalette(
            gradientTop = MidnightBackground,
            gradientBottom = Color(0xFF050D1D),
            glassFill = MidnightGlass.copy(alpha = 0.76f),
            glassFillStrong = MidnightGlassHigh.copy(alpha = 0.90f),
            glassBorder = SkyCyanPrimary.copy(alpha = 0.18f),
            accentGlow = SkyCyanPrimary,
            isDark = true
        )
        AppThemeMode.LIGHT -> GlassPalette(
            gradientTop = IceBackground,
            gradientBottom = IceCanvasBottom,
            glassFill = Color.White.copy(alpha = 0.82f),
            glassFillStrong = Color.White.copy(alpha = 0.94f),
            glassBorder = IcePrimary.copy(alpha = 0.22f),
            accentGlow = IcePrimary,
            isDark = false
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val useDarkBars = forceDarkSystemBars || themeMode != AppThemeMode.LIGHT
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !useDarkBars
                isAppearanceLightNavigationBars = !useDarkBars
            }
        }
    }

    CompositionLocalProvider(LocalGlassPalette provides glassPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
