package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.data.preferences.AppThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = CinemaBluePrimary,
    onPrimary = CinemaBlueOnPrimary,
    primaryContainer = CinemaBlueContainer,
    onPrimaryContainer = CinemaBlueOnContainer,
    secondary = CinemaIndigoSecondary,
    tertiary = CinemaCyanTertiary,
    background = DarkBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFF94A3B8),
    surfaceContainerHigh = Color(0xFF1E2634),
    surfaceContainerHighest = Color(0xFF263042),
    outline = DarkOutline
)

private val AmoledColorScheme = darkColorScheme(
    primary = CinemaBluePrimary,
    onPrimary = CinemaBlueOnPrimary,
    primaryContainer = CinemaBlueContainer,
    onPrimaryContainer = CinemaBlueOnContainer,
    secondary = CinemaIndigoSecondary,
    tertiary = CinemaCyanTertiary,
    background = AmoledBackground,
    onBackground = Color(0xFFF8FAFC),
    surface = AmoledSurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = AmoledSurfaceVariant,
    onSurfaceVariant = Color(0xFF94A3B8),
    surfaceContainerHigh = Color(0xFF141923),
    surfaceContainerHighest = Color(0xFF1B2230),
    outline = Color(0xFF222A38)
)

private val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = Color(0xFF4F46E5),
    tertiary = Color(0xFF0D9488),
    background = LightBackground,
    onBackground = Color(0xFF0F172A),
    surface = LightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Color(0xFF475569),
    surfaceContainerHigh = Color(0xFFEEF3F8),
    surfaceContainerHighest = Color(0xFFE2E8F0),
    outline = Color(0xFFCBD5E1)
)

@Composable
fun VideoPlayerTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    forceDarkSystemBars: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.DARK -> DarkColorScheme
        AppThemeMode.AMOLED -> AmoledColorScheme
        AppThemeMode.LIGHT -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val useDarkBars = forceDarkSystemBars || themeMode != AppThemeMode.LIGHT
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !useDarkBars
                isAppearanceLightNavigationBars = !useDarkBars
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
