package com.example.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import coil.annotation.ExperimentalCoilApi
import com.example.AppContainer
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.DecoderMode
import com.example.data.preferences.HomeStartTab
import com.example.data.preferences.OrientationMode
import com.example.data.preferences.PlayerSettings
import com.example.data.preferences.SubtitleBackgroundStyle
import com.example.player.engine.AspectRatioMode
import com.example.player.engine.LoopMode
import com.example.util.TimeFormatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val container = AppContainer.getInstance(application)
    private val settingsRepo = container.settingsRepository
    private val libraryRepo = container.videoLibraryRepository
    private val imageLoader = container.imageLoader

    val settings: StateFlow<PlayerSettings> = settingsRepo.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = PlayerSettings()
    )

    private val _cacheSizeLabel = MutableStateFlow("0 B")
    val cacheSizeLabel: StateFlow<String> = _cacheSizeLabel.asStateFlow()

    private val _messages = MutableSharedFlow<String>()
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        refreshCacheSize()
    }

    @OptIn(ExperimentalCoilApi::class)
    fun refreshCacheSize() {
        viewModelScope.launch {
            val bytes = withContext(Dispatchers.IO) {
                imageLoader.diskCache?.size ?: 0L
            }
            _cacheSizeLabel.value = TimeFormatters.formatFileSize(bytes)
        }
    }

    @OptIn(ExperimentalCoilApi::class)
    fun clearThumbnailCache() {
        viewModelScope.launch {
            imageLoader.memoryCache?.clear()
            withContext(Dispatchers.IO) {
                imageLoader.diskCache?.clear()
            }
            refreshCacheSize()
            _messages.emit("Thumbnail cache cleared")
        }
    }

    fun clearWatchHistory() {
        viewModelScope.launch {
            libraryRepo.clearPlaybackHistory()
            _messages.emit("Watch history cleared")
        }
    }

    fun clearNetworkHistory() {
        viewModelScope.launch {
            libraryRepo.clearNetworkStreamHistory()
            _messages.emit("Network stream history cleared")
        }
    }

    fun rescanLibrary() {
        viewModelScope.launch {
            runCatching { libraryRepo.refreshFromMediaStore() }
                .onSuccess { _messages.emit("Library rescanned") }
                .onFailure { _messages.emit("Grant video permission to rescan") }
        }
    }

    fun setStartTab(tab: HomeStartTab) = launch { settingsRepo.updateStartTab(tab) }
    fun setThemeMode(mode: AppThemeMode) = launch { settingsRepo.updateThemeMode(mode) }
    fun setShowThumbnails(show: Boolean) = launch { settingsRepo.updateShowThumbnails(show) }

    fun setDoubleTapSeekSeconds(sec: Int) = launch { settingsRepo.updateDoubleTapSeekSeconds(sec) }
    fun setSwipeSeekSensitivity(sens: Float) = launch { settingsRepo.updateSwipeSeekSensitivity(sens) }
    fun setGestureBrightness(enabled: Boolean) = launch { settingsRepo.updateGestureBrightness(enabled) }
    fun setGestureVolume(enabled: Boolean) = launch { settingsRepo.updateGestureVolume(enabled) }
    fun setGestureSeek(enabled: Boolean) = launch { settingsRepo.updateGestureSeek(enabled) }
    fun setGestureDoubleTap(enabled: Boolean) = launch { settingsRepo.updateGestureDoubleTap(enabled) }
    fun setGesturePinchZoom(enabled: Boolean) = launch { settingsRepo.updateGesturePinchZoom(enabled) }

    fun setDefaultSpeed(speed: Float) = launch { settingsRepo.updateDefaultSpeed(speed) }
    fun setDefaultDecoder(mode: DecoderMode) = launch { settingsRepo.updateDefaultDecoder(mode) }
    fun setDefaultOrientation(mode: OrientationMode) = launch { settingsRepo.updateDefaultOrientation(mode) }
    fun setDefaultAspectRatio(mode: AspectRatioMode) = launch { settingsRepo.updateDefaultAspectRatio(mode) }
    fun setDefaultLoopMode(mode: LoopMode) = launch { settingsRepo.updateDefaultLoopMode(mode) }
    fun setDefaultSleepTimerMinutes(minutes: Int) = launch { settingsRepo.updateDefaultSleepTimerMinutes(minutes) }
    fun setResumePlayback(enabled: Boolean) = launch { settingsRepo.updateResumePlayback(enabled) }
    fun setAutoPlayNext(enabled: Boolean) = launch { settingsRepo.updateAutoPlayNext(enabled) }
    fun setKeepScreenOn(enabled: Boolean) = launch { settingsRepo.updateKeepScreenOn(enabled) }
    fun setAutoPip(enabled: Boolean) = launch { settingsRepo.updateAutoPip(enabled) }
    fun setAutoFullscreen(enabled: Boolean) = launch { settingsRepo.updateAutoFullscreen(enabled) }
    fun setBackgroundPlay(enabled: Boolean) = launch { settingsRepo.updateBackgroundPlay(enabled) }

    fun setSubtitleEnabledByDefault(enabled: Boolean) = launch { settingsRepo.updateSubtitleEnabledDefault(enabled) }
    fun setSubtitleFontSizeSp(sizeSp: Int) = launch { settingsRepo.updateSubtitleFontSizeSp(sizeSp) }
    fun setSubtitleTextColorHex(hex: Long) = launch { settingsRepo.updateSubtitleTextColorHex(hex) }
    fun setSubtitleBackgroundStyle(style: SubtitleBackgroundStyle) = launch { settingsRepo.updateSubtitleBackgroundStyle(style) }
    fun setSubtitleBottomPadding(fraction: Float) = launch { settingsRepo.updateSubtitleBottomPadding(fraction) }
    fun setSubtitleEncoding(encoding: String) = launch { settingsRepo.updateSubtitleEncoding(encoding) }

    private inline fun launch(crossinline block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }
}
