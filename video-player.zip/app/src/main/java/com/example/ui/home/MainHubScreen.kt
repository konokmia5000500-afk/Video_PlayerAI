package com.example.ui.home

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.PlaylistPlay
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.model.LibraryLayoutMode
import com.example.data.model.PlaylistSummary
import com.example.data.model.VideoItem
import com.example.data.model.WatchHistoryItem
import com.example.data.preferences.HomeStartTab
import com.example.player.engine.PlaybackQueueItem
import com.example.player.service.PlaybackServiceConnection
import com.example.ui.library.LibraryEvent
import com.example.ui.library.LibraryTabContent
import com.example.ui.library.LibraryViewModel
import com.example.ui.library.PropertiesDialog
import com.example.ui.library.RenameVideoDialog
import com.example.ui.library.SortDialog
import com.example.ui.library.shareVideos
import com.example.ui.network.NetworkTabContent
import com.example.ui.playlists.AddToPlaylistDialog
import com.example.ui.playlists.PlaylistsTabContent
import com.example.ui.playlists.PlaylistsViewModel
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.OceanBackdrop

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainHubScreen(
    onPlayVideo: (video: VideoItem) -> Unit,
    onPlayHistoryItem: (item: WatchHistoryItem) -> Unit,
    onPlayPlaylist: (playlistId: Long, startUri: String, title: String) -> Unit,
    onPlayStreamUrl: (url: String, title: String) -> Unit,
    onOpenPlaylistDetail: (playlistId: Long) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    libraryViewModel: LibraryViewModel = viewModel(),
    homeViewModel: HomeViewModel = viewModel(),
    playlistsViewModel: PlaylistsViewModel = viewModel()
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val glassPalette = LocalGlassPalette.current
    val snackbarHostState = remember { SnackbarHostState() }

    val libraryState by libraryViewModel.uiState.collectAsStateWithLifecycle()
    val dashboardState by homeViewModel.dashboardState.collectAsStateWithLifecycle()
    val playlists by playlistsViewModel.playlists.collectAsStateWithLifecycle()

    val serviceConnection = remember(context) { PlaybackServiceConnection(context) }
    val activeService by serviceConnection.service.collectAsStateWithLifecycle()

    var activeTab by rememberSaveable { mutableStateOf<HomeStartTab?>(null) }
    val resolvedTab = activeTab ?: libraryState.settings.startTab

    val requiredPermission = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    var pendingRenameVideo by remember { mutableStateOf<VideoItem?>(null) }
    var pendingRenameBaseName by remember { mutableStateOf<String?>(null) }
    var showSortDialog by remember { mutableStateOf(false) }
    var showRenameDialogFor by remember { mutableStateOf<VideoItem?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var videosPendingAddToPlaylist by remember { mutableStateOf<List<VideoItem>?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        libraryViewModel.onPermissionStatusChanged(granted)
    }

    val intentSenderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            libraryViewModel.onMediaPermissionApproved(pendingRenameVideo, pendingRenameBaseName)
        }
        pendingRenameVideo = null
        pendingRenameBaseName = null
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val title = uri.lastPathSegment?.substringAfterLast('/') ?: "Local Video"
            onPlayStreamUrl(uri.toString(), title)
        }
    }

    DisposableEffect(lifecycleOwner, requiredPermission) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    requiredPermission
                ) == PackageManager.PERMISSION_GRANTED
                libraryViewModel.onPermissionStatusChanged(granted)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(requiredPermission) {
        val granted = ContextCompat.checkSelfPermission(
            context,
            requiredPermission
        ) == PackageManager.PERMISSION_GRANTED
        libraryViewModel.onPermissionStatusChanged(granted)
        if (!granted) {
            permissionLauncher.launch(requiredPermission)
        }
    }

    LaunchedEffect(libraryViewModel) {
        libraryViewModel.events.collect { event ->
            when (event) {
                is LibraryEvent.LaunchIntentSender -> {
                    pendingRenameVideo = event.pendingRenameVideo
                    pendingRenameBaseName = event.pendingRenameBaseName
                    intentSenderLauncher.launch(
                        IntentSenderRequest.Builder(event.intentSender).build()
                    )
                }
                is LibraryEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(event.message)
                }
            }
        }
    }

    fun selectTab(tab: HomeStartTab) {
        activeTab = tab
        if (tab != HomeStartTab.FOLDERS) {
            libraryViewModel.closeFolder()
        }
        libraryViewModel.clearSelection()
    }

    fun enqueueVideos(selected: List<VideoItem>, playNextOnly: Boolean) {
        if (selected.isEmpty()) return
        val queueItems = selected.map {
            PlaybackQueueItem(
                uri = it.contentUri,
                title = it.title,
                displayName = it.displayName,
                path = it.path,
                durationMs = it.durationMs,
                sizeBytes = it.sizeBytes,
                width = it.width,
                height = it.height,
                mimeType = it.mimeType,
                folderBucketId = it.folderBucketId
            )
        }
        val svc = activeService
        if (svc != null && svc.uiState.value.currentItem != null) {
            if (playNextOnly) {
                svc.enqueuePlayNext(queueItems.first())
                libraryViewModel.showMessage("Queued \"${queueItems.first().title}\" to play next")
            } else {
                svc.addToQueue(queueItems)
                libraryViewModel.showMessage("Added ${queueItems.size} video(s) to queue")
            }
            libraryViewModel.clearSelection()
        } else {
            serviceConnection.bind()
            libraryViewModel.clearSelection()
            onPlayVideo(selected.first())
        }
    }

    DisposableEffect(Unit) {
        onDispose { serviceConnection.unbind() }
    }

    BackHandler(
        enabled = libraryState.isMultiSelectActive ||
            libraryState.isSearchActive ||
            (resolvedTab == HomeStartTab.FOLDERS && libraryState.selectedFolderBucketId != null)
    ) {
        when {
            libraryState.isMultiSelectActive -> libraryViewModel.clearSelection()
            libraryState.isSearchActive -> libraryViewModel.setSearchActive(false)
            resolvedTab == HomeStartTab.FOLDERS && libraryState.selectedFolderBucketId != null -> libraryViewModel.closeFolder()
        }
    }

    val isLibraryTab = resolvedTab == HomeStartTab.VIDEOS || resolvedTab == HomeStartTab.FOLDERS

    OceanBackdrop(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 700.dp

            Row(modifier = Modifier.fillMaxSize()) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = glassPalette.glassFill,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.size(12.dp))
                        HubDestination.entries.forEach { dest ->
                            NavigationRailItem(
                                selected = resolvedTab == dest.tab,
                                onClick = { selectTab(dest.tab) },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label) }
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        NavigationRailItem(
                            selected = false,
                            onClick = onOpenHistory,
                            icon = { Icon(Icons.Filled.History, contentDescription = stringResource(R.string.nav_history)) },
                            label = { Text(stringResource(R.string.nav_history)) }
                        )
                        NavigationRailItem(
                            selected = false,
                            onClick = onOpenSettings,
                            icon = { Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings_title)) },
                            label = { Text(stringResource(R.string.settings_title)) }
                        )
                    }
                }

                Scaffold(
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        when {
                            libraryState.isMultiSelectActive -> {
                                val totalSelected = libraryState.selectedVideoIds.size + libraryState.selectedFolderIds.size
                                val selectedVideos = libraryState.videos.filter { it.id in libraryState.selectedVideoIds }
                                TopAppBar(
                                    colors = TopAppBarDefaults.topAppBarColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.92f)
                                    ),
                                    title = { Text("$totalSelected selected") },
                                    navigationIcon = {
                                        IconButton(onClick = libraryViewModel::clearSelection) {
                                            Icon(Icons.Filled.Close, contentDescription = "Clear selection")
                                        }
                                    },
                                    actions = {
                                        IconButton(onClick = libraryViewModel::selectAllVisible) {
                                            Icon(Icons.Filled.SelectAll, contentDescription = "Select all")
                                        }
                                        if (selectedVideos.isNotEmpty()) {
                                            IconButton(
                                                onClick = { videosPendingAddToPlaylist = selectedVideos },
                                                modifier = Modifier.testTag("action_add_to_playlist")
                                            ) {
                                                Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = "Add to playlist")
                                            }
                                            if (selectedVideos.size == 1) {
                                                IconButton(
                                                    onClick = { enqueueVideos(selectedVideos, playNextOnly = true) },
                                                    modifier = Modifier.testTag("action_play_next")
                                                ) {
                                                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play next")
                                                }
                                            } else {
                                                IconButton(
                                                    onClick = { enqueueVideos(selectedVideos, playNextOnly = false) },
                                                    modifier = Modifier.testTag("action_add_to_queue")
                                                ) {
                                                    Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = "Add to queue")
                                                }
                                            }
                                            IconButton(
                                                onClick = { shareVideos(context, selectedVideos) },
                                                modifier = Modifier.testTag("action_share")
                                            ) {
                                                Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.share))
                                            }
                                            if (selectedVideos.size == 1) {
                                                IconButton(
                                                    onClick = { showRenameDialogFor = selectedVideos.first() },
                                                    modifier = Modifier.testTag("action_rename")
                                                ) {
                                                    Icon(Icons.Filled.DriveFileRenameOutline, contentDescription = stringResource(R.string.rename))
                                                }
                                                IconButton(
                                                    onClick = { libraryViewModel.loadProperties(selectedVideos.first()) },
                                                    modifier = Modifier.testTag("action_properties")
                                                ) {
                                                    Icon(Icons.Filled.Info, contentDescription = stringResource(R.string.properties))
                                                }
                                            }
                                            IconButton(
                                                onClick = { showDeleteConfirm = true },
                                                modifier = Modifier.testTag("action_delete")
                                            ) {
                                                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete))
                                            }
                                        }
                                        if (libraryState.selectedFolderIds.isNotEmpty()) {
                                            IconButton(
                                                onClick = libraryViewModel::hideOrUnhideSelectedFolders,
                                                modifier = Modifier.testTag("action_toggle_hide_folder")
                                            ) {
                                                Icon(Icons.Filled.VisibilityOff, contentDescription = stringResource(R.string.hide_folder))
                                            }
                                        }
                                    }
                                )
                            }

                            libraryState.isSearchActive && isLibraryTab -> {
                                TopAppBar(
                                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                                    title = {
                                        TextField(
                                            value = libraryState.searchQuery,
                                            onValueChange = libraryViewModel::updateSearchQuery,
                                            placeholder = { Text(stringResource(R.string.search_hint)) },
                                            singleLine = true,
                                            colors = TextFieldDefaults.colors(
                                                focusedContainerColor = Color.Transparent,
                                                unfocusedContainerColor = Color.Transparent,
                                                focusedIndicatorColor = Color.Transparent,
                                                unfocusedIndicatorColor = Color.Transparent
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("search_input")
                                        )
                                    },
                                    navigationIcon = {
                                        IconButton(onClick = { libraryViewModel.setSearchActive(false) }) {
                                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close search")
                                        }
                                    },
                                    actions = {
                                        if (libraryState.searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { libraryViewModel.updateSearchQuery("") }) {
                                                Icon(Icons.Filled.Close, contentDescription = "Clear")
                                            }
                                        }
                                    }
                                )
                            }

                            else -> {
                                TopAppBar(
                                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                                    navigationIcon = {
                                        if (resolvedTab == HomeStartTab.FOLDERS && libraryState.selectedFolderBucketId != null) {
                                            IconButton(onClick = { libraryViewModel.closeFolder() }) {
                                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to folders")
                                            }
                                        }
                                    },
                                    title = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (resolvedTab != HomeStartTab.FOLDERS || libraryState.selectedFolderBucketId == null) {
                                                Image(
                                                    painter = painterResource(R.drawable.ic_launcher_logo),
                                                    contentDescription = null,
                                                    modifier = Modifier
                                                        .size(28.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                            }
                                            Text(
                                                text = when {
                                                    resolvedTab == HomeStartTab.FOLDERS && libraryState.selectedFolderName != null ->
                                                        libraryState.selectedFolderName!!
                                                    resolvedTab == HomeStartTab.HOME -> stringResource(R.string.app_name)
                                                    else -> resolvedTab.label
                                                },
                                                maxLines = 1
                                            )
                                        }
                                    },
                                    actions = {
                                        if (isLibraryTab) {
                                            IconButton(
                                                onClick = { libraryViewModel.setSearchActive(true) },
                                                modifier = Modifier.testTag("search_button")
                                            ) {
                                                Icon(Icons.Filled.Search, contentDescription = "Search")
                                            }
                                            IconButton(
                                                onClick = libraryViewModel::toggleLayoutMode,
                                                modifier = Modifier.testTag("layout_toggle_button")
                                            ) {
                                                val isGrid = libraryState.settings.libraryLayoutMode == LibraryLayoutMode.GRID
                                                Icon(
                                                    imageVector = if (isGrid) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.GridView,
                                                    contentDescription = "Toggle grid or list"
                                                )
                                            }
                                            IconButton(
                                                onClick = { showSortDialog = true },
                                                modifier = Modifier.testTag("sort_button")
                                            ) {
                                                Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort")
                                            }
                                        } else {
                                            IconButton(
                                                onClick = onOpenHistory,
                                                modifier = Modifier.testTag("top_history_button")
                                            ) {
                                                Icon(Icons.Filled.History, contentDescription = stringResource(R.string.nav_history))
                                            }
                                        }
                                        IconButton(
                                            onClick = onOpenSettings,
                                            modifier = Modifier.testTag("top_settings_button")
                                        ) {
                                            Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings_title))
                                        }
                                        Box {
                                            IconButton(
                                                onClick = { showOverflowMenu = true },
                                                modifier = Modifier.testTag("library_more_button")
                                            ) {
                                                Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                                            }
                                            DropdownMenu(
                                                expanded = showOverflowMenu,
                                                onDismissRequest = { showOverflowMenu = false }
                                            ) {
                                                DropdownMenuItem(
                                                    text = { Text(stringResource(R.string.nav_history)) },
                                                    leadingIcon = { Icon(Icons.Filled.History, contentDescription = null) },
                                                    onClick = {
                                                        showOverflowMenu = false
                                                        onOpenHistory()
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text(stringResource(R.string.pick_video_file)) },
                                                    leadingIcon = { Icon(Icons.Filled.FolderOpen, contentDescription = null) },
                                                    onClick = {
                                                        showOverflowMenu = false
                                                        filePickerLauncher.launch(arrayOf("video/*"))
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = {
                                                        Text(
                                                            if (libraryState.settings.showHiddenFolders) "Hide hidden folders" else "Show hidden folders"
                                                        )
                                                    },
                                                    leadingIcon = {
                                                        Icon(
                                                            if (libraryState.settings.showHiddenFolders) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                                            contentDescription = null
                                                        )
                                                    },
                                                    onClick = {
                                                        showOverflowMenu = false
                                                        libraryViewModel.toggleShowHiddenFolders()
                                                    }
                                                )
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    },
                    bottomBar = {
                        if (!useNavigationRail && !libraryState.isMultiSelectActive) {
                            NavigationBar(
                                containerColor = glassPalette.glassFillStrong
                            ) {
                                HubDestination.entries.forEach { dest ->
                                    NavigationBarItem(
                                        selected = resolvedTab == dest.tab,
                                        onClick = { selectTab(dest.tab) },
                                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                                        label = { Text(dest.label, maxLines = 1) },
                                        modifier = Modifier.testTag("nav_tab_${dest.tab.name.lowercase()}")
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (resolvedTab) {
                            HomeStartTab.HOME -> {
                                HomeDashboardContent(
                                    dashboard = dashboardState,
                                    hasStoragePermission = libraryState.hasStoragePermission,
                                    showThumbnails = libraryState.settings.showThumbnails,
                                    onResumePlay = onPlayHistoryItem,
                                    onDismissResume = homeViewModel::dismissResumeCard,
                                    onPlayVideo = onPlayVideo,
                                    onOpenHistory = onOpenHistory,
                                    onRequestPermission = { permissionLauncher.launch(requiredPermission) },
                                    onPickVideoFile = { filePickerLauncher.launch(arrayOf("video/*")) },
                                    onOpenNetworkTab = { selectTab(HomeStartTab.NETWORK) }
                                )
                            }

                            HomeStartTab.VIDEOS, HomeStartTab.FOLDERS -> {
                                LibraryTabContent(
                                    state = libraryState,
                                    showFolders = resolvedTab == HomeStartTab.FOLDERS,
                                    onRefresh = libraryViewModel::refreshLibrary,
                                    onRequestPermission = { permissionLauncher.launch(requiredPermission) },
                                    onPickVideoFile = { filePickerLauncher.launch(arrayOf("video/*")) },
                                    onOpenNetworkTab = { selectTab(HomeStartTab.NETWORK) },
                                    onFolderClick = { folder ->
                                        if (libraryState.isMultiSelectActive) {
                                            libraryViewModel.toggleFolderSelection(folder.bucketId)
                                        } else {
                                            libraryViewModel.openFolder(folder)
                                        }
                                    },
                                    onFolderLongClick = { folder ->
                                        libraryViewModel.toggleFolderSelection(folder.bucketId)
                                    },
                                    onPlayFolder = { folder ->
                                        val first = libraryViewModel.firstVideoInFolder(folder.bucketId)
                                        if (first != null) {
                                            onPlayVideo(first)
                                        } else {
                                            libraryViewModel.openFolder(folder)
                                        }
                                    },
                                    onVideoClick = { video ->
                                        if (libraryState.isMultiSelectActive) {
                                            libraryViewModel.toggleVideoSelection(video.id)
                                        } else {
                                            onPlayVideo(video)
                                        }
                                    },
                                    onVideoLongClick = { video ->
                                        libraryViewModel.toggleVideoSelection(video.id)
                                    }
                                )
                            }

                            HomeStartTab.PLAYLISTS -> {
                                PlaylistsTabContent(
                                    playlists = playlists,
                                    showThumbnails = libraryState.settings.showThumbnails,
                                    onOpenPlaylist = onOpenPlaylistDetail,
                                    onPlayPlaylist = { summary: PlaylistSummary ->
                                        onPlayPlaylist(summary.id, "", summary.name)
                                    },
                                    onCreatePlaylist = { name ->
                                        playlistsViewModel.createPlaylist(name)
                                    },
                                    onRenamePlaylist = playlistsViewModel::renamePlaylist,
                                    onDeletePlaylist = playlistsViewModel::deletePlaylist
                                )
                            }

                            HomeStartTab.NETWORK -> {
                                NetworkTabContent(onPlayStreamUrl = onPlayStreamUrl)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSortDialog) {
        SortDialog(
            currentField = libraryState.settings.sortField,
            currentDirection = libraryState.settings.sortDirection,
            onDismiss = { showSortDialog = false },
            onApply = { field, direction ->
                showSortDialog = false
                libraryViewModel.updateSort(field, direction)
            }
        )
    }

    showRenameDialogFor?.let { target ->
        RenameVideoDialog(
            currentTitle = target.title,
            onDismiss = { showRenameDialogFor = null },
            onConfirm = { newBaseName ->
                showRenameDialogFor = null
                libraryViewModel.renameVideo(target, newBaseName)
            }
        )
    }

    videosPendingAddToPlaylist?.let { chosen ->
        AddToPlaylistDialog(
            playlists = playlists,
            onDismiss = { videosPendingAddToPlaylist = null },
            onSelectPlaylist = { playlistId ->
                playlistsViewModel.addVideosToPlaylist(playlistId, chosen)
                videosPendingAddToPlaylist = null
                libraryViewModel.clearSelection()
                libraryViewModel.showMessage("Added ${chosen.size} video(s) to playlist")
            },
            onCreateNewPlaylist = { name ->
                playlistsViewModel.createPlaylist(name, chosen)
                videosPendingAddToPlaylist = null
                libraryViewModel.clearSelection()
                libraryViewModel.showMessage("Created playlist \"$name\"")
            }
        )
    }

    if (showDeleteConfirm) {
        val count = libraryState.selectedVideoIds.size
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete $count video(s)?") },
            text = { Text("Selected videos will be permanently removed from your device.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    libraryViewModel.deleteSelectedVideos()
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (libraryState.isLoadingProperties || libraryState.propertiesVideo != null) {
        PropertiesDialog(
            properties = libraryState.propertiesVideo,
            isLoading = libraryState.isLoadingProperties,
            onDismiss = libraryViewModel::dismissProperties
        )
    }
}

private enum class HubDestination(
    val tab: HomeStartTab,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    HOME(HomeStartTab.HOME, "Home", Icons.Filled.Home),
    VIDEOS(HomeStartTab.VIDEOS, "Videos", Icons.Filled.VideoLibrary),
    FOLDERS(HomeStartTab.FOLDERS, "Folders", Icons.Filled.Folder),
    PLAYLISTS(HomeStartTab.PLAYLISTS, "Playlists", Icons.AutoMirrored.Filled.PlaylistPlay),
    NETWORK(HomeStartTab.NETWORK, "Network", Icons.Filled.Public)
}
