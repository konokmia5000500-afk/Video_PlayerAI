package com.example.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Full-screen subtle blue/navy/ice atmospheric backdrop shared across app hubs.
 */
@Composable
fun OceanBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val palette = LocalGlassPalette.current
    val brush = Brush.verticalGradient(
        colors = listOf(
            palette.gradientTop,
            palette.gradientBottom
        )
    )
    Box(
        modifier = modifier.background(brush),
        content = content
    )
}

/**
 * Clean glassmorphic + subtle neumorphic container with translucent tint, crisp hairline border,
 * and refined shadow elevation without heavy blur performance overhead.
 */
@Composable
fun GlassSurfaceCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(18.dp),
    strong: Boolean = false,
    elevation: Dp = 4.dp,
    highlightColor: Color? = null,
    content: @Composable () -> Unit
) {
    val palette = LocalGlassPalette.current
    val fillColor = if (strong) palette.glassFillStrong else palette.glassFill
    val borderColor = highlightColor ?: palette.glassBorder

    Surface(
        modifier = modifier.shadow(
            elevation = elevation,
            shape = shape,
            ambientColor = palette.accentGlow.copy(alpha = if (palette.isDark) 0.14f else 0.10f),
            spotColor = palette.accentGlow.copy(alpha = if (palette.isDark) 0.18f else 0.12f)
        ),
        shape = shape,
        color = fillColor,
        border = BorderStroke(1.dp, borderColor),
        content = content
    )
}

/**
 * Soft pill modifier combining glass fill and subtle rim stroke.
 */
@Composable
fun Modifier.glassPill(
    shape: Shape = RoundedCornerShape(50),
    active: Boolean = false
): Modifier {
    val palette = LocalGlassPalette.current
    val bg = if (active) palette.accentGlow.copy(alpha = 0.22f) else palette.glassFill
    val border = if (active) palette.accentGlow.copy(alpha = 0.65f) else palette.glassBorder
    return this
        .background(bg, shape)
        .border(1.dp, border, shape)
}
