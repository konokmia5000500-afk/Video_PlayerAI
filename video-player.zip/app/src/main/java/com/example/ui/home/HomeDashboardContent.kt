package com.example.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.AppContainer
import com.example.R
import com.example.data.model.LibrarySummary
import com.example.data.model.VideoItem
import com.example.data.model.WatchHistoryItem
import com.example.ui.library.VideoThumbnailImage
import com.example.ui.theme.GlassSurfaceCard
import com.example.ui.theme.LocalGlassPalette
import com.example.util.TimeFormatters

@Composable
fun HomeDashboardContent(
    dashboard: HomeDashboardState,
    hasStoragePermission: Boolean,
    showThumbnails: Boolean,
    onResumePlay: (WatchHistoryItem) -> Unit,
    onDismissResume: (String) -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onOpenHistory: () -> Unit,
    onRequestPermission: () -> Unit,
    onPickVideoFile: () -> Unit,
    onOpenNetworkTab: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val imageLoader = remember(context) { AppContainer.getInstance(context).imageLoader }

    LazyColumn(
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = modifier.fillMaxSize()
    ) {
        // Hero Resume Watching Card (only shown when meaningful resume history exists)
        dashboard.resumeCandidate?.let { candidate ->
            item(key = "resume_watching_card") {
                ResumeWatchingCard(
                    item = candidate,
                    showThumbnails = showThumbnails,
                    onResume = { onResumePlay(candidate) },
                    onDismiss = { onDismissResume(candidate.mediaKey) },
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // Library Summary Strip
        item(key = "library_summary_strip") {
            LibrarySummaryStrip(
                summary = dashboard.summary,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        if (!hasStoragePermission && dashboard.summary.totalVideos == 0) {
            item(key = "permission_banner") {
                GlassSurfaceCard(
                    strong = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = stringResource(R.string.permission_required_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.permission_required_body),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = onRequestPermission) {
                                Text(stringResource(R.string.grant_permission))
                            }
                            OutlinedButton(onClick = onPickVideoFile) {
                                Text(stringResource(R.string.pick_video_file))
                            }
                        }
                    }
                }
            }
        }

        if (dashboard.continueWatching.isNotEmpty()) {
            item(key = "continue_watching_section") {
                SectionHeaderRow(
                    title = stringResource(R.string.continue_watching),
                    actionLabel = stringResource(R.string.nav_history),
                    onActionClick = onOpenHistory
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(dashboard.continueWatching, key = { "cw_${it.mediaKey}" }) { item ->
                        HistoryCarouselCard(
                            item = item,
                            showThumbnails = showThumbnails,
                            imageLoader = imageLoader,
                            onClick = { onResumePlay(item) }
                        )
                    }
                }
            }
        }

        if (dashboard.recentlyPlayed.isNotEmpty()) {
            item(key = "recently_played_section") {
                SectionHeaderRow(
                    title = stringResource(R.string.recently_played),
                    actionLabel = stringResource(R.string.nav_history),
                    onActionClick = onOpenHistory
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(dashboard.recentlyPlayed, key = { "rp_${it.mediaKey}" }) { item ->
                        HistoryCarouselCard(
                            item = item,
                            showThumbnails = showThumbnails,
                            imageLoader = imageLoader,
                            onClick = { onResumePlay(item) }
                        )
                    }
                }
            }
        }

        if (dashboard.recentlyAdded.isNotEmpty()) {
            item(key = "recently_added_section") {
                SectionHeaderRow(title = stringResource(R.string.recently_added))
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(dashboard.recentlyAdded, key = { "ra_${it.id}" }) { video ->
                        VideoCarouselCard(
                            video = video,
                            showThumbnails = showThumbnails,
                            imageLoader = imageLoader,
                            badgeText = if (video.isNew) "NEW" else null,
                            onClick = { onPlayVideo(video) }
                        )
                    }
                }
            }
        }

        if (dashboard.frequentlyPlayed.isNotEmpty()) {
            item(key = "frequently_played_section") {
                SectionHeaderRow(title = stringResource(R.string.frequently_played))
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(dashboard.frequentlyPlayed, key = { "fp_${it.id}" }) { video ->
                        VideoCarouselCard(
                            video = video,
                            showThumbnails = showThumbnails,
                            imageLoader = imageLoader,
                            badgeText = "${video.playCount}x",
                            onClick = { onPlayVideo(video) }
                        )
                    }
                }
            }
        }

        // Quick Tools Row
        item(key = "quick_actions") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = onPickVideoFile,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pick File", maxLines = 1)
                }
                FilledTonalButton(
                    onClick = onOpenNetworkTab,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Public, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open URL", maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun ResumeWatchingCard(
    item: WatchHistoryItem,
    showThumbnails: Boolean,
    onResume: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val imageLoader = remember(context) { AppContainer.getInstance(context).imageLoader }
    val glassPalette = LocalGlassPalette.current

    GlassSurfaceCard(
        strong = true,
        highlightColor = glassPalette.accentGlow.copy(alpha = 0.45f),
        elevation = 8.dp,
        shape = RoundedCornerShape(20.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("resume_watching_card")
            .clickable(onClick = onResume)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                ) {
                    Text(
                        text = stringResource(R.string.resume_watching),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("dismiss_resume_card_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Dismiss resume card",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 132.dp, height = 76.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    if (showThumbnails && item.thumbnailUri.isNotBlank()) {
                        VideoThumbnailImage(
                            uri = item.thumbnailUri,
                            imageLoader = imageLoader,
                            contentDescription = item.title,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = if (item.isNetworkStream) Icons.Filled.Public else Icons.Filled.PlayArrow,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))
                                )
                            )
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    val timeLabel = when {
                        item.isCompleted -> "Finished • Watch again"
                        item.durationMs > 0L ->
                            "${TimeFormatters.formatDuration(item.positionMs)} / ${TimeFormatters.formatDuration(item.durationMs)}"
                        else -> TimeFormatters.formatDuration(item.positionMs)
                    }
                    Text(
                        text = timeLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onResume,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("resume_watching_cta")
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (item.isCompleted) "Replay" else stringResource(R.string.resume_button),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            if (item.durationMs > 0L && !item.isCompleted && item.positionMs > 0L) {
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { item.progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
    }
}

@Composable
private fun LibrarySummaryStrip(
    summary: LibrarySummary,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SummaryStatPill(
            icon = Icons.Filled.VideoLibrary,
            value = "${summary.totalVideos}",
            label = "Videos",
            modifier = Modifier.weight(1f)
        )
        SummaryStatPill(
            icon = Icons.Filled.Folder,
            value = "${summary.totalFolders}",
            label = "Folders",
            modifier = Modifier.weight(1f)
        )
        SummaryStatPill(
            icon = Icons.Filled.Storage,
            value = TimeFormatters.formatFileSize(summary.totalSizeBytes),
            label = "Storage",
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun SummaryStatPill(
    icon: ImageVector,
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {
    GlassSurfaceCard(
        shape = RoundedCornerShape(14.dp),
        elevation = 2.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SectionHeaderRow(
    title: String,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        if (actionLabel != null && onActionClick != null) {
            TextButton(onClick = onActionClick) {
                Text(actionLabel)
                Spacer(modifier = Modifier.width(2.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun HistoryCarouselCard(
    item: WatchHistoryItem,
    showThumbnails: Boolean,
    imageLoader: coil.ImageLoader,
    onClick: () -> Unit
) {
    GlassSurfaceCard(
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .width(174.dp)
            .clickable(onClick = onClick)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (showThumbnails && item.thumbnailUri.isNotBlank()) {
                    VideoThumbnailImage(
                        uri = item.thumbnailUri,
                        imageLoader = imageLoader,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = if (item.isNetworkStream) Icons.Filled.Public else Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                if (item.progressFraction > 0.01f && !item.isCompleted) {
                    LinearProgressIndicator(
                        progress = { item.progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .align(Alignment.BottomCenter),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color.Black.copy(alpha = 0.55f)
                    )
                }
            }
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val sub = if (item.isCompleted) {
                    "Watched"
                } else if (item.durationMs > 0L) {
                    "${TimeFormatters.formatDuration(item.positionMs)} left"
                } else {
                    "Resume"
                }
                Text(
                    text = sub,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun VideoCarouselCard(
    video: VideoItem,
    showThumbnails: Boolean,
    imageLoader: coil.ImageLoader,
    badgeText: String?,
    onClick: () -> Unit
) {
    GlassSurfaceCard(
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .width(174.dp)
            .clickable(onClick = onClick)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (showThumbnails) {
                    VideoThumbnailImage(
                        uri = video.contentUri,
                        imageLoader = imageLoader,
                        contentDescription = video.title,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                if (badgeText != null) {
                    Surface(
                        shape = RoundedCornerShape(5.dp),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                    ) {
                        Text(
                            text = badgeText,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(5.dp),
                    color = Color.Black.copy(alpha = 0.76f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                ) {
                    Text(
                        text = TimeFormatters.formatDuration(video.durationMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = video.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${TimeFormatters.formatResolutionBadge(video.width, video.height)} • ${TimeFormatters.formatFileSize(video.sizeBytes)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}
