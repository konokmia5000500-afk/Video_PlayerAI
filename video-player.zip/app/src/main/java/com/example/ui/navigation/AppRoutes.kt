package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
data object MainHubRoute

@Serializable
data class PlayerRoute(
    val startUri: String,
    val folderBucketId: String = "",
    val playlistId: Long = -1L,
    val title: String = "",
    val isNetworkStream: Boolean = false,
    val initialPositionMs: Long = -1L
)

@Serializable
data object HistoryRoute

@Serializable
data class PlaylistDetailRoute(
    val playlistId: Long
)

@Serializable
data object SettingsRoute
