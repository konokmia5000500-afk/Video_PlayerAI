package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
data object LibraryRoute

@Serializable
data class PlayerRoute(
    val startUri: String,
    val folderBucketId: String = "",
    val title: String = "",
    val isNetworkStream: Boolean = false
)

@Serializable
data object SettingsRoute
