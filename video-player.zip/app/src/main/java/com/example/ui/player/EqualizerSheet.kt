package com.example.ui.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.preferences.PlayerSettings
import com.example.player.audio.EqualizerPreset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerBottomSheet(
    settings: PlayerSettings,
    presets: List<EqualizerPreset>,
    bandFreqsHz: List<Int>,
    onUpdate: (
        enabled: Boolean,
        presetIndex: Int,
        bandLevels: List<Int>,
        bassBoost: Int,
        virtualizer: Int
    ) -> Unit,
    onDismiss: () -> Unit
) {
    var enabled by remember(settings.eqEnabled) { mutableStateOf(settings.eqEnabled) }
    var presetIndex by remember(settings.eqPresetIndex) { mutableIntStateOf(settings.eqPresetIndex) }
    val bands = remember(settings.eqBandLevels) {
        mutableStateListOf<Int>().apply { addAll(settings.eqBandLevels) }
    }
    var bassBoost by remember(settings.bassBoostStrength) { mutableIntStateOf(settings.bassBoostStrength) }
    var virtualizer by remember(settings.virtualizerStrength) { mutableIntStateOf(settings.virtualizerStrength) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("5-Band Equalizer", style = MaterialTheme.typography.titleLarge)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        presetIndex = 0
                        for (i in 0 until 5) bands[i] = 0
                        bassBoost = 0
                        virtualizer = 0
                        onUpdate(enabled, 0, bands.toList(), 0, 0)
                    }) {
                        Text("Reset")
                    }
                    Switch(
                        checked = enabled,
                        onCheckedChange = {
                            enabled = it
                            onUpdate(enabled, presetIndex, bands.toList(), bassBoost, virtualizer)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (presets.isNotEmpty()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    itemsIndexed(presets) { index, preset ->
                        FilterChip(
                            selected = presetIndex == index,
                            onClick = {
                                presetIndex = index
                                preset.bandNormalized.forEachIndexed { idx, value ->
                                    if (idx < bands.size) bands[idx] = value
                                }
                                bassBoost = preset.bassBoost
                                virtualizer = preset.virtualizer
                                onUpdate(enabled, presetIndex, bands.toList(), bassBoost, virtualizer)
                            },
                            label = { Text(preset.name) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            for (i in 0 until 5) {
                val freq = bandFreqsHz.getOrElse(i) { 1000 }
                val freqLabel = if (freq >= 1000) "${freq / 1000} kHz" else "$freq Hz"
                val level = bands.getOrElse(i) { 0 }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = freqLabel,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.weight(0.22f)
                    )
                    Slider(
                        value = level.toFloat(),
                        onValueChange = { v ->
                            bands[i] = v.toInt()
                            presetIndex = -1
                            onUpdate(enabled, presetIndex, bands.toList(), bassBoost, virtualizer)
                        },
                        valueRange = -1000f..1000f,
                        enabled = enabled,
                        modifier = Modifier.weight(0.63f)
                    )
                    Text(
                        text = "${(level / 100f).toInt()} dB",
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.weight(0.15f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Bass Boost", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(0.25f))
                Slider(
                    value = bassBoost.toFloat(),
                    onValueChange = {
                        bassBoost = it.toInt()
                        onUpdate(enabled, presetIndex, bands.toList(), bassBoost, virtualizer)
                    },
                    valueRange = 0f..1000f,
                    enabled = enabled,
                    modifier = Modifier.weight(0.6f)
                )
                Text("${bassBoost / 10}%", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(0.15f))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Virtualizer", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(0.25f))
                Slider(
                    value = virtualizer.toFloat(),
                    onValueChange = {
                        virtualizer = it.toInt()
                        onUpdate(enabled, presetIndex, bands.toList(), bassBoost, virtualizer)
                    },
                    valueRange = 0f..1000f,
                    enabled = enabled,
                    modifier = Modifier.weight(0.6f)
                )
                Text("${virtualizer / 10}%", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(0.15f))
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
