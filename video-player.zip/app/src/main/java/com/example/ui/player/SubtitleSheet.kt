package com.example.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.PlayerSettings
import com.example.data.preferences.SubtitleBackgroundStyle
import com.example.player.subtitle.SubtitleEncodings
import com.example.player.subtitle.SubtitleTrackInfo
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SubtitleBottomSheet(
    tracks: List<SubtitleTrackInfo>,
    subtitlesEnabled: Boolean,
    subtitleDelayMs: Long,
    settings: PlayerSettings,
    onToggleEnabled: (Boolean) -> Unit,
    onSelectTrack: (SubtitleTrackInfo?) -> Unit,
    onPickExternalFile: () -> Unit,
    onDelayChangeMs: (Long) -> Unit,
    onFontSizeChange: (Int) -> Unit,
    onTextColorChange: (Long) -> Unit,
    onBackgroundStyleChange: (SubtitleBackgroundStyle) -> Unit,
    onBottomPaddingChange: (Float) -> Unit,
    onEncodingChange: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val colorOptions = listOf(
        0xFFFFFFFF to "White",
        0xFF38BDF8 to "Sky",
        0xFFFACC15 to "Yellow",
        0xFF86EFAC to "Mint"
    )

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Subtitles",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Switch(
                    checked = subtitlesEnabled,
                    onCheckedChange = onToggleEnabled,
                    modifier = Modifier.testTag("subtitle_enable_switch")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onPickExternalFile,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pick_subtitle_file_button")
            ) {
                Icon(Icons.Filled.FolderOpen, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open Subtitle File (.srt, .ass, .ssa, .vtt, .sub, .smi)")
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Available Tracks",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectTrack(null) }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = !subtitlesEnabled || tracks.none { it.isSelected },
                    onClick = { onSelectTrack(null) }
                )
                Text("Off", modifier = Modifier.padding(start = 6.dp))
            }

            tracks.forEach { track ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectTrack(track) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = subtitlesEnabled && track.isSelected,
                        onClick = { onSelectTrack(track) }
                    )
                    Text(track.label, modifier = Modifier.padding(start = 6.dp))
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

            // Subtitle synchronization delay
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sync Offset: ${String.format(Locale.US, "%+.1fs", subtitleDelayMs / 1000f)}",
                    style = MaterialTheme.typography.titleSmall
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onDelayChangeMs(subtitleDelayMs - 250L) }) {
                        Icon(Icons.Filled.Remove, contentDescription = "Delay -0.25s")
                    }
                    IconButton(onClick = { onDelayChangeMs(subtitleDelayMs + 250L) }) {
                        Icon(Icons.Filled.Add, contentDescription = "Delay +0.25s")
                    }
                    TextButton(onClick = { onDelayChangeMs(0L) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset")
                    }
                }
            }

            Slider(
                value = subtitleDelayMs.toFloat(),
                onValueChange = { onDelayChangeMs((it / 100f).toLong() * 100L) },
                valueRange = -10_000f..10_000f
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

            Text(
                text = "Appearance & Encoding",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Font Size", style = MaterialTheme.typography.bodyMedium)
                Text("${settings.subtitleFontSizeSp} sp", color = MaterialTheme.colorScheme.primary)
            }
            Slider(
                value = settings.subtitleFontSizeSp.toFloat(),
                onValueChange = { onFontSizeChange(it.toInt()) },
                valueRange = 12f..34f
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Vertical Position", style = MaterialTheme.typography.bodyMedium)
                Text("${(settings.subtitleBottomPaddingFraction * 100).toInt()}%", color = MaterialTheme.colorScheme.primary)
            }
            Slider(
                value = settings.subtitleBottomPaddingFraction,
                onValueChange = onBottomPaddingChange,
                valueRange = 0.02f..0.25f
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text("Text Color", style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                colorOptions.forEach { (hex, _) ->
                    val selected = settings.subtitleTextColorHex == hex
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(Color(hex))
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                shape = CircleShape
                            )
                            .clickable { onTextColorChange(hex) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text("Background Style", style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SubtitleBackgroundStyle.entries.forEach { style ->
                    FilterChip(
                        selected = settings.subtitleBackgroundStyle == style,
                        onClick = { onBackgroundStyleChange(style) },
                        label = { Text(style.label) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text("Character Encoding", style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SubtitleEncodings.supported.forEach { enc ->
                    FilterChip(
                        selected = settings.subtitleEncoding.equals(enc, ignoreCase = true),
                        onClick = { onEncodingChange(enc) },
                        label = { Text(enc) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
