package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CinemaBluePrimary = Color(0xFF38BDF8)
val CinemaBlueOnPrimary = Color(0xFF00263A)
val CinemaBlueContainer = Color(0xFF0C4A6E)
val CinemaBlueOnContainer = Color(0xFFE0F2FE)

val CinemaIndigoSecondary = Color(0xFF818CF8)
val CinemaCyanTertiary = Color(0xFF2DD4BF)

val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF121720)
val DarkSurfaceVariant = Color(0xFF1C2331)
val DarkOutline = Color(0xFF2D3748)

val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF05070A)
val AmoledSurfaceVariant = Color(0xFF11151C)

val LightPrimary = Color(0xFF0284C7)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFE0F2FE)
val LightOnPrimaryContainer = Color(0xFF0C4A6E)
val LightBackground = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8EEF5)
