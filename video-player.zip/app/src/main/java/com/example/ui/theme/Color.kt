package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Ocean & Sky-Cyan Palette
val SkyCyanPrimary = Color(0xFF38BDF8)
val SoftCyanAccent = Color(0xFF67E8F9)
val DeepNavyInk = Color(0xFF03233A)
val RoyalBlueAccent = Color(0xFF2563EB)
val OceanBlueContainer = Color(0xFF0C4A78)
val PaleIceOnContainer = Color(0xFFE0F4FF)

// Deep Navy Glass Theme (Default Dark)
val NavyCanvasTop = Color(0xFF061326)
val NavyCanvasBottom = Color(0xFF0A1D3A)
val NavySurface = Color(0xFF0B1C35)
val NavyGlassSurface = Color(0xFF12284A)
val NavyGlassElevated = Color(0xFF18345E)
val NavyBorderGlow = Color(0xFF2E5B94)
val NavyOnSurface = Color(0xFFF0F7FF)
val NavyOnSurfaceMuted = Color(0xFF93B4D8)

// Midnight Blue AMOLED Theme
val MidnightBackground = Color(0xFF020712)
val MidnightSurface = Color(0xFF071124)
val MidnightGlass = Color(0xFF0E1E3B)
val MidnightGlassHigh = Color(0xFF142A50)
val MidnightOutline = Color(0xFF224273)

// Pale Sky-Blue Glass Theme (Light)
val IceBackground = Color(0xFFEDF5FF)
val IceCanvasBottom = Color(0xFFF7FBFF)
val IceSurface = Color(0xFFFFFFFF)
val IceSurfaceVariant = Color(0xFFDCEEFF)
val IceSurfaceHigh = Color(0xFFE6F2FF)
val IceSurfaceHighest = Color(0xFFD5E9FF)
val IceOutline = Color(0xFFA9CEF2)
val IcePrimary = Color(0xFF0284C7)
val IceSecondary = Color(0xFF0891B2)
val IceTertiary = Color(0xFF1D4ED8)
val IceOnSurface = Color(0xFF0A1F3C)
val IceOnSurfaceMuted = Color(0xFF44658A)
