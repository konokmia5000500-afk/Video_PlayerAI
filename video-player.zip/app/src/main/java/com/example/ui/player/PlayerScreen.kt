package com.example.ui.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.graphics.Rect
import android.os.Build
import android.view.LayoutInflater
import android.view.SurfaceView
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toAndroidRectF
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.toRect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.player.engine.AspectRatioMode
import com.example.player.engine.PlayerEngineType
import com.example.ui.library.PropertiesDialog
import com.example.util.ActivitySystemHelpers
import com.example.util.ActivitySystemHelpers.findActivity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    startUri: String,
    folderBucketId: String,
    title: String,
    isInPipMode: Boolean,
    onRegisterLeaveHintPip: ((() -> Unit)?) -> Unit,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: PlayerViewModel = viewModel()
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    val service by viewModel.serviceFlow.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val chromeState by viewModel.chromeState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val propertiesPair by viewModel.propertiesState.collectAsStateWithLifecycle()

    var hudState by remember { mutableStateOf<GestureHudState>(GestureHudState.None) }
    var hudClearJob by remember { mutableStateOf<Job?>(null) }
    var videoSourceRect by remember { mutableStateOf<Rect?>(null) }

    var showSpeedDialog by remember { mutableStateOf(false) }
    var showDecoderDialog by remember { mutableStateOf(false) }
    var showAudioTrackDialog by remember { mutableStateOf(false) }
    var showAspectDialog by remember { mutableStateOf(false) }
    var showOrientationDialog by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }

    fun showTransientHud(state: GestureHudState, durationMs: Long = 1100L) {
        hudClearJob?.cancel()
        hudState = state
        if (state !is GestureHudState.None) {
            hudClearJob = coroutineScope.launch {
                delay(durationMs)
                hudState = GestureHudState.None
            }
        }
    }

    LaunchedEffect(startUri, folderBucketId, title) {
        viewModel.startPlaybackIfNeeded(startUri, folderBucketId, title)
    }

    // Apply orientation, immersive fullscreen, keepScreenOn
    LaunchedEffect(
        activity,
        chromeState.orientationMode,
        playbackState.videoWidth,
        playbackState.videoHeight
    ) {
        val act = activity ?: return@LaunchedEffect
        ActivitySystemHelpers.applyOrientation(
            activity = act,
            mode = chromeState.orientationMode,
            videoWidth = playbackState.videoWidth,
            videoHeight = playbackState.videoHeight
        )
    }

    LaunchedEffect(activity, chromeState.isFullscreenImmersive, isInPipMode) {
        val act = activity ?: return@LaunchedEffect
        ActivitySystemHelpers.setImmersiveMode(act, chromeState.isFullscreenImmersive && !isInPipMode)
    }

    LaunchedEffect(activity, settings.keepScreenOn, playbackState.isPlaying) {
        val act = activity ?: return@LaunchedEffect
        ActivitySystemHelpers.setKeepScreenOn(act, settings.keepScreenOn && playbackState.isPlaying)
    }

    // Configure Android 12+ auto-PiP and pre-12 userLeaveHint PiP
    val pipSupported = remember(context) { ActivitySystemHelpers.isPipSupported(context) }

    fun triggerPip() {
        val act = activity ?: return
        if (!pipSupported || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val params = ActivitySystemHelpers.buildPipParams(
            context = context,
            videoWidth = playbackState.videoWidth,
            videoHeight = playbackState.videoHeight,
            sourceRectHint = videoSourceRect,
            autoEnter = settings.autoPip && playbackState.isPlaying,
            isPlaying = playbackState.isPlaying
        )
        runCatching { act.enterPictureInPictureMode(params) }
    }

    LaunchedEffect(
        activity,
        pipSupported,
        settings.autoPip,
        playbackState.isPlaying,
        playbackState.videoWidth,
        playbackState.videoHeight,
        videoSourceRect
    ) {
        val act = activity ?: return@LaunchedEffect
        if (pipSupported && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = ActivitySystemHelpers.buildPipParams(
                context = context,
                videoWidth = playbackState.videoWidth,
                videoHeight = playbackState.videoHeight,
                sourceRectHint = videoSourceRect,
                autoEnter = settings.autoPip && playbackState.isPlaying,
                isPlaying = playbackState.isPlaying
            )
            runCatching { act.setPictureInPictureParams(params) }
        }
    }

    DisposableEffect(settings.autoPip, playbackState.isPlaying, pipSupported) {
        if (pipSupported && Build.VERSION.SDK_INT in Build.VERSION_CODES.O until Build.VERSION_CODES.S) {
            onRegisterLeaveHintPip {
                if (settings.autoPip && playbackState.isPlaying) {
                    triggerPip()
                }
            }
        } else {
            onRegisterLeaveHintPip(null)
        }
        onDispose { onRegisterLeaveHintPip(null) }
    }

    // PiP RemoteAction BroadcastReceiver
    DisposableEffect(context, service) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action != ActivitySystemHelpers.ACTION_PIP_CONTROL) return
                when (intent.getIntExtra(ActivitySystemHelpers.EXTRA_PIP_COMMAND, 0)) {
                    ActivitySystemHelpers.PIP_CMD_PLAY_PAUSE -> viewModel.togglePlayPause()
                    ActivitySystemHelpers.PIP_CMD_PREV -> viewModel.playPrevious()
                    ActivitySystemHelpers.PIP_CMD_NEXT -> viewModel.playNext()
                }
            }
        }
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(ActivitySystemHelpers.ACTION_PIP_CONTROL),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        onDispose {
            runCatching { context.unregisterReceiver(receiver) }
        }
    }

    // Handle background pause when backgroundPlay == false and not in PiP
    DisposableEffect(lifecycleOwner, service, activity) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                val inPip = activity?.isInPictureInPictureMode == true
                service?.handleAppBackgrounded(inPipMode = inPip)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Restore system bars, orientation, brightness, and screen-on when exiting PlayerScreen
    DisposableEffect(activity) {
        onDispose {
            activity?.let { act ->
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                ActivitySystemHelpers.setWindowBrightness(act, WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE)
                ActivitySystemHelpers.setKeepScreenOn(act, false)
                ActivitySystemHelpers.setImmersiveMode(act, false)
            }
        }
    }

    BackHandler(enabled = !isInPipMode) {
        if (chromeState.isLocked) {
            viewModel.onSingleTap()
        } else {
            if (!settings.backgroundPlay) {
                service?.pause()
            }
            onBack()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clipToBounds()
            .onGloballyPositioned { coords ->
                videoSourceRect = coords.boundsInWindow().toAndroidRectF().toRect()
            }
            .then(
                if (isInPipMode) {
                    Modifier
                } else {
                    Modifier.mxPlayerGestures(
                        settings = settings,
                        isLocked = chromeState.isLocked,
                        currentScale = chromeState.zoomScale,
                        currentPanX = chromeState.panX,
                        currentPanY = chromeState.panY,
                        getCurrentPositionMs = { service?.getCurrentPositionMs() ?: 0L },
                        getDurationMs = { service?.getDurationMs() ?: 0L },
                        getInitialBrightness = {
                            val current = activity?.window?.attributes?.screenBrightness ?: -1f
                            if (current < 0f) 0.5f else current
                        },
                        getInitialVolumePercent = {
                            val boost = playbackState.volumeBoostPercent
                            if (boost > 100) {
                                boost
                            } else {
                                val max = viewModel.getMaxSystemVolume()
                                val cur = viewModel.getCurrentSystemVolume()
                                ((cur.toFloat() / max.toFloat()) * 100f).toInt()
                            }
                        },
                        onSingleTap = viewModel::onSingleTap,
                        onDoubleTapSeek = { deltaMs, isForward ->
                            viewModel.seekBy(deltaMs, fromDoubleTap = true)
                            showTransientHud(
                                GestureHudState.DoubleTapSeek(settings.doubleTapSeekSeconds, isForward),
                                durationMs = 750L
                            )
                        },
                        onDoubleTapPlayPause = {
                            val willPlay = !playbackState.isPlaying
                            viewModel.togglePlayPause(fromDoubleTap = true)
                            showTransientHud(
                                GestureHudState.DoubleTapPlayPause(willPlay),
                                durationMs = 750L
                            )
                        },
                        onBrightnessDrag = { b ->
                            activity?.let { ActivitySystemHelpers.setWindowBrightness(it, b) }
                        },
                        onVolumeDrag = { pct ->
                            viewModel.setCombinedVolumePercent(pct)
                        },
                        onSeekDrag = { targetMs, _, isFinal ->
                            viewModel.seekTo(targetMs, isScrubbing = !isFinal)
                        },
                        onZoomPan = viewModel::updateZoomAndPan,
                        onHudChange = { newHud ->
                            hudClearJob?.cancel()
                            hudState = newHud
                        }
                    )
                }
            )
    ) {
        // Video Surface Container with Aspect Ratio + Pinch Zoom/Pan (ONLY in Player)
        VideoSurfaceContainer(
            engineType = playbackState.engineType,
            aspectRatioMode = playbackState.aspectRatioMode,
            videoWidth = playbackState.videoWidth,
            videoHeight = playbackState.videoHeight,
            zoomScale = if (isInPipMode) 1f else chromeState.zoomScale,
            panX = if (isInPipMode) 0f else chromeState.panX,
            panY = if (isInPipMode) 0f else chromeState.panY,
            service = service
        )

        if (playbackState.isBuffering && !isInPipMode) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        playbackState.errorMessage?.let { err ->
            if (!isInPipMode) {
                Surface(
                    color = Color.Black.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                ) {
                    Text(
                        text = err,
                        color = Color.White,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }

        if (!isInPipMode) {
            GestureHudOverlay(hudState = hudState)

            PlayerControlsOverlay(
                playbackState = playbackState,
                chromeState = chromeState,
                positionStateFlow = viewModel.positionState,
                isPipSupported = pipSupported,
                onBack = {
                    if (!settings.backgroundPlay) {
                        service?.pause()
                    }
                    onBack()
                },
                onDecoderClick = { showDecoderDialog = true },
                onAudioTrackClick = { showAudioTrackDialog = true },
                onMuteClick = viewModel::toggleMute,
                onPipClick = { triggerPip() },
                onRotateClick = { showOrientationDialog = true },
                onLockClick = viewModel::toggleLock,
                onPreviousClick = viewModel::playPrevious,
                onPlayPauseClick = { viewModel.togglePlayPause(fromDoubleTap = false) },
                onNextClick = viewModel::playNext,
                onStepFrameClick = viewModel::stepFrameForward,
                onSpeedClick = { showSpeedDialog = true },
                onAspectRatioClick = {
                    val mode = viewModel.cycleAspectRatio()
                    showTransientHud(GestureHudState.ToastLabel("Aspect: ${mode.label}"), 900L)
                },
                onEqualizerClick = { showEqualizerSheet = true },
                onFullscreenClick = viewModel::toggleFullscreenImmersive,
                onToggleRemainingTime = viewModel::toggleRemainingTime,
                onSeek = viewModel::seekTo,
                onResetZoom = viewModel::resetZoom,
                onAbRepeatClick = viewModel::toggleAbRepeat,
                onClearAbRepeat = viewModel::clearAbRepeat,
                onSleepTimerClick = { showSleepTimerDialog = true },
                onLoopClick = {
                    val loop = viewModel.cycleLoopMode()
                    showTransientHud(GestureHudState.ToastLabel("Loop: ${loop.label}"), 900L)
                },
                onShuffleClick = {
                    val on = viewModel.toggleShuffle()
                    showTransientHud(GestureHudState.ToastLabel(if (on) "Shuffle On" else "Shuffle Off"), 900L)
                },
                onPropertiesClick = viewModel::loadCurrentVideoProperties,
                onSettingsClick = onOpenSettings
            )
        }
    }

    if (showSpeedDialog) {
        SpeedDialog(
            currentSpeed = playbackState.speed,
            onSelectSpeed = viewModel::setSpeed,
            onDismiss = { showSpeedDialog = false }
        )
    }

    if (showDecoderDialog) {
        DecoderDialog(
            currentMode = playbackState.decoderMode,
            currentEngine = playbackState.engineType,
            onSelectMode = viewModel::setDecoderMode,
            onSwitchEngine = { engine -> service?.switchEngineManually(engine) },
            onDismiss = { showDecoderDialog = false }
        )
    }

    if (showAudioTrackDialog) {
        AudioTrackDialog(
            tracks = playbackState.audioTracks,
            onSelectTrack = viewModel::selectAudioTrack,
            onDismiss = { showAudioTrackDialog = false }
        )
    }

    if (showAspectDialog) {
        AspectRatioDialog(
            currentMode = playbackState.aspectRatioMode,
            onSelectMode = viewModel::setAspectRatio,
            onDismiss = { showAspectDialog = false }
        )
    }

    if (showOrientationDialog) {
        OrientationDialog(
            currentMode = chromeState.orientationMode,
            onSelectMode = viewModel::setOrientationMode,
            onDismiss = { showOrientationDialog = false }
        )
    }

    if (showSleepTimerDialog) {
        SleepTimerDialog(
            currentRemainingMs = playbackState.sleepTimerRemainingMs,
            onSetMinutes = viewModel::setSleepTimerMinutes,
            onDismiss = { showSleepTimerDialog = false }
        )
    }

    if (showEqualizerSheet) {
        EqualizerBottomSheet(
            settings = settings,
            presets = viewModel.getEqualizerPresets(),
            bandFreqsHz = viewModel.getEqualizerBandFreqsHz(),
            onUpdate = viewModel::updateEqualizer,
            onDismiss = { showEqualizerSheet = false }
        )
    }

    if (propertiesPair.second || propertiesPair.first != null) {
        PropertiesDialog(
            properties = propertiesPair.first,
            isLoading = propertiesPair.second,
            onDismiss = viewModel::dismissProperties
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoSurfaceContainer(
    engineType: PlayerEngineType,
    aspectRatioMode: AspectRatioMode,
    videoWidth: Int,
    videoHeight: Int,
    zoomScale: Float,
    panX: Float,
    panY: Float,
    service: com.example.player.service.PlaybackService?
) {
    val density = LocalDensity.current

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                scaleX = zoomScale
                scaleY = zoomScale
                translationX = panX
                translationY = panY
            },
        contentAlignment = Alignment.Center
    ) {
        val surfaceModifier = when (aspectRatioMode) {
            AspectRatioMode.FIT,
            AspectRatioMode.FILL,
            AspectRatioMode.STRETCH,
            AspectRatioMode.CROP -> Modifier.fillMaxSize()
            AspectRatioMode.RATIO_16_9 -> Modifier.fillMaxSize().aspectRatio(16f / 9f, matchHeightConstraintsFirst = maxWidth / maxHeight > 16f / 9f)
            AspectRatioMode.RATIO_4_3 -> Modifier.fillMaxSize().aspectRatio(4f / 3f, matchHeightConstraintsFirst = maxWidth / maxHeight > 4f / 3f)
            AspectRatioMode.ACTUAL_100 -> {
                if (videoWidth > 0 && videoHeight > 0) {
                    val wDp = with(density) { videoWidth.toDp() }
                    val hDp = with(density) { videoHeight.toDp() }
                    Modifier.width(wDp).height(hDp)
                } else {
                    Modifier.fillMaxSize()
                }
            }
        }

        val exoResizeMode = when (aspectRatioMode) {
            AspectRatioMode.FIT, AspectRatioMode.ACTUAL_100 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            AspectRatioMode.FILL, AspectRatioMode.STRETCH, AspectRatioMode.RATIO_16_9, AspectRatioMode.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            AspectRatioMode.CROP -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        }

        if (engineType == PlayerEngineType.EXOPLAYER) {
            AndroidView(
                factory = { ctx ->
                    val inflated = LayoutInflater.from(ctx)
                        .inflate(R.layout.exo_player_surface_view, null, false) as PlayerView
                    inflated.apply {
                        useController = false
                        resizeMode = exoResizeMode
                        player = service?.getExoPlayer()
                    }
                },
                update = { playerView ->
                    val targetPlayer = service?.getExoPlayer()
                    if (playerView.player !== targetPlayer) {
                        playerView.player = targetPlayer
                    }
                    if (playerView.resizeMode != exoResizeMode) {
                        playerView.resizeMode = exoResizeMode
                    }
                },
                onRelease = { playerView ->
                    playerView.player = null
                },
                modifier = surfaceModifier
            )
        } else {
            AndroidView(
                factory = { ctx ->
                    SurfaceView(ctx).also { sv ->
                        service?.attachLibVlcSurface(sv)
                    }
                },
                update = { sv ->
                    service?.attachLibVlcSurface(sv)
                },
                onRelease = {
                    service?.detachLibVlcSurface()
                },
                modifier = surfaceModifier
            )
        }
    }
}
