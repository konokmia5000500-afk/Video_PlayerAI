package com.example.player.engine

import androidx.compose.runtime.Immutable
import com.example.data.preferences.DecoderMode
import com.example.player.subtitle.SubtitleTrackInfo

enum class AspectRatioMode(val label: String) {
    FIT("Fit"),
    FILL("Fill"),
    STRETCH("Stretch"),
    CROP("Crop"),
    ACTUAL_100("100%"),
    RATIO_16_9("16:9"),
    RATIO_4_3("4:3")
}

enum class LoopMode(val label: String) {
    OFF("Off"),
    ONE("Loop One"),
    ALL("Loop All")
}

enum class PlayerEngineType(val label: String) {
    EXOPLAYER("ExoPlayer"),
    LIBVLC("LibVLC")
}

@Immutable
data class AudioTrackInfo(
    val id: String,
    val label: String,
    val language: String,
    val channelCount: Int,
    val groupIndex: Int,
    val trackIndex: Int,
    val vlcTrackId: Int = -1,
    val isSelected: Boolean
)

@Immutable
data class PlaybackQueueItem(
    val uri: String,
    val title: String,
    val displayName: String = title,
    val path: String = "",
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val mimeType: String = "video/*",
    val folderBucketId: String = "",
    val isNetworkStream: Boolean = false
)

@Immutable
data class PlaybackUiState(
    val currentItem: PlaybackQueueItem? = null,
    val currentIndex: Int = 0,
    val queueSize: Int = 0,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val engineType: PlayerEngineType = PlayerEngineType.EXOPLAYER,
    val decoderMode: DecoderMode = DecoderMode.HW_PLUS,
    val activeVideoCodec: String = "",
    val activeAudioCodec: String = "",
    val speed: Float = 1.0f,
    val aspectRatioMode: AspectRatioMode = AspectRatioMode.FIT,
    val loopMode: LoopMode = LoopMode.OFF,
    val shuffleEnabled: Boolean = false,
    val isMuted: Boolean = false,
    val volumeBoostPercent: Int = 100,
    val audioDelayMs: Long = 0L,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val audioTracks: List<AudioTrackInfo> = emptyList(),
    val subtitleTracks: List<SubtitleTrackInfo> = emptyList(),
    val subtitlesEnabled: Boolean = true,
    val subtitleDelayMs: Long = 0L,
    val abRepeatA: Long? = null,
    val abRepeatB: Long? = null,
    val sleepTimerRemainingMs: Long = 0L,
    val errorMessage: String? = null,
    val playbackEnded: Boolean = false
)

/**
 * Isolated position state updated only while controls are visible so the main player screen
 * and gesture layers do not recompose every 250ms.
 */
@Immutable
data class PlaybackPositionState(
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPositionMs: Long = 0L
)
