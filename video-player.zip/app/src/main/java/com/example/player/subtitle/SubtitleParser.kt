package com.example.player.subtitle

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.charset.Charset

/**
 * Fast, dependency-free multi-format subtitle parser supporting SRT, VTT, ASS/SSA, SUB, and SMI,
 * plus sibling file auto-discovery for local folders.
 */
object SubtitleParser {

    private val HTML_OR_ASS_TAG_REGEX = Regex("""<[^>]*>|\{[^}]*\}""")
    private val SRT_VTT_TIME_REGEX = Regex(
        """(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[,.](\d{1,3})"""
    )
    private val MICRODVD_LINE_REGEX = Regex("""^\{(\d+)\}\{(\d+)\}(.+)$""")
    private val SMI_SYNC_REGEX = Regex("""<SYNC\s+Start\s*=\s*["']?(\d+)["']?\s*>""", RegexOption.IGNORE_CASE)

    suspend fun loadExternalSubtitles(
        context: Context,
        uri: Uri,
        encodingName: String = "UTF-8",
        fpsHint: Float = 23.976f
    ): List<SubtitleCue> = withContext(Dispatchers.IO) {
        val rawBytes = runCatching {
            if (uri.scheme == "file" || uri.scheme.isNullOrBlank()) {
                val f = File(uri.path ?: uri.toString())
                if (f.exists() && f.length() < 12L * 1024L * 1024L) f.readBytes() else null
            } else {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    input.readBytes()
                }
            }
        }.getOrNull() ?: return@withContext emptyList()

        val charset = runCatching { Charset.forName(encodingName) }.getOrDefault(Charsets.UTF_8)
        val text = decodeBytes(rawBytes, charset)
        val fileName = uri.lastPathSegment.orEmpty()
        parse(text = text, format = SubtitleFormat.fromFilename(fileName), fps = fpsHint)
    }

    fun decodeBytes(bytes: ByteArray, fallbackCharset: Charset = Charsets.UTF_8): String {
        if (bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() &&
            bytes[1] == 0xBB.toByte() &&
            bytes[2] == 0xBF.toByte()
        ) {
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        return String(bytes, fallbackCharset)
    }

    fun parse(
        text: String,
        format: SubtitleFormat? = null,
        fps: Float = 23.976f
    ): List<SubtitleCue> {
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n').trim()
        if (normalized.isEmpty()) return emptyList()

        val detected = format ?: detectFormat(normalized)
        val rawCues = when (detected) {
            SubtitleFormat.SRT -> parseSrt(normalized)
            SubtitleFormat.VTT -> parseVtt(normalized)
            SubtitleFormat.ASS, SubtitleFormat.SSA -> parseAss(normalized)
            SubtitleFormat.SUB -> parseSub(normalized, fps)
            SubtitleFormat.SMI -> parseSmi(normalized)
        }
        return rawCues
            .filter { it.endMs > it.startMs && it.text.isNotBlank() }
            .sortedBy { it.startMs }
    }

    fun findActiveCueText(
        cues: List<SubtitleCue>,
        playbackPositionMs: Long,
        offsetMs: Long
    ): String? {
        if (cues.isEmpty()) return null
        val lookupTime = playbackPositionMs - offsetMs
        if (lookupTime < 0L) return null

        // Binary search to locate the last cue whose startMs <= lookupTime
        var low = 0
        var high = cues.lastIndex
        var candidate = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (cues[mid].startMs <= lookupTime) {
                candidate = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        if (candidate < 0) return null

        // Collect all overlapping cues active around candidate (ASS/SRT can have slight overlaps)
        val activeLines = ArrayList<String>(2)
        var idx = candidate
        while (idx >= 0 && cues[idx].startMs >= lookupTime - 15_000L) {
            val cue = cues[idx]
            if (lookupTime in cue.startMs..cue.endMs) {
                activeLines.add(0, cue.text)
            }
            idx--
        }
        return if (activeLines.isEmpty()) null else activeLines.joinToString("\n")
    }

    suspend fun discoverMatchingSubtitleUris(videoPath: String): List<Pair<String, String>> =
        withContext(Dispatchers.IO) {
            if (videoPath.isBlank()) return@withContext emptyList()
            val videoFile = File(videoPath)
            val parent = videoFile.parentFile ?: return@withContext emptyList()
            if (!parent.exists() || !parent.canRead()) return@withContext emptyList()

            val baseName = videoFile.nameWithoutExtension
            val files = parent.listFiles()?.toList().orEmpty()
            files.mapNotNull { file ->
                if (!file.isFile) return@mapNotNull null
                val ext = file.extension.lowercase()
                if (ext !in SubtitleFormat.supportedExtensions) return@mapNotNull null
                val nameNoExt = file.nameWithoutExtension
                val matchesVideo = nameNoExt.equals(baseName, ignoreCase = true) ||
                    nameNoExt.startsWith("$baseName.", ignoreCase = true) ||
                    nameNoExt.startsWith("${baseName}_", ignoreCase = true) ||
                    nameNoExt.startsWith("${baseName}-", ignoreCase = true)
                if (!matchesVideo) return@mapNotNull null
                Uri.fromFile(file).toString() to file.name
            }.sortedBy { it.second }
        }

    private fun detectFormat(text: String): SubtitleFormat {
        val upper = text.take(512).uppercase()
        return when {
            upper.startsWith("WEBVTT") -> SubtitleFormat.VTT
            upper.contains("[SCRIPT INFO]") || upper.contains("[V4+ STYLES]") || upper.contains("DIALOGUE:") -> SubtitleFormat.ASS
            upper.contains("<SAMI>") || upper.contains("<SYNC ") -> SubtitleFormat.SMI
            MICRODVD_LINE_REGEX.containsMatchIn(text.lineSequence().firstOrNull().orEmpty()) -> SubtitleFormat.SUB
            else -> SubtitleFormat.SRT
        }
    }

    private fun parseSrt(text: String): List<SubtitleCue> {
        val blocks = text.split(Regex("\n{2,}"))
        val result = ArrayList<SubtitleCue>(blocks.size)
        for (block in blocks) {
            val lines = block.lines().map { it.trimEnd() }.filter { it.isNotEmpty() }
            if (lines.size < 2) continue
            val timingLineIdx = lines.indexOfFirst { it.contains("-->") }
            if (timingLineIdx < 0) continue
            val (startMs, endMs) = parseArrowTiming(lines[timingLineIdx]) ?: continue
            val payload = lines.drop(timingLineIdx + 1)
                .joinToString("\n")
                .let(::cleanMarkup)
            if (payload.isNotBlank()) {
                result.add(SubtitleCue(startMs, endMs, payload))
            }
        }
        return result
    }

    private fun parseVtt(text: String): List<SubtitleCue> {
        val withoutHeader = text.removePrefix("WEBVTT").trimStart()
        return parseSrt(withoutHeader)
    }

    private fun parseAss(text: String): List<SubtitleCue> {
        val result = ArrayList<SubtitleCue>()
        var formatFields: List<String>? = null
        for (rawLine in text.lineSequence()) {
            val line = rawLine.trim()
            if (line.startsWith("Format:", ignoreCase = true) && formatFields == null) {
                formatFields = line.substringAfter(':').split(',').map { it.trim().lowercase() }
            } else if (line.startsWith("Dialogue:", ignoreCase = true)) {
                val fields = formatFields ?: listOf(
                    "layer", "start", "end", "style", "name", "marginl", "marginr", "marginv", "effect", "text"
                )
                val body = line.substringAfter(':').trimStart()
                val parts = body.split(',', limit = fields.size)
                if (parts.size < fields.size) continue
                val startIdx = fields.indexOf("start").takeIf { it >= 0 } ?: 1
                val endIdx = fields.indexOf("end").takeIf { it >= 0 } ?: 2
                val textIdx = fields.indexOf("text").takeIf { it >= 0 } ?: (fields.size - 1)
                val startMs = parseAssTimestamp(parts[startIdx].trim()) ?: continue
                val endMs = parseAssTimestamp(parts[endIdx].trim()) ?: continue
                val cleanedText = parts[textIdx]
                    .replace("\\N", "\n")
                    .replace("\\n", "\n")
                    .replace("\\h", " ")
                    .let(::cleanMarkup)
                if (cleanedText.isNotBlank()) {
                    result.add(SubtitleCue(startMs, endMs, cleanedText))
                }
            }
        }
        return result
    }

    private fun parseSub(text: String, fps: Float): List<SubtitleCue> {
        val safeFps = if (fps > 1f) fps else 23.976f
        val result = ArrayList<SubtitleCue>()
        for (line in text.lineSequence()) {
            val match = MICRODVD_LINE_REGEX.matchEntire(line.trim()) ?: continue
            val startFrame = match.groupValues[1].toLongOrNull() ?: continue
            val endFrame = match.groupValues[2].toLongOrNull() ?: continue
            val startMs = ((startFrame * 1000f) / safeFps).toLong()
            val endMs = ((endFrame * 1000f) / safeFps).toLong()
            val payload = match.groupValues[3]
                .replace("|", "\n")
                .let(::cleanMarkup)
            if (payload.isNotBlank()) {
                result.add(SubtitleCue(startMs, endMs, payload))
            }
        }
        return result
    }

    private fun parseSmi(text: String): List<SubtitleCue> {
        val matches = SMI_SYNC_REGEX.findAll(text).toList()
        if (matches.isEmpty()) return emptyList()
        val result = ArrayList<SubtitleCue>(matches.size)
        for (i in matches.indices) {
            val startMs = matches[i].groupValues[1].toLongOrNull() ?: continue
            val contentStart = matches[i].range.last + 1
            val contentEnd = if (i + 1 < matches.size) matches[i + 1].range.first else text.length
            val rawChunk = text.substring(contentStart, contentEnd)
                .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
                .replace("&nbsp;", " ")
            val cleaned = cleanMarkup(rawChunk)
            val endMs = if (i + 1 < matches.size) {
                matches[i + 1].groupValues[1].toLongOrNull()?.coerceAtLeast(startMs) ?: (startMs + 4000L)
            } else {
                startMs + 4000L
            }
            if (cleaned.isNotBlank()) {
                result.add(SubtitleCue(startMs, endMs, cleaned))
            }
        }
        return result
    }

    private fun parseArrowTiming(line: String): Pair<Long, Long>? {
        val parts = line.split("-->")
        if (parts.size < 2) return null
        val start = parseFlexibleTimestamp(parts[0].trim()) ?: return null
        val endToken = parts[1].trim().substringBefore(' ')
        val end = parseFlexibleTimestamp(endToken) ?: return null
        return start to end
    }

    private fun parseFlexibleTimestamp(raw: String): Long? {
        val match = SRT_VTT_TIME_REGEX.find(raw) ?: return null
        val hasHours = match.groupValues[1].isNotEmpty()
        val hours = if (hasHours) match.groupValues[1].toLong() else 0L
        val minutes = if (hasHours) match.groupValues[2].toLong() else match.groupValues[2].toLong()
        val seconds = match.groupValues[3].toLong()
        val millisRaw = match.groupValues[4].padEnd(3, '0').take(3).toLong()
        return (hours * 3600L + minutes * 60L + seconds) * 1000L + millisRaw
    }

    private fun parseAssTimestamp(raw: String): Long? {
        val parts = raw.split(':')
        if (parts.size != 3) return null
        val hours = parts[0].toLongOrNull() ?: return null
        val minutes = parts[1].toLongOrNull() ?: return null
        val secParts = parts[2].split('.', ',')
        if (secParts.size != 2) return null
        val seconds = secParts[0].toLongOrNull() ?: return null
        val centis = secParts[1].padEnd(2, '0').take(2).toLongOrNull() ?: return null
        return (hours * 3600L + minutes * 60L + seconds) * 1000L + centis * 10L
    }

    private fun cleanMarkup(raw: String): String {
        return raw.replace(HTML_OR_ASS_TAG_REGEX, "")
            .lines()
            .joinToString("\n") { it.trim() }
            .trim()
    }
}
