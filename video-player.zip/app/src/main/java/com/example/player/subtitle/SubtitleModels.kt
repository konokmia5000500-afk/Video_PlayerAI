package com.example.player.subtitle

import androidx.compose.runtime.Immutable

enum class SubtitleFormat(val extension: String, val label: String) {
    SRT("srt", "SubRip (.srt)"),
    VTT("vtt", "WebVTT (.vtt)"),
    ASS("ass", "Advanced SubStation (.ass)"),
    SSA("ssa", "SubStation Alpha (.ssa)"),
    SUB("sub", "MicroDVD (.sub)"),
    SMI("smi", "SAMI (.smi)");

    companion object {
        val supportedExtensions = entries.map { it.extension }.toSet()

        fun fromFilename(name: String): SubtitleFormat? {
            val ext = name.substringAfterLast('.', "").lowercase()
            return entries.firstOrNull { it.extension == ext }
        }
    }
}

@Immutable
data class SubtitleCue(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

@Immutable
data class SubtitleTrackInfo(
    val id: String,
    val label: String,
    val language: String = "und",
    val isSelected: Boolean = false,
    val isExternal: Boolean = false,
    val uri: String? = null,
    val groupIndex: Int = -1,
    val trackIndex: Int = -1,
    val vlcTrackId: Int = -1
)

object SubtitleEncodings {
    val supported = listOf(
        "UTF-8",
        "Windows-1252",
        "ISO-8859-1",
        "Windows-1256",
        "UTF-16"
    )
}
