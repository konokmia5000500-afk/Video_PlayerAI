package com.example.player.service

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Binder
import android.os.IBinder
import android.view.SurfaceView
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.AppContainer
import com.example.MainActivity
import com.example.data.preferences.DecoderMode
import com.example.player.audio.AudioEffectsManager
import com.example.player.engine.AspectRatioMode
import com.example.player.engine.AudioTrackInfo
import com.example.player.engine.LibVlcFallbackPlayer
import com.example.player.engine.LoopMode
import com.example.player.engine.PlaybackPositionState
import com.example.player.engine.PlaybackQueueItem
import com.example.player.engine.PlaybackUiState
import com.example.player.engine.PlayerEngineType
import com.example.player.subtitle.SubtitleCue
import com.example.player.subtitle.SubtitleParser
import com.example.player.subtitle.SubtitleTrackInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    inner class LocalBinder : Binder() {
        val service: PlaybackService get() = this@PlaybackService
    }

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var appContainer: AppContainer
    private val audioEffects = AudioEffectsManager()

    private var exoPlayer: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private var libVlcPlayer: LibVlcFallbackPlayer? = null

    private var queue: List<PlaybackQueueItem> = emptyList()
    private var backgroundPlayEnabled: Boolean = false
    private var resumePlaybackEnabled: Boolean = true
    private var autoPlayNextEnabled: Boolean = true
    private var subtitleEncoding: String = "UTF-8"
    private var subtitleDefaultEnabled: Boolean = true
    private var isForegroundUiActive: Boolean = false

    private var sleepTimerJob: Job? = null
    private var abMonitorJob: Job? = null
    private var positionTickerJob: Job? = null
    private var progressSaverJob: Job? = null
    private var subtitleTickerJob: Job? = null
    private var controlsVisibleForTicker: Boolean = false
    private var activeSurfaceView: SurfaceView? = null

    private var externalSubtitles: List<SubtitleTrackInfo> = emptyList()
    private var selectedExternalSubtitleUri: String? = null
    private var externalCues: List<SubtitleCue> = emptyList()
    private var embeddedCueText: String? = null

    private val _uiState = MutableStateFlow(PlaybackUiState())
    val uiState: StateFlow<PlaybackUiState> = _uiState.asStateFlow()

    private val _positionState = MutableStateFlow(PlaybackPositionState())
    val positionState: StateFlow<PlaybackPositionState> = _positionState.asStateFlow()

    private val _queueFlow = MutableStateFlow<List<PlaybackQueueItem>>(emptyList())
    val queueFlow: StateFlow<List<PlaybackQueueItem>> = _queueFlow.asStateFlow()

    private val _activeSubtitleText = MutableStateFlow<String?>(null)
    val activeSubtitleText: StateFlow<String?> = _activeSubtitleText.asStateFlow()

    private val exoListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (_uiState.value.engineType != PlayerEngineType.EXOPLAYER) return
            _uiState.update { it.copy(isPlaying = isPlaying, playbackEnded = false) }
            if (isPlaying) {
                startPeriodicProgressSaver()
            } else {
                stopPeriodicProgressSaver()
                persistCurrentPosition()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (_uiState.value.engineType != PlayerEngineType.EXOPLAYER) return
            val player = exoPlayer ?: return
            when (playbackState) {
                Player.STATE_BUFFERING -> _uiState.update { it.copy(isBuffering = true) }
                Player.STATE_READY -> {
                    _uiState.update { it.copy(isBuffering = false, errorMessage = null) }
                    _positionState.value = PlaybackPositionState(
                        positionMs = player.currentPosition.coerceAtLeast(0L),
                        durationMs = player.duration.coerceAtLeast(0L),
                        bufferedPositionMs = player.bufferedPosition.coerceAtLeast(0L)
                    )
                    if (player.audioSessionId > 0) {
                        audioEffects.attachToAudioSession(player.audioSessionId)
                    }
                }
                Player.STATE_ENDED -> {
                    stopPeriodicProgressSaver()
                    _uiState.update { it.copy(isPlaying = false, isBuffering = false, playbackEnded = true) }
                    persistCurrentPosition(completed = true)
                    handleTrackEnded()
                }
                else -> _uiState.update { it.copy(isBuffering = false) }
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (_uiState.value.engineType != PlayerEngineType.EXOPLAYER) return
            if (videoSize.width > 0 && videoSize.height > 0) {
                _uiState.update { it.copy(videoWidth = videoSize.width, videoHeight = videoSize.height) }
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            if (_uiState.value.engineType != PlayerEngineType.EXOPLAYER) return
            val player = exoPlayer ?: return
            val idx = player.currentMediaItemIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0))
            val item = queue.getOrNull(idx)
            embeddedCueText = null
            _uiState.update {
                it.copy(
                    currentIndex = idx,
                    currentItem = item,
                    abRepeatA = null,
                    abRepeatB = null,
                    playbackEnded = false
                )
            }
            if (item != null) {
                onNewItemActivated(item)
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            if (_uiState.value.engineType != PlayerEngineType.EXOPLAYER) return
            val audio = extractExoAudioTracks(tracks)
            val embeddedSubs = extractExoSubtitleTracks(tracks)
            val videoCodec = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.isSelected }
                ?.let { grp ->
                    (0 until grp.length).firstOrNull { grp.isTrackSelected(it) }?.let { idx ->
                        grp.getTrackFormat(idx).codecs ?: grp.getTrackFormat(idx).sampleMimeType
                    }
                }.orEmpty()
            val audioCodec = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.isSelected }
                ?.let { grp ->
                    (0 until grp.length).firstOrNull { grp.isTrackSelected(it) }?.let { idx ->
                        grp.getTrackFormat(idx).codecs ?: grp.getTrackFormat(idx).sampleMimeType
                    }
                }.orEmpty()

            _uiState.update {
                it.copy(
                    audioTracks = audio,
                    subtitleTracks = combineSubtitleTracks(embeddedSubs),
                    activeVideoCodec = videoCodec,
                    activeAudioCodec = audioCodec
                )
            }
        }

        override fun onCues(cueGroup: CueGroup) {
            if (_uiState.value.engineType != PlayerEngineType.EXOPLAYER) return
            if (selectedExternalSubtitleUri != null || !_uiState.value.subtitlesEnabled) {
                embeddedCueText = null
                return
            }
            val combined = cueGroup.cues
                .mapNotNull { it.text?.toString()?.trim()?.takeIf(String::isNotEmpty) }
                .joinToString("\n")
                .ifBlank { null }
            embeddedCueText = combined
            _activeSubtitleText.value = combined
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            if (audioSessionId > 0) {
                audioEffects.attachToAudioSession(audioSessionId)
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val currentItem = _uiState.value.currentItem ?: return
            val currentPos = exoPlayer?.currentPosition?.coerceAtLeast(0L) ?: 0L
            switchToLibVlcFallback(currentItem, startPositionMs = currentPos)
        }
    }

    override fun onCreate() {
        super.onCreate()
        appContainer = AppContainer.getInstance(applicationContext)
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(applicationContext).build()
        )
        buildOrReplaceExoPlayer(DecoderMode.HW_PLUS)
        val player = requireNotNull(exoPlayer)
        val sessionActivityIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_PLAYER, true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityIntent)
            .build()

        serviceScope.launch {
            appContainer.settingsRepository.settingsFlow.collect { settings ->
                backgroundPlayEnabled = settings.backgroundPlay
                resumePlaybackEnabled = settings.resumePlayback
                autoPlayNextEnabled = settings.autoPlayNext
                subtitleDefaultEnabled = settings.subtitleEnabledByDefault
                if (subtitleEncoding != settings.subtitleEncoding) {
                    subtitleEncoding = settings.subtitleEncoding
                    selectedExternalSubtitleUri?.let { reloadExternalSubtitle(it) }
                }
                audioEffects.updateEqualizer(
                    enabled = settings.eqEnabled,
                    bandNormalized = settings.eqBandLevels,
                    bassBoostLevel = settings.bassBoostStrength,
                    virtualizerLevel = settings.virtualizerStrength
                )
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        if (intent?.action == SERVICE_INTERFACE) {
            return super.onBind(intent)
        }
        return binder
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        persistCurrentPosition()
        val player = exoPlayer
        if (!backgroundPlayEnabled || (player != null && !player.playWhenReady && _uiState.value.engineType == PlayerEngineType.EXOPLAYER)) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        persistCurrentPosition()
        stopPeriodicProgressSaver()
        subtitleTickerJob?.cancel()
        positionTickerJob?.cancel()
        sleepTimerJob?.cancel()
        abMonitorJob?.cancel()
        libVlcPlayer?.release()
        libVlcPlayer = null
        mediaSession?.release()
        mediaSession = null
        exoPlayer?.removeListener(exoListener)
        exoPlayer?.release()
        exoPlayer = null
        audioEffects.release()
        serviceScope.cancel()
        super.onDestroy()
    }

    fun getExoPlayer(): ExoPlayer? = exoPlayer

    fun getAudioEffectsManager(): AudioEffectsManager = audioEffects

    fun setUiForegroundActive(active: Boolean) {
        isForegroundUiActive = active
    }

    fun handleAppBackgrounded(inPipMode: Boolean) {
        if (inPipMode) return
        if (!backgroundPlayEnabled && _uiState.value.isPlaying) {
            pause()
        }
        persistCurrentPosition()
    }

    fun setPositionTickerActive(controlsVisible: Boolean) {
        controlsVisibleForTicker = controlsVisible
        if (controlsVisible) {
            if (positionTickerJob?.isActive != true) {
                positionTickerJob = serviceScope.launch {
                    while (isActive && controlsVisibleForTicker) {
                        syncPositionNow()
                        delay(250L)
                    }
                }
            }
        } else {
            positionTickerJob?.cancel()
            positionTickerJob = null
        }
    }

    fun syncPositionNow() {
        when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> {
                val player = exoPlayer ?: return
                _positionState.value = PlaybackPositionState(
                    positionMs = player.currentPosition.coerceAtLeast(0L),
                    durationMs = player.duration.coerceAtLeast(0L),
                    bufferedPositionMs = player.bufferedPosition.coerceAtLeast(0L)
                )
            }
            PlayerEngineType.LIBVLC -> {
                val vlc = libVlcPlayer ?: return
                _positionState.value = PlaybackPositionState(
                    positionMs = vlc.getCurrentPositionMs(),
                    durationMs = vlc.getDurationMs(),
                    bufferedPositionMs = vlc.getCurrentPositionMs()
                )
            }
        }
    }

    fun attachLibVlcSurface(surfaceView: SurfaceView) {
        activeSurfaceView = surfaceView
        libVlcPlayer?.attachSurface(surfaceView)
    }

    fun detachLibVlcSurface() {
        activeSurfaceView = null
        libVlcPlayer?.detachSurface()
    }

    fun loadQueue(
        items: List<PlaybackQueueItem>,
        startIndex: Int,
        overrideStartPositionMs: Long = -1L
    ) {
        if (items.isEmpty()) return
        val safeIndex = startIndex.coerceIn(0, items.lastIndex)
        queue = items
        _queueFlow.value = items

        serviceScope.launch {
            val settings = appContainer.settingsRepository.settingsFlow.first()
            resumePlaybackEnabled = settings.resumePlayback
            autoPlayNextEnabled = settings.autoPlayNext
            backgroundPlayEnabled = settings.backgroundPlay
            subtitleEncoding = settings.subtitleEncoding
            subtitleDefaultEnabled = settings.subtitleEnabledByDefault

            val targetItem = items[safeIndex]
            val savedPos = when {
                overrideStartPositionMs >= 0L -> overrideStartPositionMs
                settings.resumePlayback -> appContainer.videoLibraryRepository.getSavedPosition(targetItem.uri)
                else -> 0L
            }

            if (_uiState.value.decoderMode != settings.defaultDecoderMode) {
                buildOrReplaceExoPlayer(settings.defaultDecoderMode)
            }

            _uiState.update {
                it.copy(
                    currentItem = targetItem,
                    currentIndex = safeIndex,
                    queueSize = items.size,
                    speed = settings.defaultSpeed,
                    decoderMode = settings.defaultDecoderMode,
                    aspectRatioMode = settings.defaultAspectRatioMode,
                    loopMode = settings.defaultLoopMode,
                    subtitlesEnabled = settings.subtitleEnabledByDefault,
                    audioDelayMs = 0L,
                    subtitleDelayMs = 0L,
                    abRepeatA = null,
                    abRepeatB = null,
                    errorMessage = null,
                    playbackEnded = false
                )
            }

            if (settings.defaultSleepTimerMinutes > 0 && sleepTimerJob?.isActive != true) {
                setSleepTimerMinutes(settings.defaultSleepTimerMinutes)
            }

            onNewItemActivated(targetItem)

            if (shouldPreferLibVlc(targetItem.uri, targetItem.mimeType)) {
                switchToLibVlcFallback(targetItem, startPositionMs = savedPos)
            } else {
                startExoQueue(items, safeIndex, savedPos, settings.defaultSpeed)
            }
        }
    }

    fun enqueuePlayNext(item: PlaybackQueueItem) {
        if (queue.isEmpty()) {
            loadQueue(listOf(item), 0)
            return
        }
        val insertIdx = (_uiState.value.currentIndex + 1).coerceAtMost(queue.size)
        val mutable = queue.toMutableList()
        mutable.add(insertIdx, item)
        queue = mutable
        _queueFlow.value = mutable
        _uiState.update { it.copy(queueSize = mutable.size) }
        if (_uiState.value.engineType == PlayerEngineType.EXOPLAYER) {
            exoPlayer?.addMediaItem(insertIdx, item.toMediaItem())
        }
    }

    fun addToQueue(items: List<PlaybackQueueItem>) {
        if (items.isEmpty()) return
        if (queue.isEmpty()) {
            loadQueue(items, 0)
            return
        }
        val mutable = queue.toMutableList()
        mutable.addAll(items)
        queue = mutable
        _queueFlow.value = mutable
        _uiState.update { it.copy(queueSize = mutable.size) }
        if (_uiState.value.engineType == PlayerEngineType.EXOPLAYER) {
            exoPlayer?.addMediaItems(items.map { it.toMediaItem() })
        }
    }

    fun removeFromQueue(index: Int) {
        if (index !in queue.indices || queue.size <= 1) return
        val currentIdx = _uiState.value.currentIndex
        val mutable = queue.toMutableList()
        mutable.removeAt(index)
        queue = mutable
        _queueFlow.value = mutable
        if (_uiState.value.engineType == PlayerEngineType.EXOPLAYER) {
            exoPlayer?.removeMediaItem(index)
        }
        val adjustedCurrent = when {
            index < currentIdx -> (currentIdx - 1).coerceAtLeast(0)
            index == currentIdx -> currentIdx.coerceAtMost(mutable.lastIndex)
            else -> currentIdx
        }
        _uiState.update {
            it.copy(
                currentIndex = adjustedCurrent,
                currentItem = mutable.getOrNull(adjustedCurrent),
                queueSize = mutable.size
            )
        }
        if (index == currentIdx) {
            playIndex(adjustedCurrent)
        }
    }

    fun playQueueIndex(index: Int) {
        if (index in queue.indices) {
            playIndex(index)
        }
    }

    fun retryCurrentItem() {
        val current = _uiState.value.currentItem ?: return
        val pos = getCurrentPositionMs()
        if (_uiState.value.engineType == PlayerEngineType.EXOPLAYER) {
            startExoQueue(queue, _uiState.value.currentIndex, pos, _uiState.value.speed)
        } else {
            switchToLibVlcFallback(current, pos)
        }
    }

    private fun onNewItemActivated(item: PlaybackQueueItem) {
        externalSubtitles = emptyList()
        selectedExternalSubtitleUri = null
        externalCues = emptyList()
        embeddedCueText = null
        _activeSubtitleText.value = null

        serviceScope.launch {
            appContainer.videoLibraryRepository.saveProgress(
                mediaKey = item.uri,
                title = item.title,
                positionMs = -1L,
                durationMs = item.durationMs,
                completed = false,
                incrementPlayCount = true,
                isNetworkStream = item.isNetworkStream,
                folderBucketId = item.folderBucketId,
                width = item.width,
                height = item.height
            )
            if (item.isNetworkStream) {
                appContainer.videoLibraryRepository.recordNetworkStreamPlay(item.uri, item.title)
            }

            // Auto-discover sibling subtitle files (.srt, .ass, .ssa, .vtt, .sub, .smi)
            val discovered = SubtitleParser.discoverMatchingSubtitleUris(item.path)
            if (discovered.isNotEmpty()) {
                val tracks = discovered.mapIndexed { idx, (subUri, fileName) ->
                    SubtitleTrackInfo(
                        id = "ext_$idx",
                        label = "$fileName (Auto)",
                        language = "ext",
                        isExternal = true,
                        uri = subUri,
                        isSelected = idx == 0 && subtitleDefaultEnabled
                    )
                }
                externalSubtitles = tracks
                _uiState.update { state ->
                    val embeddedOnly = state.subtitleTracks.filterNot { it.isExternal }
                    state.copy(subtitleTracks = combineSubtitleTracks(embeddedOnly))
                }
                if (subtitleDefaultEnabled) {
                    selectExternalSubtitleUri(discovered.first().first)
                }
            }
        }
    }

    private fun startExoQueue(
        items: List<PlaybackQueueItem>,
        startIndex: Int,
        startPositionMs: Long,
        speed: Float
    ) {
        libVlcPlayer?.release()
        libVlcPlayer = null

        val player = exoPlayer ?: return
        val mediaItems = items.map { it.toMediaItem() }

        _uiState.update { it.copy(engineType = PlayerEngineType.EXOPLAYER, errorMessage = null) }
        player.setMediaItems(mediaItems, startIndex, startPositionMs.coerceAtLeast(0L))
        player.playbackParameters = PlaybackParameters(speed, 1.0f)
        player.prepare()
        player.playWhenReady = true
    }

    private fun switchToLibVlcFallback(item: PlaybackQueueItem, startPositionMs: Long) {
        exoPlayer?.pause()
        exoPlayer?.clearMediaItems()

        _uiState.update {
            it.copy(
                engineType = PlayerEngineType.LIBVLC,
                isBuffering = true,
                errorMessage = null,
                playbackEnded = false
            )
        }

        val state = _uiState.value
        val vlc = libVlcPlayer ?: LibVlcFallbackPlayer(applicationContext) { playing, buffering, duration, pos, w, h, audioTracks, spuTracks, vCodec, aCodec, ended, error ->
            if (_uiState.value.engineType != PlayerEngineType.LIBVLC) return@LibVlcFallbackPlayer
            val wasPlaying = _uiState.value.isPlaying
            _uiState.update {
                it.copy(
                    isPlaying = playing,
                    isBuffering = buffering,
                    videoWidth = if (w > 0) w else it.videoWidth,
                    videoHeight = if (h > 0) h else it.videoHeight,
                    audioTracks = audioTracks,
                    subtitleTracks = combineSubtitleTracks(spuTracks),
                    activeVideoCodec = vCodec.ifBlank { it.activeVideoCodec },
                    activeAudioCodec = aCodec.ifBlank { it.activeAudioCodec },
                    playbackEnded = ended,
                    errorMessage = error
                )
            }
            if (playing && !wasPlaying) {
                startPeriodicProgressSaver()
            } else if (!playing && wasPlaying) {
                stopPeriodicProgressSaver()
                persistCurrentPosition()
            }
            if (controlsVisibleForTicker || duration > 0L) {
                _positionState.value = PlaybackPositionState(
                    positionMs = pos,
                    durationMs = duration,
                    bufferedPositionMs = pos
                )
            }
            if (ended) {
                stopPeriodicProgressSaver()
                persistCurrentPosition(completed = true)
                handleTrackEnded()
            }
        }.also { libVlcPlayer = it }

        activeSurfaceView?.let { vlc.attachSurface(it) }
        vlc.prepareAndPlay(
            uriString = item.uri,
            startPositionMs = startPositionMs,
            decoderMode = state.decoderMode,
            speed = state.speed,
            muted = state.isMuted,
            volumeBoostPercent = state.volumeBoostPercent,
            audioDelayMs = state.audioDelayMs,
            spuDelayMs = state.subtitleDelayMs
        )
    }

    fun play() {
        when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> exoPlayer?.play()
            PlayerEngineType.LIBVLC -> libVlcPlayer?.play()
        }
    }

    fun pause() {
        when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> exoPlayer?.pause()
            PlayerEngineType.LIBVLC -> libVlcPlayer?.pause()
        }
        persistCurrentPosition()
    }

    fun togglePlayPause() {
        if (_uiState.value.isPlaying) pause() else play()
    }

    fun seekTo(positionMs: Long, isScrubbing: Boolean) {
        val clamped = positionMs.coerceAtLeast(0L)
        when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> {
                exoPlayer?.let { player ->
                    player.setSeekParameters(if (isScrubbing) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
                    player.seekTo(clamped)
                }
            }
            PlayerEngineType.LIBVLC -> libVlcPlayer?.seekTo(clamped)
        }
        _positionState.update { it.copy(positionMs = clamped) }
        refreshExternalSubtitleCueNow(clamped)
        if (!isScrubbing) {
            persistCurrentPosition()
        }
    }

    fun seekBy(deltaMs: Long) {
        val current = getCurrentPositionMs()
        val dur = getDurationMs()
        val target = if (dur > 0L) (current + deltaMs).coerceIn(0L, dur) else (current + deltaMs).coerceAtLeast(0L)
        seekTo(target, isScrubbing = false)
    }

    fun stepFrameForward() {
        when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> {
                exoPlayer?.let { player ->
                    if (player.isPlaying) player.pause()
                    player.setSeekParameters(SeekParameters.EXACT)
                    val target = (player.currentPosition + 33L).coerceAtMost(player.duration.coerceAtLeast(0L))
                    player.seekTo(target)
                    _positionState.update { it.copy(positionMs = target) }
                    refreshExternalSubtitleCueNow(target)
                }
            }
            PlayerEngineType.LIBVLC -> {
                libVlcPlayer?.stepFrameForward()
                syncPositionNow()
            }
        }
    }

    fun playNext() {
        if (queue.isEmpty()) return
        val nextIndex = if (_uiState.value.shuffleEnabled && queue.size > 1) {
            (queue.indices - _uiState.value.currentIndex).random()
        } else {
            val candidate = _uiState.value.currentIndex + 1
            if (candidate < queue.size) candidate else if (_uiState.value.loopMode == LoopMode.ALL) 0 else return
        }
        playIndex(nextIndex)
    }

    fun playPrevious() {
        if (queue.isEmpty()) return
        if (getCurrentPositionMs() > 3500L) {
            seekTo(0L, isScrubbing = false)
            return
        }
        val prevIndex = if (_uiState.value.currentIndex > 0) {
            _uiState.value.currentIndex - 1
        } else if (_uiState.value.loopMode == LoopMode.ALL) {
            queue.lastIndex
        } else {
            0
        }
        playIndex(prevIndex)
    }

    private fun playIndex(index: Int) {
        persistCurrentPosition()
        val safeIdx = index.coerceIn(0, queue.lastIndex)
        val item = queue[safeIdx]
        serviceScope.launch {
            val savedPos = if (resumePlaybackEnabled) {
                appContainer.videoLibraryRepository.getSavedPosition(item.uri)
            } else {
                0L
            }
            _uiState.update {
                it.copy(
                    currentIndex = safeIdx,
                    currentItem = item,
                    abRepeatA = null,
                    abRepeatB = null,
                    playbackEnded = false
                )
            }
            onNewItemActivated(item)
            if (shouldPreferLibVlc(item.uri, item.mimeType)) {
                switchToLibVlcFallback(item, savedPos)
            } else if (_uiState.value.engineType == PlayerEngineType.EXOPLAYER) {
                val player = exoPlayer
                if (player != null && player.mediaItemCount == queue.size) {
                    player.seekTo(safeIdx, savedPos)
                    player.playWhenReady = true
                } else {
                    startExoQueue(queue, safeIdx, savedPos, _uiState.value.speed)
                }
            } else {
                startExoQueue(queue, safeIdx, savedPos, _uiState.value.speed)
            }
        }
    }

    private fun handleTrackEnded() {
        val state = _uiState.value
        when (state.loopMode) {
            LoopMode.ONE -> {
                seekTo(0L, isScrubbing = false)
                play()
            }
            LoopMode.ALL -> {
                if (state.engineType == PlayerEngineType.LIBVLC || state.shuffleEnabled) {
                    playNext()
                }
            }
            LoopMode.OFF -> {
                if (autoPlayNextEnabled && state.currentIndex < queue.lastIndex) {
                    if (state.engineType == PlayerEngineType.LIBVLC) {
                        playNext()
                    }
                }
            }
        }
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.25f, 4.0f)
        _uiState.update { it.copy(speed = clamped) }
        when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> exoPlayer?.playbackParameters = PlaybackParameters(clamped, 1.0f)
            PlayerEngineType.LIBVLC -> libVlcPlayer?.setSpeed(clamped)
        }
    }

    fun setDecoderMode(mode: DecoderMode) {
        if (_uiState.value.decoderMode == mode) return
        val currentPos = getCurrentPositionMs()
        val wasPlaying = _uiState.value.isPlaying
        _uiState.update { it.copy(decoderMode = mode) }

        if (_uiState.value.engineType == PlayerEngineType.EXOPLAYER) {
            buildOrReplaceExoPlayer(mode)
            mediaSession?.player = requireNotNull(exoPlayer)
            val idx = _uiState.value.currentIndex
            if (queue.isNotEmpty()) {
                startExoQueue(queue, idx, currentPos, _uiState.value.speed)
                if (!wasPlaying) exoPlayer?.pause()
            }
        } else {
            val item = _uiState.value.currentItem ?: return
            switchToLibVlcFallback(item, currentPos)
            if (!wasPlaying) libVlcPlayer?.pause()
        }
    }

    fun switchEngineManually(engine: PlayerEngineType) {
        val item = _uiState.value.currentItem ?: return
        val pos = getCurrentPositionMs()
        if (engine == PlayerEngineType.LIBVLC) {
            switchToLibVlcFallback(item, pos)
        } else {
            startExoQueue(queue, _uiState.value.currentIndex, pos, _uiState.value.speed)
        }
    }

    fun setAspectRatioMode(mode: AspectRatioMode) {
        _uiState.update { it.copy(aspectRatioMode = mode) }
        if (_uiState.value.engineType == PlayerEngineType.LIBVLC) {
            libVlcPlayer?.setAspectRatio(mode)
        }
    }

    fun cycleAspectRatioMode(): AspectRatioMode {
        val values = AspectRatioMode.entries
        val next = values[(_uiState.value.aspectRatioMode.ordinal + 1) % values.size]
        setAspectRatioMode(next)
        return next
    }

    fun toggleMute() {
        val nextMuted = !_uiState.value.isMuted
        _uiState.update { it.copy(isMuted = nextMuted) }
        applyAudioGain(nextMuted, _uiState.value.volumeBoostPercent)
    }

    fun setVolumeBoostPercent(percent: Int) {
        val clamped = percent.coerceIn(0, 200)
        val muted = clamped == 0
        _uiState.update { it.copy(volumeBoostPercent = clamped, isMuted = muted) }
        applyAudioGain(muted, clamped)
    }

    fun setAudioDelayMs(delayMs: Long) {
        val clamped = delayMs.coerceIn(-5000L, 5000L)
        _uiState.update { it.copy(audioDelayMs = clamped) }
        if (_uiState.value.engineType == PlayerEngineType.LIBVLC) {
            libVlcPlayer?.setAudioDelayMs(clamped)
        } else if (clamped != 0L) {
            // Seamlessly switch to LibVLC which supports exact microsecond audio synchronization
            val item = _uiState.value.currentItem ?: return
            val pos = getCurrentPositionMs()
            switchToLibVlcFallback(item, pos)
        }
    }

    private fun applyAudioGain(muted: Boolean, boostPercent: Int) {
        when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> {
                val player = exoPlayer
                if (player != null) {
                    player.volume = if (muted) 0f else (boostPercent.coerceAtMost(100) / 100f)
                }
                audioEffects.updateVolumeBoost(boostPercent, muted)
            }
            PlayerEngineType.LIBVLC -> libVlcPlayer?.setVolumeBoost(muted, boostPercent)
        }
    }

    fun selectAudioTrack(track: AudioTrackInfo) {
        when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> {
                val player = exoPlayer ?: return
                val audioGroups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                val targetGroup = audioGroups.getOrNull(track.groupIndex) ?: return
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setOverrideForType(
                        TrackSelectionOverride(targetGroup.mediaTrackGroup, track.trackIndex)
                    )
                    .build()
            }
            PlayerEngineType.LIBVLC -> {
                if (track.vlcTrackId >= 0) {
                    libVlcPlayer?.selectAudioTrack(track.vlcTrackId)
                }
            }
        }
    }

    // Subtitle control
    fun setSubtitlesEnabled(enabled: Boolean) {
        _uiState.update { it.copy(subtitlesEnabled = enabled) }
        if (!enabled) {
            _activeSubtitleText.value = null
            if (_uiState.value.engineType == PlayerEngineType.LIBVLC) {
                libVlcPlayer?.selectSubtitleTrack(-1)
            } else {
                exoPlayer?.let { p ->
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                }
            }
        } else {
            val activeExt = selectedExternalSubtitleUri
            if (activeExt != null) {
                refreshExternalSubtitleCueNow()
            } else {
                exoPlayer?.let { p ->
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .build()
                }
                _uiState.value.subtitleTracks.firstOrNull { !it.isExternal }?.let { first ->
                    if (first.vlcTrackId >= 0) libVlcPlayer?.selectSubtitleTrack(first.vlcTrackId)
                }
            }
        }
    }

    fun selectSubtitleTrack(track: SubtitleTrackInfo?) {
        if (track == null) {
            selectedExternalSubtitleUri = null
            externalCues = emptyList()
            _activeSubtitleText.value = null
            setSubtitlesEnabled(false)
            return
        }

        _uiState.update { it.copy(subtitlesEnabled = true) }
        if (track.isExternal && track.uri != null) {
            // Turn off embedded text rendering while external parsed track is active
            if (_uiState.value.engineType == PlayerEngineType.LIBVLC) {
                libVlcPlayer?.selectSubtitleTrack(-1)
            } else {
                exoPlayer?.let { p ->
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                }
            }
            selectExternalSubtitleUri(track.uri)
        } else {
            selectedExternalSubtitleUri = null
            externalCues = emptyList()
            subtitleTickerJob?.cancel()
            externalSubtitles = externalSubtitles.map { it.copy(isSelected = false) }
            when (_uiState.value.engineType) {
                PlayerEngineType.EXOPLAYER -> {
                    val player = exoPlayer ?: return
                    val textGroups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
                    val targetGroup = textGroups.getOrNull(track.groupIndex) ?: return
                    player.trackSelectionParameters = player.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setOverrideForType(
                            TrackSelectionOverride(targetGroup.mediaTrackGroup, track.trackIndex)
                        )
                        .build()
                }
                PlayerEngineType.LIBVLC -> {
                    if (track.vlcTrackId >= 0) {
                        _activeSubtitleText.value = null
                        libVlcPlayer?.selectSubtitleTrack(track.vlcTrackId)
                    }
                }
            }
        }
    }

    fun addExternalSubtitle(uri: Uri, displayName: String) {
        val uriString = uri.toString()
        val label = displayName.ifBlank { uri.lastPathSegment?.substringAfterLast('/') ?: "External subtitle" }
        val existingIdx = externalSubtitles.indexOfFirst { it.uri == uriString }
        val updatedList = if (existingIdx >= 0) {
            externalSubtitles.mapIndexed { i, t -> t.copy(isSelected = i == existingIdx) }
        } else {
            externalSubtitles.map { it.copy(isSelected = false) } + SubtitleTrackInfo(
                id = "ext_user_${externalSubtitles.size}",
                label = label,
                language = "ext",
                isExternal = true,
                uri = uriString,
                isSelected = true
            )
        }
        externalSubtitles = updatedList
        _uiState.update { state ->
            val embedded = state.subtitleTracks.filterNot { it.isExternal }.map { it.copy(isSelected = false) }
            state.copy(
                subtitlesEnabled = true,
                subtitleTracks = embedded + updatedList
            )
        }
        selectSubtitleTrack(updatedList.first { it.uri == uriString })
    }

    fun setSubtitleDelayMs(delayMs: Long) {
        val clamped = delayMs.coerceIn(-10_000L, 10_000L)
        _uiState.update { it.copy(subtitleDelayMs = clamped) }
        if (selectedExternalSubtitleUri != null) {
            refreshExternalSubtitleCueNow()
        } else if (_uiState.value.engineType == PlayerEngineType.LIBVLC) {
            libVlcPlayer?.setSpuDelayMs(clamped)
        }
    }

    private fun selectExternalSubtitleUri(uriString: String) {
        selectedExternalSubtitleUri = uriString
        externalSubtitles = externalSubtitles.map { it.copy(isSelected = it.uri == uriString) }
        _uiState.update { state ->
            val embedded = state.subtitleTracks.filterNot { it.isExternal }.map { it.copy(isSelected = false) }
            state.copy(subtitleTracks = embedded + externalSubtitles)
        }
        reloadExternalSubtitle(uriString)
    }

    private fun reloadExternalSubtitle(uriString: String) {
        serviceScope.launch {
            val cues = SubtitleParser.loadExternalSubtitles(
                context = applicationContext,
                uri = Uri.parse(uriString),
                encodingName = subtitleEncoding
            )
            externalCues = cues
            startExternalSubtitleTicker()
            refreshExternalSubtitleCueNow()
        }
    }

    private fun startExternalSubtitleTicker() {
        subtitleTickerJob?.cancel()
        subtitleTickerJob = serviceScope.launch {
            while (isActive && selectedExternalSubtitleUri != null) {
                refreshExternalSubtitleCueNow()
                delay(120L)
            }
        }
    }

    private fun refreshExternalSubtitleCueNow(overridePosMs: Long? = null) {
        if (!_uiState.value.subtitlesEnabled || selectedExternalSubtitleUri == null) {
            if (selectedExternalSubtitleUri != null) _activeSubtitleText.value = null
            return
        }
        val pos = overridePosMs ?: getCurrentPositionMs()
        _activeSubtitleText.value = SubtitleParser.findActiveCueText(
            cues = externalCues,
            playbackPositionMs = pos,
            offsetMs = _uiState.value.subtitleDelayMs
        )
    }

    private fun combineSubtitleTracks(embedded: List<SubtitleTrackInfo>): List<SubtitleTrackInfo> {
        val extActive = selectedExternalSubtitleUri != null
        val adjustedEmbedded = if (extActive) embedded.map { it.copy(isSelected = false) } else embedded
        val adjustedExt = externalSubtitles.map { it.copy(isSelected = extActive && it.uri == selectedExternalSubtitleUri) }
        return adjustedEmbedded + adjustedExt
    }

    fun cycleLoopMode(): LoopMode {
        val next = when (_uiState.value.loopMode) {
            LoopMode.OFF -> LoopMode.ONE
            LoopMode.ONE -> LoopMode.ALL
            LoopMode.ALL -> LoopMode.OFF
        }
        _uiState.update { it.copy(loopMode = next) }
        exoPlayer?.repeatMode = when (next) {
            LoopMode.OFF -> Player.REPEAT_MODE_OFF
            LoopMode.ONE -> Player.REPEAT_MODE_ONE
            LoopMode.ALL -> Player.REPEAT_MODE_ALL
        }
        return next
    }

    fun toggleShuffle(): Boolean {
        val next = !_uiState.value.shuffleEnabled
        _uiState.update { it.copy(shuffleEnabled = next) }
        exoPlayer?.shuffleModeEnabled = next
        return next
    }

    fun setAbRepeatPoint() {
        val current = getCurrentPositionMs()
        val state = _uiState.value
        when {
            state.abRepeatA == null -> {
                _uiState.update { it.copy(abRepeatA = current, abRepeatB = null) }
            }
            state.abRepeatB == null -> {
                val a = state.abRepeatA
                val b = if (current > a + 300L) current else a + 1000L
                _uiState.update { it.copy(abRepeatB = b) }
                startAbMonitor(a, b)
            }
            else -> {
                abMonitorJob?.cancel()
                _uiState.update { it.copy(abRepeatA = null, abRepeatB = null) }
            }
        }
    }

    fun clearAbRepeat() {
        abMonitorJob?.cancel()
        _uiState.update { it.copy(abRepeatA = null, abRepeatB = null) }
    }

    private fun startAbMonitor(aMs: Long, bMs: Long) {
        abMonitorJob?.cancel()
        abMonitorJob = serviceScope.launch {
            while (isActive) {
                val pos = getCurrentPositionMs()
                if (pos >= bMs) {
                    seekTo(aMs, isScrubbing = false)
                }
                delay(150L)
            }
        }
    }

    fun setSleepTimerMinutes(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _uiState.update { it.copy(sleepTimerRemainingMs = 0L) }
            return
        }
        var remainingMs = minutes * 60_000L
        _uiState.update { it.copy(sleepTimerRemainingMs = remainingMs) }
        sleepTimerJob = serviceScope.launch {
            while (isActive && remainingMs > 0L) {
                delay(1000L)
                remainingMs = (remainingMs - 1000L).coerceAtLeast(0L)
                _uiState.update { it.copy(sleepTimerRemainingMs = remainingMs) }
            }
            if (isActive) {
                pause()
                _uiState.update { it.copy(sleepTimerRemainingMs = 0L) }
            }
        }
    }

    fun getCurrentPositionMs(): Long {
        return when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> exoPlayer?.currentPosition?.coerceAtLeast(0L) ?: 0L
            PlayerEngineType.LIBVLC -> libVlcPlayer?.getCurrentPositionMs() ?: 0L
        }
    }

    fun getDurationMs(): Long {
        return when (_uiState.value.engineType) {
            PlayerEngineType.EXOPLAYER -> exoPlayer?.duration?.coerceAtLeast(0L) ?: 0L
            PlayerEngineType.LIBVLC -> libVlcPlayer?.getDurationMs() ?: 0L
        }
    }

    private fun buildOrReplaceExoPlayer(decoderMode: DecoderMode) {
        val oldPlayer = exoPlayer
        oldPlayer?.removeListener(exoListener)

        val renderersFactory = DefaultRenderersFactory(applicationContext).apply {
            setEnableDecoderFallback(decoderMode != DecoderMode.HW)
            if (decoderMode == DecoderMode.SW) {
                setMediaCodecSelector(SoftwarePreferredMediaCodecSelector)
            } else {
                setMediaCodecSelector(MediaCodecSelector.DEFAULT)
            }
        }

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(1500, 15000, 250, 500)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val newPlayer = ExoPlayer.Builder(applicationContext, renderersFactory)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .apply {
                addListener(exoListener)
            }

        exoPlayer = newPlayer
        oldPlayer?.release()
    }

    private fun extractExoAudioTracks(tracks: Tracks): List<AudioTrackInfo> {
        val result = mutableListOf<AudioTrackInfo>()
        val audioGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
        audioGroups.forEachIndexed { groupIdx, group ->
            for (trackIdx in 0 until group.length) {
                val format = group.getTrackFormat(trackIdx)
                val lang = format.language?.takeIf { it.isNotBlank() && it != "und" } ?: "Audio"
                val label = format.label?.takeIf { it.isNotBlank() }
                    ?: "$lang • ${format.channelCount.coerceAtLeast(1)}ch"
                result.add(
                    AudioTrackInfo(
                        id = "${groupIdx}_$trackIdx",
                        label = label,
                        language = lang,
                        channelCount = format.channelCount.coerceAtLeast(1),
                        groupIndex = groupIdx,
                        trackIndex = trackIdx,
                        isSelected = group.isTrackSelected(trackIdx)
                    )
                )
            }
        }
        return result
    }

    private fun extractExoSubtitleTracks(tracks: Tracks): List<SubtitleTrackInfo> {
        val result = mutableListOf<SubtitleTrackInfo>()
        val textGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
        textGroups.forEachIndexed { groupIdx, group ->
            for (trackIdx in 0 until group.length) {
                val format = group.getTrackFormat(trackIdx)
                val lang = format.language?.takeIf { it.isNotBlank() && it != "und" } ?: "Subtitle"
                val label = format.label?.takeIf { it.isNotBlank() }
                    ?: "$lang (Track ${result.size + 1})"
                result.add(
                    SubtitleTrackInfo(
                        id = "exo_sub_${groupIdx}_$trackIdx",
                        label = label,
                        language = lang,
                        isSelected = group.isTrackSelected(trackIdx),
                        isExternal = false,
                        groupIndex = groupIdx,
                        trackIndex = trackIdx
                    )
                )
            }
        }
        return result
    }

    private fun startPeriodicProgressSaver() {
        if (progressSaverJob?.isActive == true) return
        progressSaverJob = serviceScope.launch {
            while (isActive) {
                delay(5000L)
                persistCurrentPosition()
            }
        }
    }

    private fun stopPeriodicProgressSaver() {
        progressSaverJob?.cancel()
        progressSaverJob = null
    }

    private fun persistCurrentPosition(completed: Boolean = false) {
        val item = _uiState.value.currentItem ?: return
        val pos = if (completed) 0L else getCurrentPositionMs()
        val dur = getDurationMs().takeIf { it > 0L } ?: item.durationMs
        serviceScope.launch(Dispatchers.IO) {
            appContainer.videoLibraryRepository.saveProgress(
                mediaKey = item.uri,
                title = item.title,
                positionMs = pos,
                durationMs = dur,
                completed = completed,
                incrementPlayCount = false,
                isNetworkStream = item.isNetworkStream,
                folderBucketId = item.folderBucketId,
                width = item.width.takeIf { it > 0 } ?: _uiState.value.videoWidth,
                height = item.height.takeIf { it > 0 } ?: _uiState.value.videoHeight
            )
        }
    }

    private fun PlaybackQueueItem.toMediaItem(): MediaItem {
        return MediaItem.Builder()
            .setMediaId(uri)
            .setUri(Uri.parse(uri))
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .build()
            )
            .build()
    }

    private fun shouldPreferLibVlc(uri: String, mimeType: String): Boolean {
        val lower = uri.lowercase()
        val lowerMime = mimeType.lowercase()
        return lower.endsWith(".avi") ||
            lower.endsWith(".flv") ||
            lower.endsWith(".wmv") ||
            lower.endsWith(".asf") ||
            lower.endsWith(".vob") ||
            lower.endsWith(".mpg") ||
            lower.endsWith(".mpeg") ||
            lower.endsWith(".rmvb") ||
            lower.endsWith(".divx") ||
            lowerMime.contains("avi") ||
            lowerMime.contains("flv") ||
            lowerMime.contains("x-ms-wmv")
    }

    private object SoftwarePreferredMediaCodecSelector : MediaCodecSelector {
        override fun getDecoderInfos(
            mimeType: String,
            requiresSecureDecoder: Boolean,
            requiresTunnelingDecoder: Boolean
        ): List<MediaCodecInfo> {
            val all = MediaCodecSelector.DEFAULT.getDecoderInfos(
                mimeType,
                requiresSecureDecoder,
                requiresTunnelingDecoder
            )
            val sw = ArrayList<MediaCodecInfo>()
            val hw = ArrayList<MediaCodecInfo>()
            for (info in all) {
                if (isSoftwareCodec(info.name)) sw.add(info) else hw.add(info)
            }
            return sw + hw
        }

        private fun isSoftwareCodec(name: String): Boolean {
            val lower = name.lowercase()
            return lower.startsWith("omx.google.") ||
                lower.startsWith("c2.android.") ||
                lower.startsWith("omx.ffmpeg.") ||
                (lower.startsWith("omx.sec.") && lower.contains(".sw."))
        }
    }

    companion object {
        const val EXTRA_OPEN_PLAYER = "extra_open_player"
    }
}
