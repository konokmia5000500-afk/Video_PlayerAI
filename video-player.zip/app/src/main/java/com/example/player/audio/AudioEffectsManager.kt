package com.example.player.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import kotlin.math.roundToInt

data class EqualizerPreset(
    val name: String,
    /** Normalized offsets in [-1000..1000] across 5 bands */
    val bandNormalized: List<Int>,
    val bassBoost: Int = 0,
    val virtualizer: Int = 0
)

class AudioEffectsManager {

    private var currentSessionId: Int = 0
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null

    private var eqEnabled: Boolean = false
    private var bandLevelsNormalized: List<Int> = listOf(0, 0, 0, 0, 0)
    private var bassBoostStrength: Int = 0
    private var virtualizerStrength: Int = 0
    private var volumeBoostPercent: Int = 100
    private var isMuted: Boolean = false

    val presets: List<EqualizerPreset> = listOf(
        EqualizerPreset("Flat", listOf(0, 0, 0, 0, 0), 0, 0),
        EqualizerPreset("Bass Boost", listOf(750, 500, 100, 0, 0), 650, 200),
        EqualizerPreset("Treble", listOf(0, 0, 200, 550, 800), 0, 150),
        EqualizerPreset("Vocal", listOf(-200, 150, 550, 500, 150), 0, 100),
        EqualizerPreset("Rock", listOf(550, 250, -150, 350, 600), 400, 250),
        EqualizerPreset("Pop", listOf(-150, 350, 500, 300, -150), 250, 200),
        EqualizerPreset("Dance", listOf(650, 450, 150, 350, 550), 600, 350),
        EqualizerPreset("Classical", listOf(400, 200, -100, 250, 450), 150, 300)
    )

    fun attachToAudioSession(audioSessionId: Int) {
        if (audioSessionId <= 0) return
        if (audioSessionId == currentSessionId && equalizer != null) {
            applyAll()
            return
        }
        release()
        currentSessionId = audioSessionId

        runCatching {
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                enabled = false
            }
        }
        runCatching {
            equalizer = Equalizer(0, audioSessionId).apply {
                enabled = eqEnabled
            }
        }
        runCatching {
            bassBoost = BassBoost(0, audioSessionId).apply {
                enabled = eqEnabled && bassBoostStrength > 0
            }
        }
        runCatching {
            virtualizer = Virtualizer(0, audioSessionId).apply {
                enabled = eqEnabled && virtualizerStrength > 0
            }
        }
        applyAll()
    }

    fun getBandCenterFreqHz(): List<Int> {
        val eq = equalizer ?: return listOf(60, 230, 910, 3600, 14000)
        val count = eq.numberOfBands.toInt().coerceAtLeast(1)
        return (0 until minOf(5, count)).map { band ->
            runCatching { eq.getCenterFreq(band.toShort()) / 1000 }.getOrDefault(1000)
        }.let { list ->
            if (list.size == 5) list else listOf(60, 230, 910, 3600, 14000)
        }
    }

    fun updateVolumeBoost(percent: Int, muted: Boolean) {
        volumeBoostPercent = percent.coerceIn(0, 200)
        isMuted = muted
        applyLoudness()
    }

    fun updateEqualizer(
        enabled: Boolean,
        bandNormalized: List<Int>,
        bassBoostLevel: Int,
        virtualizerLevel: Int
    ) {
        eqEnabled = enabled
        bandLevelsNormalized = bandNormalized.take(5).let {
            if (it.size == 5) it else listOf(0, 0, 0, 0, 0)
        }
        bassBoostStrength = bassBoostLevel.coerceIn(0, 1000)
        virtualizerStrength = virtualizerLevel.coerceIn(0, 1000)
        applyAll()
    }

    private fun applyAll() {
        applyLoudness()
        applyEqualizer()
        applyBassBoost()
        applyVirtualizer()
    }

    private fun applyLoudness() {
        val enhancer = loudnessEnhancer ?: return
        runCatching {
            if (isMuted || volumeBoostPercent <= 100) {
                enhancer.setTargetGain(0)
                enhancer.enabled = false
            } else {
                // Linearly map 101..200% to 18..1800 millibels (+18 dB max boost)
                val boostFraction = (volumeBoostPercent - 100) / 100f
                val targetGainMb = (boostFraction * 1800f).roundToInt()
                enhancer.setTargetGain(targetGainMb)
                enhancer.enabled = true
            }
        }
    }

    private fun applyEqualizer() {
        val eq = equalizer ?: return
        runCatching {
            eq.enabled = eqEnabled
            val range = eq.bandLevelRange
            val minMb = range[0].toInt()
            val maxMb = range[1].toInt()
            val bandCount = minOf(5, eq.numberOfBands.toInt())
            for (i in 0 until bandCount) {
                val norm = bandLevelsNormalized.getOrElse(i) { 0 }.coerceIn(-1000, 1000)
                val mb = if (norm >= 0) {
                    (norm / 1000f * maxMb).roundToInt()
                } else {
                    (-norm / 1000f * minMb).roundToInt()
                }.coerceIn(minMb, maxMb)
                eq.setBandLevel(i.toShort(), mb.toShort())
            }
        }
    }

    private fun applyBassBoost() {
        val bb = bassBoost ?: return
        runCatching {
            bb.enabled = eqEnabled && bassBoostStrength > 0
            if (bb.strengthSupported) {
                bb.setStrength(bassBoostStrength.toShort())
            }
        }
    }

    private fun applyVirtualizer() {
        val virt = virtualizer ?: return
        runCatching {
            virt.enabled = eqEnabled && virtualizerStrength > 0
            if (virt.strengthSupported) {
                virt.setStrength(virtualizerStrength.toShort())
            }
        }
    }

    fun release() {
        runCatching { loudnessEnhancer?.release() }
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        loudnessEnhancer = null
        equalizer = null
        bassBoost = null
        virtualizer = null
        currentSessionId = 0
    }
}
