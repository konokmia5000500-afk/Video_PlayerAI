package com.example.player.service

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages binding to [PlaybackService] cleanly without leaking Contexts.
 */
class PlaybackServiceConnection(context: Context) {
    private val appContext = context.applicationContext

    private val _service = MutableStateFlow<PlaybackService?>(null)
    val service: StateFlow<PlaybackService?> = _service.asStateFlow()

    private var bound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as? PlaybackService.LocalBinder
            _service.value = localBinder?.service
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            _service.value = null
        }
    }

    fun bind() {
        if (bound) return
        val intent = Intent(appContext, PlaybackService::class.java)
        appContext.startService(intent)
        bound = appContext.bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    fun unbind() {
        if (!bound) return
        runCatching { appContext.unbindService(connection) }
        bound = false
        _service.value = null
    }
}
