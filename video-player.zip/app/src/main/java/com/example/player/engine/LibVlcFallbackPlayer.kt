package com.example.player.engine

import android.content.Context
import android.net.Uri
import android.view.SurfaceView
import com.example.data.preferences.DecoderMode
import com.example.player.subtitle.SubtitleTrackInfo
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IVLCVout

/**
 * Automatic fallback playback engine powered by LibVLC for containers/codecs that MediaCodec
 * / ExoPlayer cannot decode (AVI, FLV, WMV, MPEG-PS, AC3/DTS/EAC3, etc.).
 */
class LibVlcFallbackPlayer(
    private val context: Context,
    private val onStateChanged: (
        isPlaying: Boolean,
        isBuffering: Boolean,
        durationMs: Long,
        positionMs: Long,
        videoWidth: Int,
        videoHeight: Int,
        audioTracks: List<AudioTrackInfo>,
        subtitleTracks: List<SubtitleTrackInfo>,
        videoCodec: String,
        audioCodec: String,
        ended: Boolean,
        error: String?
    ) -> Unit
) : IVLCVout.Callback {

    private var libVLC: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private var attachedSurfaceView: SurfaceView? = null
    private var currentSpeed: Float = 1.0f
    private var currentVolumePercent: Int = 100
    private var currentMuted: Boolean = false
    private var currentAudioDelayMs: Long = 0L
    private var currentSpuDelayMs: Long = 0L
    private var lastWidth: Int = 0
    private var lastHeight: Int = 0
    private var pendingSeekMs: Long = 0L

    fun prepareAndPlay(
        uriString: String,
        startPositionMs: Long,
        decoderMode: DecoderMode,
        speed: Float,
        muted: Boolean,
        volumeBoostPercent: Int,
        audioDelayMs: Long = 0L,
        spuDelayMs: Long = 0L
    ) {
        release()
        currentSpeed = speed
        currentMuted = muted
        currentVolumePercent = volumeBoostPercent
        currentAudioDelayMs = audioDelayMs
        currentSpuDelayMs = spuDelayMs
        pendingSeekMs = startPositionMs

        val options = ArrayList<String>().apply {
            add("--no-sub-autodetect-file")
            add("--file-caching=350")
            add("--network-caching=1200")
            add("--audio-time-stretch")
            if (decoderMode == DecoderMode.SW) {
                add("--avcodec-hw=none")
            }
        }

        val vlc = LibVLC(context.applicationContext, options)
        val player = MediaPlayer(vlc)
        libVLC = vlc
        mediaPlayer = player

        player.setEventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Opening,
                MediaPlayer.Event.Buffering -> {
                    val buffering = event.buffering < 100f && event.type == MediaPlayer.Event.Buffering
                    emitSnapshot(isPlaying = player.isPlaying, isBuffering = buffering, ended = false)
                }

                MediaPlayer.Event.Playing -> {
                    if (pendingSeekMs > 0L) {
                        val seekTarget = pendingSeekMs
                        pendingSeekMs = 0L
                        player.time = seekTarget
                    }
                    player.rate = currentSpeed
                    if (currentAudioDelayMs != 0L) {
                        player.setAudioDelay(currentAudioDelayMs * 1000L)
                    }
                    if (currentSpuDelayMs != 0L) {
                        player.setSpuDelay(currentSpuDelayMs * 1000L)
                    }
                    applyVolume()
                    emitSnapshot(isPlaying = true, isBuffering = false, ended = false)
                }

                MediaPlayer.Event.Paused -> {
                    emitSnapshot(isPlaying = false, isBuffering = false, ended = false)
                }

                MediaPlayer.Event.TimeChanged -> {
                    emitSnapshot(isPlaying = player.isPlaying, isBuffering = false, ended = false)
                }

                MediaPlayer.Event.EndReached -> {
                    emitSnapshot(isPlaying = false, isBuffering = false, ended = true)
                }

                MediaPlayer.Event.EncounteredError -> {
                    emitSnapshot(
                        isPlaying = false,
                        isBuffering = false,
                        ended = false,
                        error = "LibVLC could not decode this video"
                    )
                }
            }
        }

        val uri = Uri.parse(uriString)
        val media = Media(vlc, uri).apply {
            when (decoderMode) {
                DecoderMode.HW -> setHWDecoderEnabled(true, true)
                DecoderMode.HW_PLUS -> setHWDecoderEnabled(true, false)
                DecoderMode.SW -> setHWDecoderEnabled(false, false)
            }
        }
        player.media = media
        media.release()

        attachedSurfaceView?.let { attachSurface(it) }
        player.play()
    }

    fun attachSurface(surfaceView: SurfaceView) {
        attachedSurfaceView = surfaceView
        val player = mediaPlayer ?: return
        val vout = player.vlcVout
        vout.removeCallback(this)
        if (vout.areViewsAttached()) {
            vout.detachViews()
        }
        vout.setVideoView(surfaceView)
        vout.addCallback(this)
        vout.attachViews { _, width, height, _, _, _, _ ->
            if (width > 0 && height > 0) {
                lastWidth = width
                lastHeight = height
                emitSnapshot(isPlaying = player.isPlaying, isBuffering = false, ended = false)
            }
        }
    }

    fun detachSurface() {
        attachedSurfaceView = null
        val player = mediaPlayer ?: return
        runCatching {
            val vout = player.vlcVout
            vout.removeCallback(this)
            if (vout.areViewsAttached()) {
                vout.detachViews()
            }
        }
    }

    fun play() {
        mediaPlayer?.play()
    }

    fun pause() {
        mediaPlayer?.pause()
    }

    fun seekTo(positionMs: Long) {
        mediaPlayer?.let { player ->
            player.time = positionMs.coerceAtLeast(0L)
            emitSnapshot(isPlaying = player.isPlaying, isBuffering = false, ended = false)
        }
    }

    fun stepFrameForward() {
        mediaPlayer?.let { player ->
            if (player.isPlaying) {
                player.pause()
            }
            val current = player.time.coerceAtLeast(0L)
            player.time = current + 33L
        }
    }

    fun setSpeed(speed: Float) {
        currentSpeed = speed
        mediaPlayer?.rate = speed
    }

    fun setVolumeBoost(muted: Boolean, volumeBoostPercent: Int) {
        currentMuted = muted
        currentVolumePercent = volumeBoostPercent
        applyVolume()
    }

    fun setAudioDelayMs(delayMs: Long) {
        currentAudioDelayMs = delayMs
        mediaPlayer?.setAudioDelay(delayMs * 1000L)
    }

    fun setSpuDelayMs(delayMs: Long) {
        currentSpuDelayMs = delayMs
        mediaPlayer?.setSpuDelay(delayMs * 1000L)
    }

    fun selectAudioTrack(vlcTrackId: Int) {
        mediaPlayer?.let { player ->
            player.setAudioTrack(vlcTrackId)
            emitSnapshot(isPlaying = player.isPlaying, isBuffering = false, ended = false)
        }
    }

    fun selectSubtitleTrack(vlcTrackId: Int) {
        mediaPlayer?.let { player ->
            player.setSpuTrack(vlcTrackId)
            emitSnapshot(isPlaying = player.isPlaying, isBuffering = false, ended = false)
        }
    }

    fun setAspectRatio(mode: AspectRatioMode) {
        val player = mediaPlayer ?: return
        when (mode) {
            AspectRatioMode.FIT -> {
                player.aspectRatio = null
                player.scale = 0f
            }
            AspectRatioMode.FILL, AspectRatioMode.STRETCH -> {
                val surface = attachedSurfaceView
                if (surface != null && surface.width > 0 && surface.height > 0) {
                    player.aspectRatio = "${surface.width}:${surface.height}"
                }
                player.scale = 0f
            }
            AspectRatioMode.CROP -> {
                player.aspectRatio = null
                player.scale = 0f
            }
            AspectRatioMode.ACTUAL_100 -> {
                player.aspectRatio = null
                player.scale = 1f
            }
            AspectRatioMode.RATIO_16_9 -> {
                player.aspectRatio = "16:9"
                player.scale = 0f
            }
            AspectRatioMode.RATIO_4_3 -> {
                player.aspectRatio = "4:3"
                player.scale = 0f
            }
        }
    }

    fun getCurrentPositionMs(): Long = mediaPlayer?.time?.coerceAtLeast(0L) ?: 0L

    fun getDurationMs(): Long = mediaPlayer?.length?.coerceAtLeast(0L) ?: 0L

    override fun onSurfacesCreated(vlcVout: IVLCVout) {
        val surface = attachedSurfaceView ?: return
        if (surface.width > 0 && surface.height > 0) {
            vlcVout.setWindowSize(surface.width, surface.height)
        }
    }

    override fun onSurfacesDestroyed(vlcVout: IVLCVout) = Unit

    fun release() {
        runCatching {
            mediaPlayer?.let { player ->
                player.setEventListener(null)
                player.stop()
                val vout = player.vlcVout
                vout.removeCallback(this)
                if (vout.areViewsAttached()) {
                    vout.detachViews()
                }
                player.release()
            }
        }
        runCatching { libVLC?.release() }
        mediaPlayer = null
        libVLC = null
        lastWidth = 0
        lastHeight = 0
    }

    private fun applyVolume() {
        val player = mediaPlayer ?: return
        player.volume = if (currentMuted) 0 else currentVolumePercent.coerceIn(0, 200)
    }

    private fun emitSnapshot(
        isPlaying: Boolean,
        isBuffering: Boolean,
        ended: Boolean,
        error: String? = null
    ) {
        val player = mediaPlayer ?: return
        val selectedAudio = player.audioTrack
        val audioTracks = player.audioTracks?.mapIndexedNotNull { idx, desc ->
            if (desc.id < 0) return@mapIndexedNotNull null
            AudioTrackInfo(
                id = desc.id.toString(),
                label = desc.name ?: "Track ${idx + 1}",
                language = desc.name ?: "Audio ${idx + 1}",
                channelCount = 2,
                groupIndex = 0,
                trackIndex = idx,
                vlcTrackId = desc.id,
                isSelected = desc.id == selectedAudio
            )
        } ?: emptyList()

        val selectedSpu = player.spuTrack
        val spuTracks = player.spuTracks?.mapIndexedNotNull { idx, desc ->
            if (desc.id < 0) return@mapIndexedNotNull null
            SubtitleTrackInfo(
                id = "vlc_spu_${desc.id}",
                label = desc.name ?: "Subtitle ${idx + 1}",
                language = desc.name ?: "und",
                vlcTrackId = desc.id,
                isExternal = false,
                isSelected = desc.id == selectedSpu
            )
        } ?: emptyList()

        val videoTrack = runCatching { player.currentVideoTrack }.getOrNull()
        val width = videoTrack?.width ?: lastWidth
        val height = videoTrack?.height ?: lastHeight
        val videoCodec = videoTrack?.codec.orEmpty()
        val selectedAudioLabel = audioTracks.firstOrNull { it.isSelected }?.label.orEmpty()

        onStateChanged(
            isPlaying,
            isBuffering,
            player.length.coerceAtLeast(0L),
            player.time.coerceAtLeast(0L),
            width,
            height,
            audioTracks,
            spuTracks,
            videoCodec,
            selectedAudioLabel,
            ended,
            error
        )
    }
}
