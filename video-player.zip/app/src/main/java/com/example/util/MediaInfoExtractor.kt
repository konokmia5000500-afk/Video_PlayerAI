package com.example.util

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.data.model.VideoProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MediaInfoExtractor {

    suspend fun extractProperties(
        context: Context,
        uri: Uri,
        displayName: String,
        path: String,
        sizeBytes: Long,
        durationMs: Long,
        width: Int,
        height: Int
    ): VideoProperties = withContext(Dispatchers.IO) {
        var videoCodec = "Unknown"
        var audioCodec = "None"
        var bitrateBps = 0L
        var fps = 0f
        var resolvedWidth = width
        var resolvedHeight = height
        var resolvedDuration = durationMs

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && videoCodec == "Unknown") {
                    videoCodec = prettyCodecName(mime)
                    if (resolvedWidth <= 0 && format.containsKey(MediaFormat.KEY_WIDTH)) {
                        resolvedWidth = format.getInteger(MediaFormat.KEY_WIDTH)
                    }
                    if (resolvedHeight <= 0 && format.containsKey(MediaFormat.KEY_HEIGHT)) {
                        resolvedHeight = format.getInteger(MediaFormat.KEY_HEIGHT)
                    }
                    if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        fps = runCatching { format.getFloat(MediaFormat.KEY_FRAME_RATE) }
                            .getOrElse {
                                runCatching { format.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }
                                    .getOrDefault(0f)
                            }
                    }
                    if (format.containsKey(MediaFormat.KEY_BIT_RATE)) {
                        bitrateBps += format.getInteger(MediaFormat.KEY_BIT_RATE).toLong()
                    }
                } else if (mime.startsWith("audio/") && audioCodec == "None") {
                    audioCodec = prettyCodecName(mime)
                    if (format.containsKey(MediaFormat.KEY_BIT_RATE)) {
                        bitrateBps += format.getInteger(MediaFormat.KEY_BIT_RATE).toLong()
                    }
                }
            }
        } catch (_: Throwable) {
            // Fall through to MediaMetadataRetriever for containers MediaExtractor cannot parse
        } finally {
            runCatching { extractor.release() }
        }

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            if (bitrateBps <= 0L) {
                bitrateBps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                    ?.toLongOrNull() ?: 0L
            }
            if (fps <= 0f) {
                fps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
                    ?.toFloatOrNull() ?: 0f
            }
            if (resolvedDuration <= 0L) {
                resolvedDuration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
            }
            if (resolvedWidth <= 0) {
                resolvedWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    ?.toIntOrNull() ?: 0
            }
            if (resolvedHeight <= 0) {
                resolvedHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    ?.toIntOrNull() ?: 0
            }
        } catch (_: Throwable) {
            // Ignore unsupported container metadata errors
        } finally {
            runCatching { retriever.release() }
        }

        if (bitrateBps <= 0L && sizeBytes > 0L && resolvedDuration > 0L) {
            bitrateBps = (sizeBytes * 8L * 1000L) / resolvedDuration
        }

        VideoProperties(
            title = displayName,
            path = path.ifBlank { uri.toString() },
            resolution = if (resolvedWidth > 0 && resolvedHeight > 0) "${resolvedWidth}x${resolvedHeight}" else "Unknown",
            videoCodec = videoCodec,
            audioCodec = audioCodec,
            bitrateKbps = (bitrateBps / 1000L).toInt(),
            fps = fps,
            sizeBytes = sizeBytes,
            durationMs = resolvedDuration
        )
    }

    private fun prettyCodecName(mime: String): String {
        return when (mime.lowercase()) {
            "video/avc" -> "H.264 / AVC"
            "video/hevc" -> "H.265 / HEVC"
            "video/x-vnd.on2.vp9" -> "VP9"
            "video/x-vnd.on2.vp8" -> "VP8"
            "video/av01" -> "AV1"
            "video/mp4v-es" -> "MPEG-4"
            "video/3gpp" -> "H.263"
            "audio/mp4a-latm" -> "AAC"
            "audio/ac3" -> "AC3"
            "audio/eac3" -> "E-AC3"
            "audio/mpeg" -> "MP3"
            "audio/opus" -> "Opus"
            "audio/vorbis" -> "Vorbis"
            "audio/flac" -> "FLAC"
            else -> mime.substringAfter('/').uppercase()
        }
    }
}
