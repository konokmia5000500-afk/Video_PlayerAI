package com.example.util

import android.media.MediaCodecList
import android.os.Build
import androidx.compose.runtime.Immutable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Immutable
data class DeviceCodecSummary(
    val name: String,
    val mimeTypes: List<String>,
    val isHardwareAccelerated: Boolean,
    val isVideo: Boolean
)

object CodecCapabilitiesHelper {

    suspend fun listVideoAndAudioDecoders(): List<DeviceCodecSummary> = withContext(Dispatchers.Default) {
        val list = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos
        list.mapNotNull { info ->
            if (info.isEncoder) return@mapNotNull null
            val mediaTypes = info.supportedTypes.filter {
                it.startsWith("video/", ignoreCase = true) || it.startsWith("audio/", ignoreCase = true)
            }
            if (mediaTypes.isEmpty()) return@mapNotNull null
            val isHw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.isHardwareAccelerated
            } else {
                val lower = info.name.lowercase()
                !lower.startsWith("omx.google.") && !lower.startsWith("c2.android.")
            }
            DeviceCodecSummary(
                name = info.name,
                mimeTypes = mediaTypes.sorted(),
                isHardwareAccelerated = isHw,
                isVideo = mediaTypes.any { it.startsWith("video/", ignoreCase = true) }
            )
        }.sortedWith(
            compareByDescending<DeviceCodecSummary> { it.isVideo }
                .thenByDescending { it.isHardwareAccelerated }
                .thenBy { it.name }
        )
    }
}
