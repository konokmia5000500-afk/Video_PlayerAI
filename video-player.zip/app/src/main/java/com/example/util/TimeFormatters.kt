package com.example.util

import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

object TimeFormatters {

    fun formatDuration(durationMs: Long): String {
        val safeMs = durationMs.coerceAtLeast(0L)
        val totalSeconds = safeMs / 1000L
        val seconds = totalSeconds % 60L
        val minutes = (totalSeconds / 60L) % 60L
        val hours = totalSeconds / 3600L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatSignedDelta(deltaMs: Long): String {
        val sign = if (deltaMs >= 0) "+" else "-"
        return "$sign${formatDuration(abs(deltaMs))}"
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        return when {
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
            bytes >= kb -> String.format(Locale.US, "%.0f KB", bytes / kb)
            else -> "$bytes B"
        }
    }

    fun formatResolutionBadge(width: Int, height: Int): String {
        val minDim = minOf(width, height)
        val maxDim = maxOf(width, height)
        return when {
            minDim <= 0 || maxDim <= 0 -> "Video"
            maxDim >= 3840 || minDim >= 2160 -> "4K"
            maxDim >= 2560 || minDim >= 1440 -> "2K"
            minDim >= 1080 -> "1080p"
            minDim >= 720 -> "720p"
            minDim >= 480 -> "480p"
            else -> "${width}x${height}"
        }
    }

    fun formatSpeed(speed: Float): String {
        val rounded = (speed * 100f).roundToInt() / 100f
        return if (rounded % 1f == 0f) {
            "${rounded.toInt()}.0x"
        } else {
            "${rounded}x"
        }
    }
}
