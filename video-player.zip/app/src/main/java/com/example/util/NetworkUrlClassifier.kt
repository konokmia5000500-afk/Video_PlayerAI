package com.example.util

import android.net.Uri

sealed interface ClassifiedStreamUrl {
    data class PlayableStream(val normalizedUrl: String, val protocolLabel: String) : ClassifiedStreamUrl
    data class YouTubeLink(val originalUrl: String) : ClassifiedStreamUrl
    data class Invalid(val reason: String) : ClassifiedStreamUrl
}

/**
 * Classifies network URLs cleanly between direct playable streams (HTTP/HTTPS/RTSP/HLS/DASH)
 * and external platform links such as YouTube that must be opened safely in their official app/browser.
 */
object NetworkUrlClassifier {

    private val SUPPORTED_SCHEMES = setOf("http", "https", "rtsp", "rtmp", "udp", "rtp", "mms")

    fun classify(rawInput: String): ClassifiedStreamUrl {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return ClassifiedStreamUrl.Invalid("Enter a stream or video URL.")
        }

        val withScheme = if (!trimmed.contains("://")) "https://$trimmed" else trimmed
        val parsed = runCatching { Uri.parse(withScheme) }.getOrNull()
            ?: return ClassifiedStreamUrl.Invalid("Malformed URL.")

        val scheme = parsed.scheme?.lowercase().orEmpty()
        if (scheme !in SUPPORTED_SCHEMES) {
            return ClassifiedStreamUrl.Invalid("Unsupported protocol '$scheme'. Use HTTP, HTTPS, or RTSP.")
        }

        val host = parsed.host?.lowercase().orEmpty()
        if (host.isBlank()) {
            return ClassifiedStreamUrl.Invalid("URL is missing a server hostname.")
        }

        if (isYouTubeHost(host)) {
            return ClassifiedStreamUrl.YouTubeLink(withScheme)
        }

        val lower = withScheme.lowercase()
        val protocolLabel = when {
            lower.contains(".m3u8") -> "HLS Stream"
            lower.contains(".mpd") -> "DASH Stream"
            scheme == "rtsp" -> "RTSP Stream"
            scheme == "https" -> "HTTPS Direct"
            scheme == "http" -> "HTTP Direct"
            else -> "${scheme.uppercase()} Stream"
        }
        return ClassifiedStreamUrl.PlayableStream(withScheme, protocolLabel)
    }

    fun isYouTubeHost(host: String): Boolean {
        val clean = host.lowercase().removePrefix("www.").removePrefix("m.").removePrefix("music.")
        return clean == "youtube.com" ||
            clean == "youtu.be" ||
            clean == "youtube-nocookie.com" ||
            clean.endsWith(".youtube.com")
    }
}
