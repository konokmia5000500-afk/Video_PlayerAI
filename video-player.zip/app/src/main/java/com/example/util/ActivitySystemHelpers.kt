package com.example.util

import android.app.Activity
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Build
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.annotation.RequiresApi
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.R
import com.example.data.preferences.OrientationMode

object ActivitySystemHelpers {

    const val ACTION_PIP_CONTROL = "com.example.ACTION_PIP_CONTROL"
    const val EXTRA_PIP_COMMAND = "extra_pip_command"
    const val PIP_CMD_PLAY_PAUSE = 1
    const val PIP_CMD_PREV = 2
    const val PIP_CMD_NEXT = 3

    fun Context.findActivity(): ComponentActivity? {
        var ctx = this
        while (ctx is ContextWrapper) {
            if (ctx is ComponentActivity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    fun applyOrientation(
        activity: Activity,
        mode: OrientationMode,
        videoWidth: Int,
        videoHeight: Int
    ) {
        activity.requestedOrientation = when (mode) {
            OrientationMode.AUTO -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            OrientationMode.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            OrientationMode.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            OrientationMode.REVERSE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
            OrientationMode.SENSOR -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            OrientationMode.MATCH_VIDEO -> {
                if (videoWidth > 0 && videoHeight > 0) {
                    if (videoWidth >= videoHeight) {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    }
                } else {
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                }
            }
        }
    }

    fun setImmersiveMode(activity: Activity, immersive: Boolean) {
        val window = activity.window ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (immersive) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    fun setKeepScreenOn(activity: Activity, keepOn: Boolean) {
        val window = activity.window ?: return
        if (keepOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    fun setWindowBrightness(activity: Activity, brightness01: Float) {
        val window = activity.window ?: return
        window.attributes = window.attributes.apply {
            screenBrightness = if (brightness01 < 0f) {
                WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            } else {
                brightness01.coerceIn(0.01f, 1.0f)
            }
        }
    }

    fun isPipSupported(context: Context): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun buildPipParams(
        context: Context,
        videoWidth: Int,
        videoHeight: Int,
        sourceRectHint: Rect?,
        autoEnter: Boolean,
        isPlaying: Boolean
    ): PictureInPictureParams {
        val builder = PictureInPictureParams.Builder()
        val safeRatio = computeClampedAspectRatio(videoWidth, videoHeight)
        builder.setAspectRatio(safeRatio)
        if (sourceRectHint != null && !sourceRectHint.isEmpty) {
            builder.setSourceRectHint(sourceRectHint)
        }
        builder.setActions(buildPipActions(context, isPlaying))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(autoEnter)
            builder.setSeamlessResizeEnabled(true)
        }
        return builder.build()
    }

    private fun computeClampedAspectRatio(width: Int, height: Int): Rational {
        if (width <= 0 || height <= 0) return Rational(16, 9)
        val ratio = width.toFloat() / height.toFloat()
        // Android PiP enforces aspect ratio strictly between 1/2.39 and 2.39/1
        return when {
            ratio > 2.35f -> Rational(235, 100)
            ratio < (1f / 2.35f) -> Rational(100, 235)
            else -> Rational(width, height)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun buildPipActions(context: Context, isPlaying: Boolean): List<RemoteAction> {
        val prevAction = createRemoteAction(
            context = context,
            iconRes = android.R.drawable.ic_media_previous,
            title = context.getString(R.string.pip_action_prev),
            command = PIP_CMD_PREV,
            requestCode = 101
        )
        val playPauseAction = createRemoteAction(
            context = context,
            iconRes = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
            title = context.getString(if (isPlaying) R.string.pip_action_pause else R.string.pip_action_play),
            command = PIP_CMD_PLAY_PAUSE,
            requestCode = 102
        )
        val nextAction = createRemoteAction(
            context = context,
            iconRes = android.R.drawable.ic_media_next,
            title = context.getString(R.string.pip_action_next),
            command = PIP_CMD_NEXT,
            requestCode = 103
        )
        return listOf(prevAction, playPauseAction, nextAction)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createRemoteAction(
        context: Context,
        iconRes: Int,
        title: String,
        command: Int,
        requestCode: Int
    ): RemoteAction {
        val intent = Intent(ACTION_PIP_CONTROL).apply {
            setPackage(context.packageName)
            putExtra(EXTRA_PIP_COMMAND, command)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return RemoteAction(
            Icon.createWithResource(context, iconRes),
            title,
            title,
            pendingIntent
        )
    }
}
