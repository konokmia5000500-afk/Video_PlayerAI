package com.example.data.preferences

import androidx.compose.runtime.Immutable
import com.example.data.model.LibraryLayoutMode
import com.example.data.model.LibraryViewMode
import com.example.data.model.SortDirection
import com.example.data.model.SortField

enum class DecoderMode(val label: String, val badge: String) {
    HW("HW (Hardware)", "HW"),
    HW_PLUS("HW+ (Hardware + Fallback)", "HW+"),
    SW("SW (Software)", "SW")
}

enum class OrientationMode(val label: String) {
    MATCH_VIDEO("Match video"),
    AUTO("System auto"),
    LANDSCAPE("Landscape"),
    PORTRAIT("Portrait"),
    REVERSE_LANDSCAPE("Reverse landscape"),
    SENSOR("Sensor")
}

enum class AppThemeMode(val label: String) {
    DARK("Dark"),
    AMOLED("AMOLED Black"),
    LIGHT("Light")
}

@Immutable
data class PlayerSettings(
    val doubleTapSeekSeconds: Int = 10,
    val swipeSeekSensitivity: Float = 1.0f,
    val gestureBrightnessEnabled: Boolean = true,
    val gestureVolumeEnabled: Boolean = true,
    val gestureSeekEnabled: Boolean = true,
    val gestureDoubleTapEnabled: Boolean = true,
    val gesturePinchZoomEnabled: Boolean = true,
    val defaultSpeed: Float = 1.0f,
    val defaultDecoderMode: DecoderMode = DecoderMode.HW_PLUS,
    val defaultOrientationMode: OrientationMode = OrientationMode.MATCH_VIDEO,
    val resumePlayback: Boolean = true,
    val autoPlayNext: Boolean = true,
    val keepScreenOn: Boolean = true,
    val autoPip: Boolean = true,
    val backgroundPlay: Boolean = false,
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val libraryViewMode: LibraryViewMode = LibraryViewMode.FOLDERS,
    val libraryLayoutMode: LibraryLayoutMode = LibraryLayoutMode.LIST,
    val sortField: SortField = SortField.DATE,
    val sortDirection: SortDirection = SortDirection.DESC,
    val showHiddenFolders: Boolean = false,
    val eqEnabled: Boolean = false,
    val eqPresetIndex: Int = 0,
    val eqBandLevels: List<Int> = listOf(0, 0, 0, 0, 0),
    val bassBoostStrength: Int = 0,
    val virtualizerStrength: Int = 0,
    val recentNetworkUrls: List<String> = emptyList()
)
