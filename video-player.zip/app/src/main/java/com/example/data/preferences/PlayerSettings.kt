package com.example.data.preferences

import androidx.compose.runtime.Immutable
import com.example.data.model.LibraryLayoutMode
import com.example.data.model.LibraryViewMode
import com.example.data.model.SortDirection
import com.example.data.model.SortField
import com.example.player.engine.AspectRatioMode
import com.example.player.engine.LoopMode

enum class DecoderMode(val label: String, val badge: String) {
    HW("HW (Hardware)", "HW"),
    HW_PLUS("HW+ (Hardware + Fallback)", "HW+"),
    SW("SW (Software)", "SW")
}

enum class OrientationMode(val label: String) {
    MATCH_VIDEO("Match video"),
    AUTO("System auto"),
    LANDSCAPE("Landscape"),
    PORTRAIT("Portrait"),
    REVERSE_LANDSCAPE("Reverse landscape"),
    SENSOR("Sensor")
}

enum class AppThemeMode(val label: String) {
    DARK("Ocean Navy (Dark)"),
    AMOLED("Midnight AMOLED"),
    LIGHT("Sky Ice (Light)")
}

enum class HomeStartTab(val label: String) {
    HOME("Home"),
    VIDEOS("Videos"),
    FOLDERS("Folders"),
    PLAYLISTS("Playlists"),
    NETWORK("Network")
}

enum class SubtitleBackgroundStyle(val label: String) {
    NONE("None"),
    SEMI_BLACK("Semi-transparent"),
    OUTLINE_SHADOW("Drop shadow"),
    SOLID_NAVY("Ocean pill")
}

@Immutable
data class PlayerSettings(
    val doubleTapSeekSeconds: Int = 10,
    val swipeSeekSensitivity: Float = 1.0f,
    val gestureBrightnessEnabled: Boolean = true,
    val gestureVolumeEnabled: Boolean = true,
    val gestureSeekEnabled: Boolean = true,
    val gestureDoubleTapEnabled: Boolean = true,
    val gesturePinchZoomEnabled: Boolean = true,
    val defaultSpeed: Float = 1.0f,
    val defaultDecoderMode: DecoderMode = DecoderMode.HW_PLUS,
    val defaultOrientationMode: OrientationMode = OrientationMode.MATCH_VIDEO,
    val defaultAspectRatioMode: AspectRatioMode = AspectRatioMode.FIT,
    val defaultLoopMode: LoopMode = LoopMode.OFF,
    val defaultSleepTimerMinutes: Int = 0,
    val resumePlayback: Boolean = true,
    val autoPlayNext: Boolean = true,
    val keepScreenOn: Boolean = true,
    val autoPip: Boolean = true,
    val autoFullscreen: Boolean = true,
    val backgroundPlay: Boolean = false,
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val startTab: HomeStartTab = HomeStartTab.HOME,
    val showThumbnails: Boolean = true,
    val libraryViewMode: LibraryViewMode = LibraryViewMode.FOLDERS,
    val libraryLayoutMode: LibraryLayoutMode = LibraryLayoutMode.LIST,
    val sortField: SortField = SortField.DATE,
    val sortDirection: SortDirection = SortDirection.DESC,
    val showHiddenFolders: Boolean = false,
    val subtitleEnabledByDefault: Boolean = true,
    val subtitleFontSizeSp: Int = 18,
    val subtitleTextColorHex: Long = 0xFFFFFFFF,
    val subtitleBackgroundStyle: SubtitleBackgroundStyle = SubtitleBackgroundStyle.SEMI_BLACK,
    val subtitleBottomPaddingFraction: Float = 0.08f,
    val subtitleEncoding: String = "UTF-8",
    val eqEnabled: Boolean = false,
    val eqPresetIndex: Int = 0,
    val eqBandLevels: List<Int> = listOf(0, 0, 0, 0, 0),
    val bassBoostStrength: Int = 0,
    val virtualizerStrength: Int = 0,
    val recentNetworkUrls: List<String> = emptyList()
)
