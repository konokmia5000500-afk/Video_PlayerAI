package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.LibraryLayoutMode
import com.example.data.model.LibraryViewMode
import com.example.data.model.SortDirection
import com.example.data.model.SortField
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.playerDataStore: DataStore<Preferences> by preferencesDataStore(name = "video_player_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val DOUBLE_TAP_SEEK_SEC = intPreferencesKey("double_tap_seek_sec")
        val SWIPE_SEEK_SENSITIVITY = floatPreferencesKey("swipe_seek_sensitivity")
        val GESTURE_BRIGHTNESS = booleanPreferencesKey("gesture_brightness")
        val GESTURE_VOLUME = booleanPreferencesKey("gesture_volume")
        val GESTURE_SEEK = booleanPreferencesKey("gesture_seek")
        val GESTURE_DOUBLE_TAP = booleanPreferencesKey("gesture_double_tap")
        val GESTURE_PINCH_ZOOM = booleanPreferencesKey("gesture_pinch_zoom")
        val DEFAULT_SPEED = floatPreferencesKey("default_speed")
        val DEFAULT_DECODER = stringPreferencesKey("default_decoder")
        val DEFAULT_ORIENTATION = stringPreferencesKey("default_orientation")
        val RESUME_PLAYBACK = booleanPreferencesKey("resume_playback")
        val AUTO_PLAY_NEXT = booleanPreferencesKey("auto_play_next")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val AUTO_PIP = booleanPreferencesKey("auto_pip")
        val BACKGROUND_PLAY = booleanPreferencesKey("background_play")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LIBRARY_VIEW_MODE = stringPreferencesKey("library_view_mode")
        val LIBRARY_LAYOUT_MODE = stringPreferencesKey("library_layout_mode")
        val SORT_FIELD = stringPreferencesKey("sort_field")
        val SORT_DIRECTION = stringPreferencesKey("sort_direction")
        val SHOW_HIDDEN_FOLDERS = booleanPreferencesKey("show_hidden_folders")
        val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
        val EQ_PRESET_INDEX = intPreferencesKey("eq_preset_index")
        val EQ_BAND_LEVELS = stringPreferencesKey("eq_band_levels")
        val BASS_BOOST = intPreferencesKey("bass_boost")
        val VIRTUALIZER = intPreferencesKey("virtualizer")
        val RECENT_URLS = stringPreferencesKey("recent_network_urls")
    }

    val settingsFlow: Flow<PlayerSettings> = context.playerDataStore.data.map { prefs ->
        PlayerSettings(
            doubleTapSeekSeconds = prefs[Keys.DOUBLE_TAP_SEEK_SEC] ?: 10,
            swipeSeekSensitivity = prefs[Keys.SWIPE_SEEK_SENSITIVITY] ?: 1.0f,
            gestureBrightnessEnabled = prefs[Keys.GESTURE_BRIGHTNESS] ?: true,
            gestureVolumeEnabled = prefs[Keys.GESTURE_VOLUME] ?: true,
            gestureSeekEnabled = prefs[Keys.GESTURE_SEEK] ?: true,
            gestureDoubleTapEnabled = prefs[Keys.GESTURE_DOUBLE_TAP] ?: true,
            gesturePinchZoomEnabled = prefs[Keys.GESTURE_PINCH_ZOOM] ?: true,
            defaultSpeed = prefs[Keys.DEFAULT_SPEED] ?: 1.0f,
            defaultDecoderMode = enumValueOrDefault(prefs[Keys.DEFAULT_DECODER], DecoderMode.HW_PLUS),
            defaultOrientationMode = enumValueOrDefault(prefs[Keys.DEFAULT_ORIENTATION], OrientationMode.MATCH_VIDEO),
            resumePlayback = prefs[Keys.RESUME_PLAYBACK] ?: true,
            autoPlayNext = prefs[Keys.AUTO_PLAY_NEXT] ?: true,
            keepScreenOn = prefs[Keys.KEEP_SCREEN_ON] ?: true,
            autoPip = prefs[Keys.AUTO_PIP] ?: true,
            backgroundPlay = prefs[Keys.BACKGROUND_PLAY] ?: false,
            themeMode = enumValueOrDefault(prefs[Keys.THEME_MODE], AppThemeMode.DARK),
            libraryViewMode = enumValueOrDefault(prefs[Keys.LIBRARY_VIEW_MODE], LibraryViewMode.FOLDERS),
            libraryLayoutMode = enumValueOrDefault(prefs[Keys.LIBRARY_LAYOUT_MODE], LibraryLayoutMode.LIST),
            sortField = enumValueOrDefault(prefs[Keys.SORT_FIELD], SortField.DATE),
            sortDirection = enumValueOrDefault(prefs[Keys.SORT_DIRECTION], SortDirection.DESC),
            showHiddenFolders = prefs[Keys.SHOW_HIDDEN_FOLDERS] ?: false,
            eqEnabled = prefs[Keys.EQ_ENABLED] ?: false,
            eqPresetIndex = prefs[Keys.EQ_PRESET_INDEX] ?: 0,
            eqBandLevels = parseIntList(prefs[Keys.EQ_BAND_LEVELS]) ?: listOf(0, 0, 0, 0, 0),
            bassBoostStrength = prefs[Keys.BASS_BOOST] ?: 0,
            virtualizerStrength = prefs[Keys.VIRTUALIZER] ?: 0,
            recentNetworkUrls = prefs[Keys.RECENT_URLS]
                ?.split("\n")
                ?.filter { it.isNotBlank() }
                ?: emptyList()
        )
    }

    suspend fun updateDoubleTapSeekSeconds(seconds: Int) = edit { it[Keys.DOUBLE_TAP_SEEK_SEC] = seconds }
    suspend fun updateSwipeSeekSensitivity(value: Float) = edit { it[Keys.SWIPE_SEEK_SENSITIVITY] = value }
    suspend fun updateGestureBrightness(enabled: Boolean) = edit { it[Keys.GESTURE_BRIGHTNESS] = enabled }
    suspend fun updateGestureVolume(enabled: Boolean) = edit { it[Keys.GESTURE_VOLUME] = enabled }
    suspend fun updateGestureSeek(enabled: Boolean) = edit { it[Keys.GESTURE_SEEK] = enabled }
    suspend fun updateGestureDoubleTap(enabled: Boolean) = edit { it[Keys.GESTURE_DOUBLE_TAP] = enabled }
    suspend fun updateGesturePinchZoom(enabled: Boolean) = edit { it[Keys.GESTURE_PINCH_ZOOM] = enabled }
    suspend fun updateDefaultSpeed(speed: Float) = edit { it[Keys.DEFAULT_SPEED] = speed }
    suspend fun updateDefaultDecoder(mode: DecoderMode) = edit { it[Keys.DEFAULT_DECODER] = mode.name }
    suspend fun updateDefaultOrientation(mode: OrientationMode) = edit { it[Keys.DEFAULT_ORIENTATION] = mode.name }
    suspend fun updateResumePlayback(enabled: Boolean) = edit { it[Keys.RESUME_PLAYBACK] = enabled }
    suspend fun updateAutoPlayNext(enabled: Boolean) = edit { it[Keys.AUTO_PLAY_NEXT] = enabled }
    suspend fun updateKeepScreenOn(enabled: Boolean) = edit { it[Keys.KEEP_SCREEN_ON] = enabled }
    suspend fun updateAutoPip(enabled: Boolean) = edit { it[Keys.AUTO_PIP] = enabled }
    suspend fun updateBackgroundPlay(enabled: Boolean) = edit { it[Keys.BACKGROUND_PLAY] = enabled }
    suspend fun updateThemeMode(mode: AppThemeMode) = edit { it[Keys.THEME_MODE] = mode.name }
    suspend fun updateLibraryViewMode(mode: LibraryViewMode) = edit { it[Keys.LIBRARY_VIEW_MODE] = mode.name }
    suspend fun updateLibraryLayoutMode(mode: LibraryLayoutMode) = edit { it[Keys.LIBRARY_LAYOUT_MODE] = mode.name }
    suspend fun updateSort(field: SortField, direction: SortDirection) = edit {
        it[Keys.SORT_FIELD] = field.name
        it[Keys.SORT_DIRECTION] = direction.name
    }
    suspend fun updateShowHiddenFolders(show: Boolean) = edit { it[Keys.SHOW_HIDDEN_FOLDERS] = show }

    suspend fun updateEqualizer(
        enabled: Boolean,
        presetIndex: Int,
        bandLevels: List<Int>,
        bassBoost: Int,
        virtualizer: Int
    ) = edit {
        it[Keys.EQ_ENABLED] = enabled
        it[Keys.EQ_PRESET_INDEX] = presetIndex
        it[Keys.EQ_BAND_LEVELS] = bandLevels.joinToString(",")
        it[Keys.BASS_BOOST] = bassBoost
        it[Keys.VIRTUALIZER] = virtualizer
    }

    suspend fun addRecentNetworkUrl(url: String) = edit { prefs ->
        val existing = prefs[Keys.RECENT_URLS]?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()
        val updated = (listOf(url.trim()) + existing.filterNot { it == url.trim() }).take(8)
        prefs[Keys.RECENT_URLS] = updated.joinToString("\n")
    }

    private suspend inline fun edit(crossinline block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.playerDataStore.edit { block(it) }
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(raw: String?, default: T): T {
        if (raw.isNullOrBlank()) return default
        return runCatching { enumValueOf<T>(raw) }.getOrDefault(default)
    }

    private fun parseIntList(raw: String?): List<Int>? {
        if (raw.isNullOrBlank()) return null
        val parsed = raw.split(",").mapNotNull { it.trim().toIntOrNull() }
        return if (parsed.size == 5) parsed else null
    }
}
