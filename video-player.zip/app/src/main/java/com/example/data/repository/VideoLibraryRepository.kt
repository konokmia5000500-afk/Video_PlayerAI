package com.example.data.repository

import android.content.IntentSender
import android.net.Uri
import com.example.data.local.HiddenFolderEntity
import com.example.data.local.PlaybackProgressEntity
import com.example.data.local.VideoDao
import com.example.data.local.VideoEntity
import com.example.data.mediastore.MediaOperationResult
import com.example.data.mediastore.MediaStoreScanner
import com.example.data.model.FolderItem
import com.example.data.model.VideoItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class VideoLibraryRepository(
    private val videoDao: VideoDao,
    private val scanner: MediaStoreScanner
) {
    private val syncMutex = Mutex()

    companion object {
        private const val NEW_THRESHOLD_SEC = 7L * 24L * 60L * 60L
    }

    val mediaChangesFlow: Flow<Unit> = scanner.observeMediaChanges()

    val videosFlow: Flow<List<VideoItem>> = combine(
        videoDao.observeCachedVideos(),
        videoDao.observePlaybackProgress()
    ) { entities, progressList ->
        val progressMap = progressList.associateBy { it.mediaKey }
        val latestPlayedKey = progressList.maxByOrNull { it.lastPlayedAtMs }?.mediaKey
        val nowSec = System.currentTimeMillis() / 1000L

        entities.map { entity ->
            val progress = progressMap[entity.contentUri]
            entity.toDomain(
                lastPositionMs = progress?.positionMs ?: 0L,
                lastPlayedAtMs = progress?.lastPlayedAtMs ?: 0L,
                isNew = entity.dateAddedSec > 0L && (nowSec - entity.dateAddedSec) <= NEW_THRESHOLD_SEC,
                isLastPlayed = entity.contentUri == latestPlayedKey
            )
        }
    }

    val hiddenFolderIdsFlow: Flow<Set<String>> = combine(
        videoDao.observeHiddenFolders(),
        videoDao.observeCachedVideos()
    ) { hidden, _ ->
        hidden.mapTo(HashSet()) { it.bucketId }
    }

    suspend fun refreshFromMediaStore() {
        syncMutex.withLock {
            val scanned = scanner.scanVideos()
            videoDao.replaceVideos(scanned)
        }
    }

    suspend fun hideFolder(bucketId: String) {
        videoDao.setFolderHidden(HiddenFolderEntity(bucketId))
    }

    suspend fun unhideFolder(bucketId: String) {
        videoDao.unhideFolder(bucketId)
    }

    suspend fun saveProgress(mediaKey: String, positionMs: Long, durationMs: Long) {
        if (mediaKey.isBlank()) return
        val safePos = if (durationMs > 0L && positionMs >= durationMs - 2000L) 0L else positionMs.coerceAtLeast(0L)
        videoDao.savePlaybackProgress(
            PlaybackProgressEntity(
                mediaKey = mediaKey,
                positionMs = safePos,
                durationMs = durationMs.coerceAtLeast(0L),
                lastPlayedAtMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun getSavedPosition(mediaKey: String): Long {
        return videoDao.getProgress(mediaKey)?.positionMs ?: 0L
    }

    suspend fun deleteVideos(videos: List<VideoItem>): MediaOperationResult {
        val uris = videos.mapNotNull { runCatching { Uri.parse(it.contentUri) }.getOrNull() }
        val result = scanner.deleteVideos(uris)
        if (result is MediaOperationResult.Success) {
            videoDao.deleteVideosByIds(videos.map { it.id })
        }
        return result
    }

    suspend fun requestRenameApproval(video: VideoItem): IntentSender? {
        return scanner.requestWriteApproval(Uri.parse(video.contentUri))
    }

    suspend fun renameVideo(video: VideoItem, newBaseName: String): MediaOperationResult {
        val sanitized = newBaseName.trim().replace('/', '_').replace('\\', '_')
        if (sanitized.isBlank()) {
            return MediaOperationResult.Failure("Name cannot be empty")
        }
        val ext = video.displayName.substringAfterLast('.', "")
        val newDisplayName = if (ext.isNotBlank() && !sanitized.endsWith(".$ext", ignoreCase = true)) {
            "$sanitized.$ext"
        } else {
            sanitized
        }
        val result = scanner.renameVideo(Uri.parse(video.contentUri), newDisplayName)
        if (result is MediaOperationResult.Success) {
            videoDao.updateVideoDisplayName(
                id = video.id,
                newName = newDisplayName,
                newTitle = newDisplayName.substringBeforeLast('.')
            )
        }
        return result
    }

    fun buildFolders(videos: List<VideoItem>, hiddenIds: Set<String>): List<FolderItem> {
        return videos
            .groupBy { it.folderBucketId }
            .map { (bucketId, items) ->
                val first = items.first()
                FolderItem(
                    bucketId = bucketId,
                    name = first.folderName,
                    path = first.folderPath,
                    videoCount = items.size,
                    totalSizeBytes = items.sumOf { it.sizeBytes },
                    latestAddedSec = items.maxOf { it.dateAddedSec },
                    previewUri = items.maxByOrNull { it.dateAddedSec }?.contentUri ?: first.contentUri,
                    isHidden = bucketId in hiddenIds,
                    hasNew = items.any { it.isNew }
                )
            }
    }

    private fun VideoEntity.toDomain(
        lastPositionMs: Long,
        lastPlayedAtMs: Long,
        isNew: Boolean,
        isLastPlayed: Boolean
    ): VideoItem {
        return VideoItem(
            id = id,
            contentUri = contentUri,
            title = title,
            displayName = displayName,
            path = path,
            folderBucketId = folderBucketId,
            folderName = folderName,
            folderPath = folderPath,
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            width = width,
            height = height,
            dateAddedSec = dateAddedSec,
            dateModifiedSec = dateModifiedSec,
            mimeType = mimeType,
            lastPositionMs = lastPositionMs,
            lastPlayedAtMs = lastPlayedAtMs,
            isNew = isNew,
            isLastPlayed = isLastPlayed
        )
    }
}
