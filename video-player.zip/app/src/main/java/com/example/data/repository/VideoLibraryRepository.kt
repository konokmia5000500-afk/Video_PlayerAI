package com.example.data.repository

import android.content.IntentSender
import android.net.Uri
import com.example.data.local.HiddenFolderEntity
import com.example.data.local.NetworkStreamHistoryEntity
import com.example.data.local.PlaybackProgressEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistItemEntity
import com.example.data.local.VideoDao
import com.example.data.local.VideoEntity
import com.example.data.mediastore.MediaOperationResult
import com.example.data.mediastore.MediaStoreScanner
import com.example.data.model.FolderItem
import com.example.data.model.LibrarySummary
import com.example.data.model.NetworkStreamEntry
import com.example.data.model.PlaylistSummary
import com.example.data.model.PlaylistVideoItem
import com.example.data.model.VideoItem
import com.example.data.model.WatchHistoryItem
import com.example.player.engine.PlaybackQueueItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class VideoLibraryRepository(
    private val videoDao: VideoDao,
    private val scanner: MediaStoreScanner
) {
    private val syncMutex = Mutex()

    companion object {
        private const val NEW_THRESHOLD_SEC = 7L * 24L * 60L * 60L
        private const val COMPLETION_THRESHOLD_MS = 3000L
    }

    val mediaChangesFlow: Flow<Unit> = scanner.observeMediaChanges()

    val videosFlow: Flow<List<VideoItem>> = combine(
        videoDao.observeCachedVideos(),
        videoDao.observePlaybackProgress()
    ) { entities, progressList ->
        val progressMap = progressList.associateBy { it.mediaKey }
        val latestPlayedKey = progressList.maxByOrNull { it.lastPlayedAtMs }?.mediaKey
        val nowSec = System.currentTimeMillis() / 1000L

        entities.map { entity ->
            val progress = progressMap[entity.contentUri]
            entity.toDomain(
                lastPositionMs = progress?.positionMs ?: 0L,
                lastPlayedAtMs = progress?.lastPlayedAtMs ?: 0L,
                playCount = progress?.playCount ?: 0,
                isCompleted = progress?.isCompleted ?: false,
                isNew = entity.dateAddedSec > 0L && (nowSec - entity.dateAddedSec) <= NEW_THRESHOLD_SEC,
                isLastPlayed = entity.contentUri == latestPlayedKey
            )
        }
    }

    val hiddenFolderIdsFlow: Flow<Set<String>> = videoDao.observeHiddenFolders()
        .map { list -> list.mapTo(HashSet()) { it.bucketId } }

    val watchHistoryFlow: Flow<List<WatchHistoryItem>> = combine(
        videoDao.observePlaybackProgress(),
        videoDao.observeCachedVideos()
    ) { progressList, videos ->
        val videoMap = videos.associateBy { it.contentUri }
        progressList
            .sortedByDescending { it.lastPlayedAtMs }
            .mapNotNull { entry ->
                val matched = videoMap[entry.mediaKey]
                if (!entry.isNetworkStream && matched == null && entry.title.isBlank()) {
                    return@mapNotNull null
                }
                WatchHistoryItem(
                    mediaKey = entry.mediaKey,
                    title = matched?.title ?: entry.title.ifBlank {
                        Uri.parse(entry.mediaKey).lastPathSegment?.substringAfterLast('/') ?: "Video"
                    },
                    thumbnailUri = matched?.contentUri ?: if (!entry.isNetworkStream) entry.mediaKey else "",
                    positionMs = entry.positionMs,
                    durationMs = entry.durationMs.takeIf { it > 0L } ?: (matched?.durationMs ?: 0L),
                    lastPlayedAtMs = entry.lastPlayedAtMs,
                    playCount = entry.playCount,
                    isCompleted = entry.isCompleted,
                    dismissedFromResume = entry.dismissedFromResume,
                    isNetworkStream = entry.isNetworkStream,
                    folderBucketId = matched?.folderBucketId ?: entry.folderBucketId,
                    width = matched?.width ?: entry.width,
                    height = matched?.height ?: entry.height
                )
            }
    }

    val resumeCandidateFlow: Flow<WatchHistoryItem?> = watchHistoryFlow.map { history ->
        history.firstOrNull { item ->
            !item.dismissedFromResume &&
                (!item.isCompleted || item.positionMs > 0L)
        } ?: history.firstOrNull { !it.dismissedFromResume }
    }

    val continueWatchingFlow: Flow<List<WatchHistoryItem>> = watchHistoryFlow.map { history ->
        history.filter { !it.isCompleted && it.positionMs > 1500L && !it.dismissedFromResume }
            .take(12)
    }

    val librarySummaryFlow: Flow<LibrarySummary> = combine(
        videosFlow,
        hiddenFolderIdsFlow
    ) { videos, hidden ->
        val visible = videos.filter { it.folderBucketId !in hidden }
        val folderIds = visible.mapTo(HashSet()) { it.folderBucketId }
        LibrarySummary(
            totalVideos = visible.size,
            totalFolders = folderIds.size,
            totalSizeBytes = visible.sumOf { it.sizeBytes }
        )
    }

    val playlistsFlow: Flow<List<PlaylistSummary>> = combine(
        videoDao.observePlaylists(),
        videoDao.observeAllPlaylistItems(),
        videoDao.observeCachedVideos()
    ) { playlists, allItems, cachedVideos ->
        val itemsByPlaylist = allItems.groupBy { it.playlistId }
        val videoMap = cachedVideos.associateBy { it.contentUri }
        playlists.map { playlist ->
            val items = itemsByPlaylist[playlist.id].orEmpty()
            val coverUri = items.firstOrNull { videoMap.containsKey(it.mediaUri) }?.mediaUri
                ?: items.firstOrNull()?.mediaUri
                ?: ""
            PlaylistSummary(
                id = playlist.id,
                name = playlist.name,
                createdAtMs = playlist.createdAtMs,
                updatedAtMs = playlist.updatedAtMs,
                itemCount = items.size,
                coverUri = coverUri,
                totalDurationMs = items.sumOf { it.durationMs.coerceAtLeast(0L) }
            )
        }
    }

    fun observePlaylistVideos(playlistId: Long): Flow<List<PlaylistVideoItem>> = combine(
        videoDao.observePlaylistItems(playlistId),
        videosFlow
    ) { entries, videos ->
        val videoMap = videos.associateBy { it.contentUri }
        entries.map { entry ->
            PlaylistVideoItem(
                entryId = entry.id,
                playlistId = entry.playlistId,
                mediaUri = entry.mediaUri,
                title = videoMap[entry.mediaUri]?.title ?: entry.title,
                durationMs = videoMap[entry.mediaUri]?.durationMs?.takeIf { it > 0L } ?: entry.durationMs,
                sortOrder = entry.sortOrder,
                videoItem = videoMap[entry.mediaUri]
            )
        }
    }

    suspend fun getPlaylistQueue(playlistId: Long): List<PlaybackQueueItem> {
        val entries = videoDao.getPlaylistItemsSync(playlistId)
        val videos = videosFlow.first().associateBy { it.contentUri }
        return entries.map { entry ->
            val v = videos[entry.mediaUri]
            if (v != null) {
                PlaybackQueueItem(
                    uri = v.contentUri,
                    title = v.title,
                    displayName = v.displayName,
                    path = v.path,
                    durationMs = v.durationMs,
                    sizeBytes = v.sizeBytes,
                    width = v.width,
                    height = v.height,
                    mimeType = v.mimeType,
                    folderBucketId = v.folderBucketId
                )
            } else {
                PlaybackQueueItem(
                    uri = entry.mediaUri,
                    title = entry.title,
                    durationMs = entry.durationMs
                )
            }
        }
    }

    val networkStreamHistoryFlow: Flow<List<NetworkStreamEntry>> = videoDao.observeNetworkStreamHistory()
        .map { list ->
            list.map {
                NetworkStreamEntry(
                    id = it.id,
                    url = it.url,
                    title = it.title,
                    lastPlayedAtMs = it.lastPlayedAtMs,
                    playCount = it.playCount
                )
            }
        }

    suspend fun refreshFromMediaStore() {
        syncMutex.withLock {
            val scanned = scanner.scanVideos()
            videoDao.replaceVideos(scanned)
        }
    }

    suspend fun hideFolder(bucketId: String) {
        videoDao.setFolderHidden(HiddenFolderEntity(bucketId))
    }

    suspend fun unhideFolder(bucketId: String) {
        videoDao.unhideFolder(bucketId)
    }

    suspend fun saveProgress(
        mediaKey: String,
        title: String = "",
        positionMs: Long,
        durationMs: Long,
        completed: Boolean = false,
        incrementPlayCount: Boolean = false,
        isNetworkStream: Boolean = false,
        folderBucketId: String = "",
        width: Int = 0,
        height: Int = 0
    ) {
        if (mediaKey.isBlank()) return
        val existing = videoDao.getProgress(mediaKey)
        val reachedEnd = completed || (durationMs > 0L && positionMs >= durationMs - COMPLETION_THRESHOLD_MS)
        val effectivePos = when {
            reachedEnd -> 0L
            positionMs < 0L -> existing?.positionMs ?: 0L
            else -> positionMs.coerceAtLeast(0L)
        }
        val resolvedCount = when {
            existing == null -> 1
            incrementPlayCount -> existing.playCount + 1
            else -> existing.playCount.coerceAtLeast(1)
        }
        videoDao.savePlaybackProgress(
            PlaybackProgressEntity(
                mediaKey = mediaKey,
                title = title.ifBlank { existing?.title.orEmpty() },
                positionMs = effectivePos,
                durationMs = durationMs.coerceAtLeast(existing?.durationMs ?: 0L),
                lastPlayedAtMs = System.currentTimeMillis(),
                playCount = resolvedCount,
                isCompleted = reachedEnd,
                dismissedFromResume = false,
                isNetworkStream = isNetworkStream || (existing?.isNetworkStream == true),
                folderBucketId = folderBucketId.ifBlank { existing?.folderBucketId.orEmpty() },
                width = if (width > 0) width else (existing?.width ?: 0),
                height = if (height > 0) height else (existing?.height ?: 0)
            )
        )
    }

    suspend fun dismissFromResume(mediaKey: String) {
        videoDao.dismissFromResume(mediaKey)
    }

    suspend fun deleteHistoryItem(mediaKey: String) {
        videoDao.deleteHistoryItem(mediaKey)
    }

    suspend fun clearPlaybackHistory() {
        videoDao.clearPlaybackHistory()
    }

    suspend fun getSavedPosition(mediaKey: String): Long {
        val entry = videoDao.getProgress(mediaKey) ?: return 0L
        return if (entry.isCompleted) 0L else entry.positionMs
    }

    // Playlist mutations
    suspend fun createPlaylist(name: String, initialVideos: List<VideoItem> = emptyList()): Long {
        val trimmed = name.trim().ifBlank { "Untitled Playlist" }
        val now = System.currentTimeMillis()
        val id = videoDao.insertPlaylist(
            PlaylistEntity(name = trimmed, createdAtMs = now, updatedAtMs = now)
        )
        if (initialVideos.isNotEmpty()) {
            addVideosToPlaylist(id, initialVideos)
        }
        return id
    }

    suspend fun renamePlaylist(playlistId: Long, newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isNotBlank()) {
            videoDao.renamePlaylist(playlistId, trimmed)
        }
    }

    suspend fun deletePlaylist(playlistId: Long) {
        videoDao.deletePlaylist(playlistId)
    }

    suspend fun addVideosToPlaylist(playlistId: Long, videos: List<VideoItem>) {
        if (videos.isEmpty()) return
        val startOrder = videoDao.getMaxPlaylistSortOrder(playlistId) + 1
        val now = System.currentTimeMillis()
        val entities = videos.mapIndexed { idx, video ->
            PlaylistItemEntity(
                playlistId = playlistId,
                mediaUri = video.contentUri,
                title = video.title,
                durationMs = video.durationMs,
                sortOrder = startOrder + idx,
                addedAtMs = now + idx
            )
        }
        videoDao.insertPlaylistItems(entities)
        videoDao.touchPlaylist(playlistId, now)
    }

    suspend fun removePlaylistEntry(playlistId: Long, entryId: Long) {
        videoDao.deletePlaylistItemByEntryId(entryId)
        videoDao.touchPlaylist(playlistId)
    }

    suspend fun movePlaylistItemUp(playlistId: Long, entries: List<PlaylistVideoItem>, index: Int) {
        if (index <= 0 || index >= entries.size) return
        val current = entries[index]
        val previous = entries[index - 1]
        videoDao.swapPlaylistItemOrders(
            playlistId = playlistId,
            firstEntryId = current.entryId,
            firstOrder = current.sortOrder,
            secondEntryId = previous.entryId,
            secondOrder = previous.sortOrder
        )
    }

    suspend fun movePlaylistItemDown(playlistId: Long, entries: List<PlaylistVideoItem>, index: Int) {
        if (index < 0 || index >= entries.lastIndex) return
        val current = entries[index]
        val next = entries[index + 1]
        videoDao.swapPlaylistItemOrders(
            playlistId = playlistId,
            firstEntryId = current.entryId,
            firstOrder = current.sortOrder,
            secondEntryId = next.entryId,
            secondOrder = next.sortOrder
        )
    }

    // Network stream history mutations
    suspend fun recordNetworkStreamPlay(url: String, title: String) {
        val cleaned = url.trim()
        if (cleaned.isBlank()) return
        val existing = videoDao.getNetworkStreamByUrl(cleaned)
        val resolvedTitle = title.ifBlank {
            Uri.parse(cleaned).lastPathSegment?.substringAfterLast('/')
                ?: Uri.parse(cleaned).host
                ?: "Network Stream"
        }
        videoDao.upsertNetworkStream(
            NetworkStreamHistoryEntity(
                id = existing?.id ?: 0L,
                url = cleaned,
                title = resolvedTitle,
                lastPlayedAtMs = System.currentTimeMillis(),
                playCount = (existing?.playCount ?: 0) + 1
            )
        )
    }

    suspend fun deleteNetworkStream(id: Long) {
        videoDao.deleteNetworkStream(id)
    }

    suspend fun clearNetworkStreamHistory() {
        videoDao.clearNetworkStreamHistory()
    }

    // File operations
    suspend fun deleteVideos(videos: List<VideoItem>): MediaOperationResult {
        val uris = videos.mapNotNull { runCatching { Uri.parse(it.contentUri) }.getOrNull() }
        val result = scanner.deleteVideos(uris)
        if (result is MediaOperationResult.Success) {
            videoDao.deleteVideosByIds(videos.map { it.id })
        }
        return result
    }

    suspend fun requestRenameApproval(video: VideoItem): IntentSender? {
        return scanner.requestWriteApproval(Uri.parse(video.contentUri))
    }

    suspend fun renameVideo(video: VideoItem, newBaseName: String): MediaOperationResult {
        val sanitized = newBaseName.trim().replace('/', '_').replace('\\', '_')
        if (sanitized.isBlank()) {
            return MediaOperationResult.Failure("Name cannot be empty")
        }
        val ext = video.displayName.substringAfterLast('.', "")
        val newDisplayName = if (ext.isNotBlank() && !sanitized.endsWith(".$ext", ignoreCase = true)) {
            "$sanitized.$ext"
        } else {
            sanitized
        }
        val result = scanner.renameVideo(Uri.parse(video.contentUri), newDisplayName)
        if (result is MediaOperationResult.Success) {
            videoDao.updateVideoDisplayName(
                id = video.id,
                newName = newDisplayName,
                newTitle = newDisplayName.substringBeforeLast('.')
            )
        }
        return result
    }

    fun buildFolders(videos: List<VideoItem>, hiddenIds: Set<String>): List<FolderItem> {
        return videos
            .groupBy { it.folderBucketId }
            .map { (bucketId, items) ->
                val first = items.first()
                FolderItem(
                    bucketId = bucketId,
                    name = first.folderName,
                    path = first.folderPath,
                    videoCount = items.size,
                    totalSizeBytes = items.sumOf { it.sizeBytes },
                    latestAddedSec = items.maxOf { it.dateAddedSec },
                    previewUri = items.maxByOrNull { it.dateAddedSec }?.contentUri ?: first.contentUri,
                    isHidden = bucketId in hiddenIds,
                    hasNew = items.any { it.isNew }
                )
            }
    }

    private fun VideoEntity.toDomain(
        lastPositionMs: Long,
        lastPlayedAtMs: Long,
        playCount: Int,
        isCompleted: Boolean,
        isNew: Boolean,
        isLastPlayed: Boolean
    ): VideoItem {
        return VideoItem(
            id = id,
            contentUri = contentUri,
            title = title,
            displayName = displayName,
            path = path,
            folderBucketId = folderBucketId,
            folderName = folderName,
            folderPath = folderPath,
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            width = width,
            height = height,
            dateAddedSec = dateAddedSec,
            dateModifiedSec = dateModifiedSec,
            mimeType = mimeType,
            lastPositionMs = lastPositionMs,
            lastPlayedAtMs = lastPlayedAtMs,
            playCount = playCount,
            isCompleted = isCompleted,
            isNew = isNew,
            isLastPlayed = isLastPlayed
        )
    }
}
