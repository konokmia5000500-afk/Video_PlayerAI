package com.example.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class VideoItem(
    val id: Long,
    val contentUri: String,
    val title: String,
    val displayName: String,
    val path: String,
    val folderBucketId: String,
    val folderName: String,
    val folderPath: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val mimeType: String,
    val lastPositionMs: Long = 0L,
    val lastPlayedAtMs: Long = 0L,
    val isNew: Boolean = false,
    val isLastPlayed: Boolean = false
) {
    val progressFraction: Float
        get() = if (durationMs > 0L && lastPositionMs > 0L) {
            (lastPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    val resolutionScore: Long
        get() = width.toLong() * height.toLong()
}

@Immutable
data class FolderItem(
    val bucketId: String,
    val name: String,
    val path: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
    val latestAddedSec: Long,
    val previewUri: String,
    val isHidden: Boolean,
    val hasNew: Boolean
)

@Immutable
data class VideoProperties(
    val title: String,
    val path: String,
    val resolution: String,
    val videoCodec: String,
    val audioCodec: String,
    val bitrateKbps: Int,
    val fps: Float,
    val sizeBytes: Long,
    val durationMs: Long
)

enum class SortField(val label: String) {
    NAME("Name"),
    DATE("Date"),
    SIZE("Size"),
    DURATION("Duration"),
    RESOLUTION("Resolution")
}

enum class SortDirection(val label: String) {
    ASC("Ascending"),
    DESC("Descending")
}

enum class LibraryViewMode {
    FOLDERS,
    FILES
}

enum class LibraryLayoutMode {
    LIST,
    GRID
}
