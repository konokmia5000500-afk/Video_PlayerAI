package com.example.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class VideoItem(
    val id: Long,
    val contentUri: String,
    val title: String,
    val displayName: String,
    val path: String,
    val folderBucketId: String,
    val folderName: String,
    val folderPath: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val mimeType: String,
    val lastPositionMs: Long = 0L,
    val lastPlayedAtMs: Long = 0L,
    val playCount: Int = 0,
    val isCompleted: Boolean = false,
    val isNew: Boolean = false,
    val isLastPlayed: Boolean = false
) {
    val progressFraction: Float
        get() = if (durationMs > 0L && lastPositionMs > 0L) {
            (lastPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    val resolutionScore: Long
        get() = width.toLong() * height.toLong()
}

@Immutable
data class FolderItem(
    val bucketId: String,
    val name: String,
    val path: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
    val latestAddedSec: Long,
    val previewUri: String,
    val isHidden: Boolean,
    val hasNew: Boolean
)

@Immutable
data class WatchHistoryItem(
    val mediaKey: String,
    val title: String,
    val thumbnailUri: String,
    val positionMs: Long,
    val durationMs: Long,
    val lastPlayedAtMs: Long,
    val playCount: Int,
    val isCompleted: Boolean,
    val dismissedFromResume: Boolean,
    val isNetworkStream: Boolean,
    val folderBucketId: String,
    val width: Int,
    val height: Int
) {
    val progressFraction: Float
        get() = if (durationMs > 0L && positionMs > 0L) {
            (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
}

@Immutable
data class LibrarySummary(
    val totalVideos: Int = 0,
    val totalFolders: Int = 0,
    val totalSizeBytes: Long = 0L
)

@Immutable
data class PlaylistSummary(
    val id: Long,
    val name: String,
    val createdAtMs: Long,
    val updatedAtMs: Long,
    val itemCount: Int,
    val coverUri: String,
    val totalDurationMs: Long
)

@Immutable
data class PlaylistVideoItem(
    val entryId: Long,
    val playlistId: Long,
    val mediaUri: String,
    val title: String,
    val durationMs: Long,
    val sortOrder: Int,
    val videoItem: VideoItem? = null
)

@Immutable
data class NetworkStreamEntry(
    val id: Long,
    val url: String,
    val title: String,
    val lastPlayedAtMs: Long,
    val playCount: Int
)

@Immutable
data class VideoProperties(
    val title: String,
    val path: String,
    val containerFormat: String = "Unknown",
    val mimeType: String = "video/*",
    val resolution: String,
    val videoCodec: String,
    val audioCodec: String,
    val audioChannels: String = "Unknown",
    val bitrateKbps: Int,
    val fps: Float,
    val sizeBytes: Long,
    val durationMs: Long
)

enum class SortField(val label: String) {
    NAME("Name"),
    DATE("Date added"),
    DATE_MODIFIED("Date modified"),
    SIZE("Size"),
    DURATION("Duration"),
    RESOLUTION("Resolution")
}

enum class SortDirection(val label: String) {
    ASC("Ascending"),
    DESC("Descending")
}

enum class LibraryViewMode {
    FOLDERS,
    FILES
}

enum class LibraryLayoutMode {
    LIST,
    GRID
}
