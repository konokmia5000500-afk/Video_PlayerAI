package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {

    @Query("SELECT * FROM cached_videos ORDER BY dateAddedSec DESC")
    fun observeCachedVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM hidden_folders")
    fun observeHiddenFolders(): Flow<List<HiddenFolderEntity>>

    @Query("SELECT * FROM playback_progress")
    fun observePlaybackProgress(): Flow<List<PlaybackProgressEntity>>

    @Query("SELECT * FROM playback_progress WHERE mediaKey = :mediaKey LIMIT 1")
    suspend fun getProgress(mediaKey: String): PlaybackProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVideos(videos: List<VideoEntity>)

    @Query("DELETE FROM cached_videos")
    suspend fun clearVideos()

    @Transaction
    suspend fun replaceVideos(videos: List<VideoEntity>) {
        clearVideos()
        if (videos.isNotEmpty()) {
            upsertVideos(videos)
        }
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setFolderHidden(entity: HiddenFolderEntity)

    @Query("DELETE FROM hidden_folders WHERE bucketId = :bucketId")
    suspend fun unhideFolder(bucketId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlaybackProgress(progress: PlaybackProgressEntity)

    @Query("UPDATE cached_videos SET displayName = :newName, title = :newTitle WHERE id = :id")
    suspend fun updateVideoDisplayName(id: Long, newName: String, newTitle: String)

    @Query("DELETE FROM cached_videos WHERE id IN (:ids)")
    suspend fun deleteVideosByIds(ids: List<Long>)
}
