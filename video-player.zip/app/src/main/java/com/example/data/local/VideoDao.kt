package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {

    @Query("SELECT * FROM cached_videos ORDER BY dateAddedSec DESC")
    fun observeCachedVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM hidden_folders")
    fun observeHiddenFolders(): Flow<List<HiddenFolderEntity>>

    @Query("SELECT * FROM playback_progress ORDER BY lastPlayedAtMs DESC")
    fun observePlaybackProgress(): Flow<List<PlaybackProgressEntity>>

    @Query("SELECT * FROM playback_progress WHERE mediaKey = :mediaKey LIMIT 1")
    suspend fun getProgress(mediaKey: String): PlaybackProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVideos(videos: List<VideoEntity>)

    @Query("DELETE FROM cached_videos")
    suspend fun clearVideos()

    @Transaction
    suspend fun replaceVideos(videos: List<VideoEntity>) {
        clearVideos()
        if (videos.isNotEmpty()) {
            upsertVideos(videos)
        }
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setFolderHidden(entity: HiddenFolderEntity)

    @Query("DELETE FROM hidden_folders WHERE bucketId = :bucketId")
    suspend fun unhideFolder(bucketId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlaybackProgress(progress: PlaybackProgressEntity)

    @Query("UPDATE playback_progress SET dismissedFromResume = 1 WHERE mediaKey = :mediaKey")
    suspend fun dismissFromResume(mediaKey: String)

    @Query("DELETE FROM playback_progress WHERE mediaKey = :mediaKey")
    suspend fun deleteHistoryItem(mediaKey: String)

    @Query("DELETE FROM playback_progress")
    suspend fun clearPlaybackHistory()

    @Query("UPDATE cached_videos SET displayName = :newName, title = :newTitle WHERE id = :id")
    suspend fun updateVideoDisplayName(id: Long, newName: String, newTitle: String)

    @Query("DELETE FROM cached_videos WHERE id IN (:ids)")
    suspend fun deleteVideosByIds(ids: List<Long>)

    // Playlists
    @Query("SELECT * FROM playlists ORDER BY updatedAtMs DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :playlistId LIMIT 1")
    suspend fun getPlaylistById(playlistId: Long): PlaylistEntity?

    @Query("SELECT * FROM playlist_items ORDER BY sortOrder ASC, addedAtMs ASC")
    fun observeAllPlaylistItems(): Flow<List<PlaylistItemEntity>>

    @Query("SELECT * FROM playlist_items WHERE playlistId = :playlistId ORDER BY sortOrder ASC, addedAtMs ASC")
    fun observePlaylistItems(playlistId: Long): Flow<List<PlaylistItemEntity>>

    @Query("SELECT * FROM playlist_items WHERE playlistId = :playlistId ORDER BY sortOrder ASC, addedAtMs ASC")
    suspend fun getPlaylistItemsSync(playlistId: Long): List<PlaylistItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :newName, updatedAtMs = :updatedAtMs WHERE id = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, newName: String, updatedAtMs: Long = System.currentTimeMillis())

    @Query("UPDATE playlists SET updatedAtMs = :updatedAtMs WHERE id = :playlistId")
    suspend fun touchPlaylist(playlistId: Long, updatedAtMs: Long = System.currentTimeMillis())

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("SELECT COALESCE(MAX(sortOrder), -1) FROM playlist_items WHERE playlistId = :playlistId")
    suspend fun getMaxPlaylistSortOrder(playlistId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistItems(items: List<PlaylistItemEntity>)

    @Query("DELETE FROM playlist_items WHERE id = :entryId")
    suspend fun deletePlaylistItemByEntryId(entryId: Long)

    @Query("UPDATE playlist_items SET sortOrder = :sortOrder WHERE id = :entryId")
    suspend fun updatePlaylistItemSortOrder(entryId: Long, sortOrder: Int)

    @Transaction
    suspend fun swapPlaylistItemOrders(
        playlistId: Long,
        firstEntryId: Long,
        firstOrder: Int,
        secondEntryId: Long,
        secondOrder: Int
    ) {
        updatePlaylistItemSortOrder(firstEntryId, secondOrder)
        updatePlaylistItemSortOrder(secondEntryId, firstOrder)
        touchPlaylist(playlistId)
    }

    // Network stream history
    @Query("SELECT * FROM network_stream_history ORDER BY lastPlayedAtMs DESC LIMIT 30")
    fun observeNetworkStreamHistory(): Flow<List<NetworkStreamHistoryEntity>>

    @Query("SELECT * FROM network_stream_history WHERE url = :url LIMIT 1")
    suspend fun getNetworkStreamByUrl(url: String): NetworkStreamHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNetworkStream(entity: NetworkStreamHistoryEntity)

    @Query("DELETE FROM network_stream_history WHERE id = :id")
    suspend fun deleteNetworkStream(id: Long)

    @Query("DELETE FROM network_stream_history")
    suspend fun clearNetworkStreamHistory()
}
