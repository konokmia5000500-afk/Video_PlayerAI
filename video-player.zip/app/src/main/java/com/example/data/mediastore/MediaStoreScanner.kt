package com.example.data.mediastore

import android.app.PendingIntent
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.IntentSender
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import com.example.data.local.VideoEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.withContext
import java.io.File

sealed interface MediaOperationResult {
    data object Success : MediaOperationResult
    data class NeedsApproval(val intentSender: IntentSender) : MediaOperationResult
    data class Failure(val message: String) : MediaOperationResult
}

class MediaStoreScanner(private val context: Context) {

    @Suppress("DEPRECATION")
    suspend fun scanVideos(): List<VideoEntity> = withContext(Dispatchers.IO) {
        val videos = ArrayList<VideoEntity>(128)
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = buildList {
            add(MediaStore.Video.Media._ID)
            add(MediaStore.Video.Media.DISPLAY_NAME)
            add(MediaStore.Video.Media.TITLE)
            add(MediaStore.Video.Media.DURATION)
            add(MediaStore.Video.Media.SIZE)
            add(MediaStore.Video.Media.WIDTH)
            add(MediaStore.Video.Media.HEIGHT)
            add(MediaStore.Video.Media.DATE_ADDED)
            add(MediaStore.Video.Media.DATE_MODIFIED)
            add(MediaStore.Video.Media.MIME_TYPE)
            add(MediaStore.Video.Media.BUCKET_ID)
            add(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            add(MediaStore.Video.Media.DATA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.Video.Media.RELATIVE_PATH)
            }
        }.toTypedArray()

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        runCatching {
            context.contentResolver.query(
                collection,
                projection,
                "${MediaStore.Video.Media.SIZE} > 0",
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndex(MediaStore.Video.Media.TITLE)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val widthCol = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val addedCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val modCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val bucketIdCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_ID)
                val bucketNameCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val dataCol = cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH)
                } else {
                    -1
                }

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    ).toString()

                    val displayName = if (nameCol >= 0) cursor.getString(nameCol).orEmpty() else ""
                    val rawTitle = if (titleCol >= 0) cursor.getString(titleCol).orEmpty() else ""
                    val title = rawTitle.ifBlank { displayName.substringBeforeLast('.') }.ifBlank { "Video" }
                    val durationMs = if (durCol >= 0) cursor.getLong(durCol).coerceAtLeast(0L) else 0L
                    val sizeBytes = if (sizeCol >= 0) cursor.getLong(sizeCol).coerceAtLeast(0L) else 0L
                    val width = if (widthCol >= 0) cursor.getInt(widthCol).coerceAtLeast(0) else 0
                    val height = if (heightCol >= 0) cursor.getInt(heightCol).coerceAtLeast(0) else 0
                    val dateAdded = if (addedCol >= 0) cursor.getLong(addedCol).coerceAtLeast(0L) else 0L
                    val dateMod = if (modCol >= 0) cursor.getLong(modCol).coerceAtLeast(0L) else 0L
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) ?: "video/*" else "video/*"

                    val rawPath = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
                    val relPath = if (relCol >= 0) cursor.getString(relCol).orEmpty() else ""
                    val folderPath = when {
                        rawPath.isNotBlank() -> File(rawPath).parent.orEmpty()
                        relPath.isNotBlank() -> relPath.trimEnd('/')
                        else -> "Internal Storage"
                    }
                    val folderName = (if (bucketNameCol >= 0) cursor.getString(bucketNameCol) else null)
                        ?.takeIf { it.isNotBlank() }
                        ?: folderPath.substringAfterLast('/').ifBlank { "Internal Storage" }
                    val bucketId = (if (bucketIdCol >= 0) cursor.getString(bucketIdCol) else null)
                        ?.takeIf { it.isNotBlank() }
                        ?: folderPath.hashCode().toString()

                    videos.add(
                        VideoEntity(
                            id = id,
                            contentUri = contentUri,
                            title = title,
                            displayName = displayName.ifBlank { "$title.mp4" },
                            path = rawPath.ifBlank { "$folderPath/$displayName" },
                            folderBucketId = bucketId,
                            folderName = folderName,
                            folderPath = folderPath,
                            durationMs = durationMs,
                            sizeBytes = sizeBytes,
                            width = width,
                            height = height,
                            dateAddedSec = dateAdded,
                            dateModifiedSec = dateMod,
                            mimeType = mime
                        )
                    )
                }
            }
        }
        videos
    }

    @OptIn(FlowPreview::class)
    fun observeMediaChanges(): Flow<Unit> = callbackFlow {
        val handler = Handler(Looper.getMainLooper())
        val observer = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        context.contentResolver.registerContentObserver(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            true,
            observer
        )
        awaitClose {
            context.contentResolver.unregisterContentObserver(observer)
        }
    }.debounce(450L)

    suspend fun deleteVideos(uris: List<Uri>): MediaOperationResult = withContext(Dispatchers.IO) {
        if (uris.isEmpty()) return@withContext MediaOperationResult.Success
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return@withContext try {
                val pendingIntent: PendingIntent = MediaStore.createDeleteRequest(
                    context.contentResolver,
                    uris
                )
                MediaOperationResult.NeedsApproval(pendingIntent.intentSender)
            } catch (t: Throwable) {
                MediaOperationResult.Failure(t.localizedMessage ?: "Unable to request deletion")
            }
        }
        return@withContext try {
            for (uri in uris) {
                context.contentResolver.delete(uri, null, null)
            }
            MediaOperationResult.Success
        } catch (sec: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && sec is RecoverableSecurityException) {
                MediaOperationResult.NeedsApproval(sec.userAction.actionIntent.intentSender)
            } else {
                MediaOperationResult.Failure(sec.localizedMessage ?: "Permission denied")
            }
        } catch (t: Throwable) {
            MediaOperationResult.Failure(t.localizedMessage ?: "Delete failed")
        }
    }

    suspend fun requestWriteApproval(uri: Uri): IntentSender? = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching {
                MediaStore.createWriteRequest(context.contentResolver, listOf(uri)).intentSender
            }.getOrNull()
        } else {
            null
        }
    }

    suspend fun renameVideo(uri: Uri, newDisplayName: String): MediaOperationResult = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, newDisplayName)
        }
        return@withContext try {
            val rows = context.contentResolver.update(uri, values, null, null)
            if (rows > 0) {
                MediaOperationResult.Success
            } else {
                MediaOperationResult.Failure("File could not be renamed")
            }
        } catch (sec: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && sec is RecoverableSecurityException) {
                MediaOperationResult.NeedsApproval(sec.userAction.actionIntent.intentSender)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val sender = requestWriteApproval(uri)
                if (sender != null) {
                    MediaOperationResult.NeedsApproval(sender)
                } else {
                    MediaOperationResult.Failure(sec.localizedMessage ?: "Write permission required")
                }
            } else {
                MediaOperationResult.Failure(sec.localizedMessage ?: "Permission denied")
            }
        } catch (t: Throwable) {
            MediaOperationResult.Failure(t.localizedMessage ?: "Rename failed")
        }
    }
}
