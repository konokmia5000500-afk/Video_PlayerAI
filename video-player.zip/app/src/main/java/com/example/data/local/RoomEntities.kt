package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "cached_videos",
    indices = [
        Index(value = ["folderBucketId"]),
        Index(value = ["dateAddedSec"])
    ]
)
data class VideoEntity(
    @PrimaryKey val id: Long,
    val contentUri: String,
    val title: String,
    val displayName: String,
    val path: String,
    val folderBucketId: String,
    val folderName: String,
    val folderPath: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val mimeType: String
)

@Entity(tableName = "hidden_folders")
data class HiddenFolderEntity(
    @PrimaryKey val bucketId: String,
    val hiddenAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "playback_progress")
data class PlaybackProgressEntity(
    @PrimaryKey val mediaKey: String,
    val positionMs: Long,
    val durationMs: Long,
    val lastPlayedAtMs: Long
)
