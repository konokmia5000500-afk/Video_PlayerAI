package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "cached_videos",
    indices = [
        Index(value = ["folderBucketId"]),
        Index(value = ["dateAddedSec"])
    ]
)
data class VideoEntity(
    @PrimaryKey val id: Long,
    val contentUri: String,
    val title: String,
    val displayName: String,
    val path: String,
    val folderBucketId: String,
    val folderName: String,
    val folderPath: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val mimeType: String
)

@Entity(tableName = "hidden_folders")
data class HiddenFolderEntity(
    @PrimaryKey val bucketId: String,
    val hiddenAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playback_progress",
    indices = [
        Index(value = ["lastPlayedAtMs"])
    ]
)
data class PlaybackProgressEntity(
    @PrimaryKey val mediaKey: String,
    val title: String = "",
    val positionMs: Long,
    val durationMs: Long,
    val lastPlayedAtMs: Long,
    val playCount: Int = 1,
    val isCompleted: Boolean = false,
    val dismissedFromResume: Boolean = false,
    val isNetworkStream: Boolean = false,
    val folderBucketId: String = "",
    val width: Int = 0,
    val height: Int = 0
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_items",
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["playlistId", "sortOrder"])
    ]
)
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val playlistId: Long,
    val mediaUri: String,
    val title: String,
    val durationMs: Long,
    val sortOrder: Int,
    val addedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "network_stream_history",
    indices = [
        Index(value = ["url"], unique = true),
        Index(value = ["lastPlayedAtMs"])
    ]
)
data class NetworkStreamHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val url: String,
    val title: String,
    val lastPlayedAtMs: Long = System.currentTimeMillis(),
    val playCount: Int = 1
)
