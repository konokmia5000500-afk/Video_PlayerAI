package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StrictMode
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.PictureInPictureModeChangedInfo
import androidx.core.util.Consumer
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.preferences.AppThemeMode
import com.example.player.service.PlaybackService
import com.example.ui.library.LibraryScreen
import com.example.ui.navigation.LibraryRoute
import com.example.ui.navigation.PlayerRoute
import com.example.ui.navigation.SettingsRoute
import com.example.ui.player.PlayerScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.VideoPlayerTheme
import kotlinx.coroutines.flow.MutableStateFlow

class MainActivity : ComponentActivity() {

    private val isInPipModeState = MutableStateFlow(false)
    private var leaveHintPipCallback: (() -> Unit)? = null
    private var externalOpenUri by mutableStateOf<Pair<String, String>?>(null)

    private val pipListener = Consumer<PictureInPictureModeChangedInfo> { info ->
        isInPipModeState.value = info.isInPictureInPictureMode
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy.Builder()
                    .detectNetwork()
                    .penaltyLog()
                    .build()
            )
            StrictMode.setVmPolicy(
                StrictMode.VmPolicy.Builder()
                    .detectLeakedClosableObjects()
                    .detectActivityLeaks()
                    .penaltyLog()
                    .build()
            )
        }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        addOnPictureInPictureModeChangedListener(pipListener)
        handleIncomingIntent(intent)

        val container = AppContainer.getInstance(applicationContext)

        setContent {
            val settings by container.settingsRepository.settingsFlow.collectAsStateWithLifecycle(
                initialValue = com.example.data.preferences.PlayerSettings()
            )
            val isInPipMode by isInPipModeState.collectAsStateWithLifecycle()
            val navController = rememberNavController()

            LaunchedEffect(externalOpenUri) {
                val pending = externalOpenUri ?: return@LaunchedEffect
                externalOpenUri = null
                navController.navigate(
                    PlayerRoute(
                        startUri = pending.first,
                        folderBucketId = "",
                        title = pending.second
                    )
                ) {
                    launchSingleTop = true
                }
            }

            VideoPlayerTheme(themeMode = settings.themeMode) {
                NavHost(
                    navController = navController,
                    startDestination = LibraryRoute
                ) {
                    composable<LibraryRoute> {
                        LibraryScreen(
                            onPlayVideo = { video ->
                                navController.navigate(
                                    PlayerRoute(
                                        startUri = video.contentUri,
                                        folderBucketId = video.folderBucketId,
                                        title = video.title
                                    )
                                )
                            },
                            onPlayStreamUrl = { url ->
                                navController.navigate(
                                    PlayerRoute(
                                        startUri = url,
                                        folderBucketId = "",
                                        title = Uri.parse(url).lastPathSegment ?: "Network Stream",
                                        isNetworkStream = true
                                    )
                                )
                            },
                            onOpenSettings = {
                                navController.navigate(SettingsRoute)
                            }
                        )
                    }

                    composable<PlayerRoute> { backStackEntry ->
                        val route = backStackEntry.toRoute<PlayerRoute>()
                        VideoPlayerTheme(
                            themeMode = AppThemeMode.DARK,
                            forceDarkSystemBars = true
                        ) {
                            PlayerScreen(
                                startUri = route.startUri,
                                folderBucketId = route.folderBucketId,
                                title = route.title,
                                isInPipMode = isInPipMode,
                                onRegisterLeaveHintPip = { callback ->
                                    leaveHintPipCallback = callback
                                },
                                onBack = { navController.popBackStack() },
                                onOpenSettings = { navController.navigate(SettingsRoute) }
                            )
                        }
                    }

                    composable<SettingsRoute> {
                        SettingsScreen(onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        leaveHintPipCallback?.invoke()
    }

    override fun onDestroy() {
        removeOnPictureInPictureModeChangedListener(pipListener)
        super.onDestroy()
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.action == Intent.ACTION_VIEW) {
            val dataUri = intent.data ?: return
            val title = intent.getStringExtra(Intent.EXTRA_TITLE)
                ?: dataUri.lastPathSegment
                ?: "Video"
            externalOpenUri = dataUri.toString() to title
        } else if (intent.getBooleanExtra(PlaybackService.EXTRA_OPEN_PLAYER, false)) {
            // Returning from MediaSession notification; if backstack already has PlayerRoute it stays visible.
        }
    }
}
