package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StrictMode
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.PictureInPictureModeChangedInfo
import androidx.core.util.Consumer
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.PlayerSettings
import com.example.player.service.PlaybackService
import com.example.ui.history.HistoryScreen
import com.example.ui.home.MainHubScreen
import com.example.ui.navigation.HistoryRoute
import com.example.ui.navigation.MainHubRoute
import com.example.ui.navigation.PlayerRoute
import com.example.ui.navigation.PlaylistDetailRoute
import com.example.ui.navigation.SettingsRoute
import com.example.ui.player.PlayerScreen
import com.example.ui.playlists.PlaylistDetailScreen
import com.example.ui.playlists.PlaylistsViewModel
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.VideoPlayerTheme
import kotlinx.coroutines.flow.MutableStateFlow

class MainActivity : ComponentActivity() {

    private val isInPipModeState = MutableStateFlow(false)
    private var leaveHintPipCallback: (() -> Unit)? = null
    private var externalOpenUri by mutableStateOf<Pair<String, String>?>(null)

    private val pipListener = Consumer<PictureInPictureModeChangedInfo> { info ->
        isInPipModeState.value = info.isInPictureInPictureMode
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy.Builder()
                    .detectNetwork()
                    .penaltyLog()
                    .build()
            )
            StrictMode.setVmPolicy(
                StrictMode.VmPolicy.Builder()
                    .detectLeakedClosableObjects()
                    .detectActivityLeaks()
                    .penaltyLog()
                    .build()
            )
        }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        addOnPictureInPictureModeChangedListener(pipListener)
        handleIncomingIntent(intent)

        val container = AppContainer.getInstance(applicationContext)

        setContent {
            val settings by container.settingsRepository.settingsFlow.collectAsStateWithLifecycle(
                initialValue = PlayerSettings()
            )
            val isInPipMode by isInPipModeState.collectAsStateWithLifecycle()
            val navController = rememberNavController()

            LaunchedEffect(externalOpenUri) {
                val pending = externalOpenUri ?: return@LaunchedEffect
                externalOpenUri = null
                val scheme = Uri.parse(pending.first).scheme?.lowercase().orEmpty()
                val isNet = scheme == "http" || scheme == "https" || scheme == "rtsp"
                navController.navigate(
                    PlayerRoute(
                        startUri = pending.first,
                        folderBucketId = "",
                        title = pending.second,
                        isNetworkStream = isNet
                    )
                ) {
                    launchSingleTop = true
                }
            }

            VideoPlayerTheme(themeMode = settings.themeMode) {
                NavHost(
                    navController = navController,
                    startDestination = MainHubRoute
                ) {
                    composable<MainHubRoute> {
                        MainHubScreen(
                            onPlayVideo = { video ->
                                navController.navigate(
                                    PlayerRoute(
                                        startUri = video.contentUri,
                                        folderBucketId = video.folderBucketId,
                                        title = video.title
                                    )
                                )
                            },
                            onPlayHistoryItem = { historyItem ->
                                navController.navigate(
                                    PlayerRoute(
                                        startUri = historyItem.mediaKey,
                                        folderBucketId = historyItem.folderBucketId,
                                        title = historyItem.title,
                                        isNetworkStream = historyItem.isNetworkStream,
                                        initialPositionMs = if (historyItem.isCompleted) 0L else historyItem.positionMs
                                    )
                                )
                            },
                            onPlayPlaylist = { playlistId, startUri, title ->
                                navController.navigate(
                                    PlayerRoute(
                                        startUri = startUri,
                                        folderBucketId = "",
                                        playlistId = playlistId,
                                        title = title
                                    )
                                )
                            },
                            onPlayStreamUrl = { url, title ->
                                val resolvedTitle = title.ifBlank {
                                    Uri.parse(url).lastPathSegment ?: "Network Stream"
                                }
                                navController.navigate(
                                    PlayerRoute(
                                        startUri = url,
                                        folderBucketId = "",
                                        title = resolvedTitle,
                                        isNetworkStream = true
                                    )
                                )
                            },
                            onOpenPlaylistDetail = { playlistId ->
                                navController.navigate(PlaylistDetailRoute(playlistId = playlistId))
                            },
                            onOpenHistory = {
                                navController.navigate(HistoryRoute)
                            },
                            onOpenSettings = {
                                navController.navigate(SettingsRoute)
                            }
                        )
                    }

                    composable<HistoryRoute> {
                        HistoryScreen(
                            onBack = { navController.popBackStack() },
                            onPlayHistoryItem = { historyItem ->
                                navController.navigate(
                                    PlayerRoute(
                                        startUri = historyItem.mediaKey,
                                        folderBucketId = historyItem.folderBucketId,
                                        title = historyItem.title,
                                        isNetworkStream = historyItem.isNetworkStream,
                                        initialPositionMs = if (historyItem.isCompleted) 0L else historyItem.positionMs
                                    )
                                )
                            }
                        )
                    }

                    composable<PlaylistDetailRoute> { backStackEntry ->
                        val route = backStackEntry.toRoute<PlaylistDetailRoute>()
                        val playlistsViewModel: PlaylistsViewModel = viewModel()
                        PlaylistDetailScreen(
                            playlistId = route.playlistId,
                            viewModel = playlistsViewModel,
                            onBack = { navController.popBackStack() },
                            onPlayPlaylistItem = { playlistId, startUri, title ->
                                navController.navigate(
                                    PlayerRoute(
                                        startUri = startUri,
                                        folderBucketId = "",
                                        playlistId = playlistId,
                                        title = title
                                    )
                                )
                            }
                        )
                    }

                    composable<PlayerRoute> { backStackEntry ->
                        val route = backStackEntry.toRoute<PlayerRoute>()
                        VideoPlayerTheme(
                            themeMode = AppThemeMode.DARK,
                            forceDarkSystemBars = true
                        ) {
                            PlayerScreen(
                                startUri = route.startUri,
                                folderBucketId = route.folderBucketId,
                                playlistId = route.playlistId,
                                title = route.title,
                                isNetworkStream = route.isNetworkStream,
                                initialPositionMs = route.initialPositionMs,
                                isInPipMode = isInPipMode,
                                onRegisterLeaveHintPip = { callback ->
                                    leaveHintPipCallback = callback
                                },
                                onBack = { navController.popBackStack() },
                                onOpenSettings = { navController.navigate(SettingsRoute) }
                            )
                        }
                    }

                    composable<SettingsRoute> {
                        SettingsScreen(onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        leaveHintPipCallback?.invoke()
    }

    override fun onDestroy() {
        removeOnPictureInPictureModeChangedListener(pipListener)
        super.onDestroy()
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.action == Intent.ACTION_VIEW) {
            val dataUri = intent.data ?: return
            val title = intent.getStringExtra(Intent.EXTRA_TITLE)
                ?: dataUri.lastPathSegment
                ?: "Video"
            externalOpenUri = dataUri.toString() to title
        } else if (intent.getBooleanExtra(PlaybackService.EXTRA_OPEN_PLAYER, false)) {
            // Returning from MediaSession notification; if backstack already has PlayerRoute it stays visible.
        }
    }
}
